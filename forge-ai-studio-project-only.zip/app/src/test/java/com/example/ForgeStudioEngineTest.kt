package com.example

import com.example.engine3d.ProceduralMeshGenerator
import com.example.io.ObjImporter
import com.example.io.RobloxCompatibilityChecker
import com.example.model.ScenePresets
import com.example.model.SceneShape
import org.junit.Assert.assertEquals
import org.junit.Assert.assertTrue
import org.junit.Test

class ForgeStudioEngineTest {

    @Test
    fun `starter citadel scene has valid parts and scripts`() {
        val (nodes, scripts) = ScenePresets.createStarterCitadelScene()
        assertTrue(nodes.any { it.isFolder })
        assertTrue(nodes.count { !it.isFolder } >= 15)
        assertTrue(scripts.isNotEmpty())
    }

    @Test
    fun `procedural meshes generate non-empty triangles for every primitive`() {
        SceneShape.entries.filter { it != SceneShape.CUSTOM_MESH }.forEach { shape ->
            val mesh = ProceduralMeshGenerator.getMesh(shape)
            assertTrue("Mesh $shape should have vertices", mesh.rawVertices.isNotEmpty())
            assertTrue("Mesh $shape should have indices", mesh.rawIndices.isNotEmpty())
            assertTrue("Mesh $shape indices must be multiple of 3", mesh.rawIndices.size % 3 == 0)
        }
    }

    @Test
    fun `obj importer parses triangle quad`() {
        val obj = """
            v 0 0 0
            v 1 0 0
            v 1 1 0
            v 0 1 0
            f 1 2 3 4
        """.trimIndent()
        val result = ObjImporter.parseObj(obj)
        assertTrue(result.isSuccess)
        val mesh = result.getOrThrow()
        assertEquals(2, mesh.triangleCount)
    }

    @Test
    fun `roblox compatibility checker evaluates starter scene cleanly`() {
        val (nodes, _) = ScenePresets.createStarterCitadelScene()
        val report = RobloxCompatibilityChecker.analyze(nodes, 1f)
        assertTrue(report.totalParts > 0)
        assertTrue(report.totalTriangles > 0)
        assertTrue(report.readyForRoblox)
    }
}
