package com.example.viewmodel

import android.graphics.Bitmap
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import androidx.lifecycle.viewmodel.initializer
import androidx.lifecycle.viewmodel.viewModelFactory
import com.example.data.GeminiStudioService
import com.example.data.ProjectRepository
import com.example.data.SceneAiOperation
import com.example.data.SettingsDataStore
import com.example.data.StudioSettings
import com.example.io.AudioRecorderHelper
import com.example.io.GlbExporter
import com.example.io.ObjImporter
import com.example.io.PortableForgeProject
import com.example.io.ProjectFileCodec
import com.example.io.RobloxCompatibilityChecker
import com.example.model.AiChatMessage
import com.example.model.AiModelChoice
import com.example.model.AssetCatalogItem
import com.example.model.AxisConstraint
import com.example.model.CompatibilityReport
import com.example.model.ConsoleLog
import com.example.model.CustomMeshData
import com.example.model.EditorTool
import com.example.model.ForgeMaterial
import com.example.model.ForgeProjectSummary
import com.example.model.ImageAspectOption
import com.example.model.ImageModelChoice
import com.example.model.ImageResolutionOption
import com.example.model.LightingSettings
import com.example.model.LogLevel
import com.example.model.LuauScript
import com.example.model.NodeKind
import com.example.model.PlayCameraMode
import com.example.model.SceneNode
import com.example.model.ScenePresets
import com.example.model.SceneShape
import com.example.model.TimeOfDay
import com.example.model.Vec3
import com.example.model.WorldRegionPlan
import com.google.firebase.firestore.FirebaseFirestoreException
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

sealed interface CloudProjectsUiState {
    data object Loading : CloudProjectsUiState
    data class Success(val projects: List<ForgeProjectSummary>) : CloudProjectsUiState
    data class Error(val message: String) : CloudProjectsUiState
}

private data class SceneSnapshot(
    val nodes: List<SceneNode>,
    val lighting: LightingSettings
)

data class ForgeStudioUiState(
    val currentProjectId: String? = null,
    val projectName: String = "Sky Citadel Realm",
    val projectDescription: String = "Interactive fantasy island built in Forge AI Studio",
    val isDirty: Boolean = false,
    val nodes: List<SceneNode> = emptyList(),
    val selectedNodeId: String? = null,
    val lighting: LightingSettings = LightingSettings(),
    val scripts: List<LuauScript> = emptyList(),
    val activeScriptId: String? = null,
    val activeTool: EditorTool = EditorTool.SELECT,
    val axisConstraint: AxisConstraint = AxisConstraint.FREE,
    val canUndo: Boolean = false,
    val canRedo: Boolean = false,
    val consoleLogs: List<ConsoleLog> = emptyList(),
    val aiChatMessages: List<AiChatMessage> = emptyList(),
    val aiStreamingText: String = "",
    val isAiBusy: Boolean = false,
    val aiStatusText: String = "Ready (Firebase AI Logic)",
    val worldRegions: List<WorldRegionPlan> = emptyList(),
    val generatedImage: Bitmap? = null,
    val isImageGenerating: Boolean = false,
    val imageGenError: String? = null,
    val videoAnalysisResult: String? = null,
    val isVideoAnalyzing: Boolean = false,
    val videoAnalysisError: String? = null,
    val isRecordingAudio: Boolean = false,
    val commandBarText: String = "",
    val aiConnectionStatus: String = "Not tested",
    val isTestingConnection: Boolean = false,
    val isPlaying: Boolean = false,
    val playCameraMode: PlayCameraMode = PlayCameraMode.THIRD_PERSON,
    val playerPosition: Vec3 = Vec3(0f, 1.0f, 7.6f),
    val playerYaw: Float = 180f,
    val playerWalkCycle: Float = 0f,
    val viewportFps: Int = 60,
    val statusBanner: String? = null,
    val isSavingCloud: Boolean = false,
    val importedAssets: List<SceneNode> = emptyList(),
    val compatibilityReport: CompatibilityReport? = null,
    val exportScaleMultiplier: Float = 1f,
    val luauAiExplanation: String? = null
)

class ForgeStudioViewModel(
    private val currentUserId: String,
    private val projectRepository: ProjectRepository,
    private val settingsDataStore: SettingsDataStore,
    private val geminiService: GeminiStudioService = GeminiStudioService()
) : ViewModel() {

    private val _uiState = MutableStateFlow(ForgeStudioUiState())
    val uiState: StateFlow<ForgeStudioUiState> = _uiState.asStateFlow()

    val settings: StateFlow<StudioSettings> = settingsDataStore.settingsFlow
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), StudioSettings())

    val cloudProjects: StateFlow<CloudProjectsUiState> = projectRepository.observeProjects(currentUserId)
        .map<List<ForgeProjectSummary>, CloudProjectsUiState> { CloudProjectsUiState.Success(it) }
        .catch { error ->
            val firestoreError = generateSequence(error) { it.cause }
                .filterIsInstance<FirebaseFirestoreException>()
                .firstOrNull()
            if (firestoreError == null && error is CancellationException) throw error
            val root = firestoreError ?: error
            Log.w(TAG, "Error observing projects", root)
            emit(CloudProjectsUiState.Error(root.message ?: "Failed to load cloud projects"))
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000L), CloudProjectsUiState.Loading)

    private val undoStack = ArrayDeque<SceneSnapshot>()
    private val redoStack = ArrayDeque<SceneSnapshot>()
    private val audioRecorder = AudioRecorderHelper()
    private var playJob: Job? = null
    private var prePlaySnapshot: SceneSnapshot? = null
    private var liveTransformInitialSnapshot: SceneSnapshot? = null
    private var joystickX = 0f
    private var joystickY = 0f
    private var playerVelY = 0f
    private var isPlayerGrounded = true

    init {
        loadStarterScene()
    }

    private fun loadStarterScene() {
        val (nodes, scripts) = ScenePresets.createStarterCitadelScene()
        _uiState.update {
            it.copy(
                nodes = nodes,
                scripts = scripts,
                activeScriptId = scripts.firstOrNull()?.id,
                selectedNodeId = "bld_keep",
                lighting = LightingSettings(),
                aiChatMessages = listOf(
                    AiChatMessage(
                        isUser = false,
                        text = "Forge AI Architect online. Describe structures, terrain, regions, or edits and I will build them directly in your 3D scene."
                    )
                )
            )
        }
        log(LogLevel.INFO, "Engine", "Initialized Sky Citadel starter scene (${nodes.count { !it.isFolder }} parts).")
        refreshCompatibilityReport()
    }

    // --- Logging ---
    fun log(level: LogLevel, source: String, message: String) {
        val ts = SimpleDateFormat("HH:mm:ss", Locale.US).format(Date())
        val entry = ConsoleLog(timestamp = ts, level = level, source = source, message = message)
        _uiState.update { state ->
            state.copy(consoleLogs = (listOf(entry) + state.consoleLogs).take(120))
        }
    }

    fun clearConsole() {
        _uiState.update { it.copy(consoleLogs = emptyList()) }
    }

    fun dismissBanner() {
        _uiState.update { it.copy(statusBanner = null) }
    }

    // --- Undo / Redo ---
    private fun pushUndoSnapshot() {
        val current = _uiState.value
        undoStack.addLast(SceneSnapshot(current.nodes, current.lighting))
        if (undoStack.size > 40) undoStack.removeFirst()
        redoStack.clear()
        syncHistoryFlags()
    }

    private fun syncHistoryFlags() {
        _uiState.update {
            it.copy(canUndo = undoStack.isNotEmpty(), canRedo = redoStack.isNotEmpty())
        }
    }

    fun undo() {
        if (undoStack.isEmpty() || _uiState.value.isPlaying) return
        val current = _uiState.value
        redoStack.addLast(SceneSnapshot(current.nodes, current.lighting))
        val prev = undoStack.removeLast()
        _uiState.update {
            it.copy(
                nodes = prev.nodes,
                lighting = prev.lighting,
                isDirty = true
            )
        }
        syncHistoryFlags()
        refreshCompatibilityReport()
        log(LogLevel.INFO, "History", "Undid last scene edit.")
    }

    fun redo() {
        if (redoStack.isEmpty() || _uiState.value.isPlaying) return
        val current = _uiState.value
        undoStack.addLast(SceneSnapshot(current.nodes, current.lighting))
        val next = redoStack.removeLast()
        _uiState.update {
            it.copy(
                nodes = next.nodes,
                lighting = next.lighting,
                isDirty = true
            )
        }
        syncHistoryFlags()
        refreshCompatibilityReport()
        log(LogLevel.INFO, "History", "Redid scene edit.")
    }

    // --- Tools & Selection ---
    fun setActiveTool(tool: EditorTool) {
        _uiState.update { it.copy(activeTool = tool) }
    }

    fun setAxisConstraint(axis: AxisConstraint) {
        _uiState.update { it.copy(axisConstraint = axis) }
    }

    fun selectNode(nodeId: String?) {
        _uiState.update { it.copy(selectedNodeId = nodeId) }
    }

    fun onLiveTransform(nodeId: String, pos: Vec3, rot: Vec3, scale: Vec3) {
        if (liveTransformInitialSnapshot == null) {
            val cur = _uiState.value
            liveTransformInitialSnapshot = SceneSnapshot(cur.nodes, cur.lighting)
        }
        _uiState.update { state ->
            state.copy(
                nodes = state.nodes.map { n ->
                    if (n.id == nodeId) n.copy(position = pos, rotation = rot, scale = scale) else n
                },
                isDirty = true
            )
        }
    }

    fun onCommitLiveTransform() {
        liveTransformInitialSnapshot?.let { snap ->
            undoStack.addLast(snap)
            if (undoStack.size > 40) undoStack.removeFirst()
            redoStack.clear()
            liveTransformInitialSnapshot = null
            syncHistoryFlags()
            refreshCompatibilityReport()
        }
    }

    // --- Scene Explorer & Property Inspector Operations ---
    fun createFolder(name: String = "NewFolder", parentId: String = SceneNode.WORKSPACE_ROOT_ID) {
        pushUndoSnapshot()
        val folder = SceneNode(
            name = name.ifBlank { "Folder" },
            kind = NodeKind.FOLDER,
            parentId = parentId
        )
        _uiState.update {
            it.copy(
                nodes = it.nodes + folder,
                selectedNodeId = folder.id,
                isDirty = true
            )
        }
        log(LogLevel.INFO, "Explorer", "Created folder '${folder.name}'.")
    }

    fun toggleFolderExpanded(folderId: String) {
        _uiState.update { state ->
            state.copy(
                nodes = state.nodes.map { n ->
                    if (n.id == folderId && n.isFolder) n.copy(expanded = !n.expanded) else n
                }
            )
        }
    }

    fun toggleNodeVisibility(nodeId: String) {
        pushUndoSnapshot()
        _uiState.update { state ->
            state.copy(
                nodes = state.nodes.map { n ->
                    if (n.id == nodeId) n.copy(visible = !n.visible) else n
                },
                isDirty = true
            )
        }
        refreshCompatibilityReport()
    }

    fun updateNode(nodeId: String, transform: (SceneNode) -> SceneNode) {
        pushUndoSnapshot()
        _uiState.update { state ->
            state.copy(
                nodes = state.nodes.map { if (it.id == nodeId) transform(it) else it },
                isDirty = true
            )
        }
        refreshCompatibilityReport()
    }

    fun duplicateSelected() {
        val selId = _uiState.value.selectedNodeId ?: return
        val source = _uiState.value.nodes.firstOrNull { it.id == selId } ?: return
        pushUndoSnapshot()
        if (source.isFolder) {
            val newFolderId = "fld_${UUID.randomUUID().toString().take(8)}"
            val newFolder = source.copy(id = newFolderId, name = "${source.name}_Copy")
            val children = _uiState.value.nodes.filter { it.parentId == source.id }.map { child ->
                child.copy(
                    id = UUID.randomUUID().toString().take(12),
                    parentId = newFolderId,
                    position = child.position.copy(x = child.position.x + 2.5f)
                )
            }
            _uiState.update {
                it.copy(
                    nodes = it.nodes + newFolder + children,
                    selectedNodeId = newFolderId,
                    isDirty = true
                )
            }
        } else {
            val copy = source.copy(
                id = UUID.randomUUID().toString().take(12),
                name = "${source.name}_Copy",
                position = source.position.copy(x = source.position.x + 1.8f, z = source.position.z + 1.2f)
            )
            _uiState.update {
                it.copy(
                    nodes = it.nodes + copy,
                    selectedNodeId = copy.id,
                    isDirty = true
                )
            }
        }
        refreshCompatibilityReport()
        log(LogLevel.INFO, "Editor", "Duplicated '${source.name}'.")
    }

    fun deleteSelected() {
        val selId = _uiState.value.selectedNodeId ?: return
        val target = _uiState.value.nodes.firstOrNull { it.id == selId } ?: return
        pushUndoSnapshot()
        val idsToRemove = collectSubtreeIds(selId, _uiState.value.nodes)
        _uiState.update { state ->
            state.copy(
                nodes = state.nodes.filterNot { it.id in idsToRemove },
                selectedNodeId = null,
                isDirty = true
            )
        }
        refreshCompatibilityReport()
        log(LogLevel.INFO, "Editor", "Deleted '${target.name}'.")
    }

    private fun collectSubtreeIds(rootId: String, allNodes: List<SceneNode>): Set<String> {
        val result = mutableSetOf(rootId)
        var added = true
        while (added) {
            added = false
            for (n in allNodes) {
                if (n.parentId in result && result.add(n.id)) {
                    added = true
                }
            }
        }
        return result
    }

    fun insertPrimitive(shape: SceneShape, name: String? = null, colorHex: String = "#3B82F6", material: ForgeMaterial = ForgeMaterial.SMOOTH_PLASTIC) {
        pushUndoSnapshot()
        val node = SceneNode(
            name = name ?: shape.label.substringBefore(" "),
            kind = NodeKind.PART,
            shape = shape,
            parentId = resolveInsertParent(),
            position = Vec3(0f, 1.0f, 0f),
            scale = Vec3(2f, 2f, 2f),
            colorHex = colorHex,
            material = material
        )
        _uiState.update {
            it.copy(nodes = it.nodes + node, selectedNodeId = node.id, isDirty = true)
        }
        refreshCompatibilityReport()
        log(LogLevel.INFO, "Insert", "Inserted ${shape.label} '${node.name}'.")
    }

    fun insertCatalogAsset(item: AssetCatalogItem) {
        pushUndoSnapshot()
        val parent = resolveInsertParent()
        val offset = Vec3(((Math.random() - 0.5) * 6.0).toFloat(), 0f, ((Math.random() - 0.5) * 6.0).toFloat())
        val created = item.builder(parent, offset)
        _uiState.update {
            it.copy(
                nodes = it.nodes + created,
                selectedNodeId = created.firstOrNull()?.id,
                isDirty = true,
                statusBanner = "Inserted ${item.name} into Workspace"
            )
        }
        refreshCompatibilityReport()
        log(LogLevel.INFO, "AssetLibrary", "Placed '${item.name}' (${created.size} nodes).")
    }

    fun insertCustomBuiltPart(
        name: String,
        kind: NodeKind,
        shape: SceneShape,
        scale: Vec3,
        colorHex: String,
        material: ForgeMaterial,
        customMesh: CustomMeshData? = null
    ) {
        pushUndoSnapshot()
        val node = SceneNode(
            name = name.ifBlank { "CustomAsset" },
            kind = kind,
            shape = if (customMesh != null) SceneShape.CUSTOM_MESH else shape,
            parentId = resolveInsertParent(),
            position = Vec3(0f, scale.y * 0.5f, 0f),
            scale = scale,
            colorHex = colorHex,
            material = material,
            customMesh = customMesh
        )
        _uiState.update {
            it.copy(
                nodes = it.nodes + node,
                selectedNodeId = node.id,
                isDirty = true,
                statusBanner = "Added '${node.name}' to 3D Scene"
            )
        }
        refreshCompatibilityReport()
        log(LogLevel.INFO, "AssetBuilder", "Built '${node.name}' (${shape.label}).")
    }

    fun importObjText(fileName: String, objContent: String) {
        val parsed = ObjImporter.parseObj(objContent)
        parsed.onSuccess { meshData ->
            val cleanName = fileName.substringBeforeLast('.').ifBlank { "ImportedMesh" }
            val templateNode = SceneNode(
                name = cleanName,
                kind = NodeKind.IMPORTED_MESH,
                shape = SceneShape.CUSTOM_MESH,
                parentId = resolveInsertParent(),
                position = Vec3(0f, 1.5f, 0f),
                scale = Vec3(3f, 3f, 3f),
                colorHex = "#94A3B8",
                material = ForgeMaterial.SMOOTH_PLASTIC,
                customMesh = meshData
            )
            pushUndoSnapshot()
            _uiState.update {
                it.copy(
                    nodes = it.nodes + templateNode,
                    importedAssets = it.importedAssets + templateNode,
                    selectedNodeId = templateNode.id,
                    isDirty = true,
                    statusBanner = "Imported OBJ '$cleanName' (${meshData.triangleCount} tris)"
                )
            }
            refreshCompatibilityReport()
            log(LogLevel.INFO, "Importer", "Imported '$cleanName' (${meshData.triangleCount} triangles).")
        }.onFailure { err ->
            _uiState.update { it.copy(statusBanner = "OBJ import failed: ${err.message}") }
            log(LogLevel.ERROR, "Importer", err.message ?: "Failed to parse OBJ")
        }
    }

    private fun resolveInsertParent(): String {
        val sel = _uiState.value.nodes.firstOrNull { it.id == _uiState.value.selectedNodeId }
        return when {
            sel == null -> SceneNode.WORKSPACE_ROOT_ID
            sel.isFolder -> sel.id
            else -> sel.parentId
        }
    }

    fun updateLighting(transform: (LightingSettings) -> LightingSettings) {
        pushUndoSnapshot()
        _uiState.update { it.copy(lighting = transform(it.lighting), isDirty = true) }
    }

    fun applyTimeOfDay(tod: TimeOfDay) {
        updateLighting {
            it.copy(
                timeOfDay = tod,
                skyColorHex = tod.skyHex,
                ambientIntensity = tod.ambient,
                sunIntensity = tod.sun
            )
        }
        log(LogLevel.INFO, "Lighting", "Switched sky preset to ${tod.label}.")
    }

    // --- Settings Updates ---
    fun setAiModel(model: AiModelChoice) = viewModelScope.launch { settingsDataStore.updateAiModel(model) }
    fun setImageModel(model: ImageModelChoice) = viewModelScope.launch { settingsDataStore.updateImageModel(model) }
    fun setTemperature(t: Float) = viewModelScope.launch { settingsDataStore.updateTemperature(t) }
    fun setAiEnabled(enabled: Boolean) = viewModelScope.launch { settingsDataStore.updateAiEnabled(enabled) }
    fun setSnapEnabled(enabled: Boolean) = viewModelScope.launch { settingsDataStore.updateSnapEnabled(enabled) }
    fun setShowGrid(show: Boolean) = viewModelScope.launch { settingsDataStore.updateShowGrid(show) }
    fun setShowCollisions(show: Boolean) = viewModelScope.launch { settingsDataStore.updateShowCollisions(show) }
    fun setExternal3dUrl(url: String) = viewModelScope.launch { settingsDataStore.updateExternal3dUrl(url) }

    // --- AI Command Bar & AI Scene Architect ---
    fun updateCommandBarText(text: String) {
        _uiState.update { it.copy(commandBarText = text) }
    }

    fun executeAiSceneCommand(prompt: String, isWorldGeneration: Boolean = false) {
        val clean = prompt.trim()
        if (clean.isEmpty()) return
        if (!settings.value.aiEnabled) {
            _uiState.update { it.copy(statusBanner = "AI Mode is disabled in AI Settings. Enable Firebase AI Logic to run AI builds.") }
            log(LogLevel.WARN, "AI", "Command skipped because Non-AI Mode is active.")
            return
        }

        viewModelScope.launch {
            val cur = _uiState.value
            val selected = cur.nodes.firstOrNull { it.id == cur.selectedNodeId }
            _uiState.update {
                it.copy(
                    isAiBusy = true,
                    aiStatusText = if (isWorldGeneration) "Generating multi-region 3D world..." else "Building scene operations...",
                    aiChatMessages = it.aiChatMessages + AiChatMessage(isUser = true, text = clean)
                )
            }
            log(LogLevel.AI, "Gemini", "Prompt: $clean")

            val result = geminiService.generateSceneOperations(
                prompt = clean,
                nodes = cur.nodes,
                selected = selected,
                lighting = cur.lighting,
                modelChoice = settings.value.aiModel,
                temperature = settings.value.temperature,
                isWorldGeneration = isWorldGeneration
            )

            result.onSuccess { plan ->
                val appliedCount = applyValidatedAiOperations(plan.operations, isWorldGeneration)
                val msg = "${plan.summary} ($appliedCount operations applied to 3D viewport)"
                _uiState.update {
                    it.copy(
                        isAiBusy = false,
                        aiStatusText = "Ready",
                        commandBarText = "",
                        statusBanner = plan.summary,
                        aiChatMessages = it.aiChatMessages + AiChatMessage(
                            isUser = false,
                            text = plan.summary,
                            actionSummary = "$appliedCount 3D ops applied"
                        )
                    )
                }
                log(LogLevel.AI, "SceneBuilder", msg)
            }.onFailure { err ->
                val errMsg = err.localizedMessage ?: "AI scene generation failed."
                _uiState.update {
                    it.copy(
                        isAiBusy = false,
                        aiStatusText = "Error",
                        statusBanner = errMsg,
                        aiChatMessages = it.aiChatMessages + AiChatMessage(
                            isUser = false,
                            text = "Error: $errMsg"
                        )
                    )
                }
                log(LogLevel.ERROR, "Gemini", errMsg)
            }
        }
    }

    private fun applyValidatedAiOperations(ops: List<SceneAiOperation>, isWorldGeneration: Boolean): Int {
        if (ops.isEmpty()) return 0
        pushUndoSnapshot()

        val updatedNodes = _uiState.value.nodes.toMutableList()
        var updatedLighting = _uiState.value.lighting
        val folderIdsByName = updatedNodes
            .filter { it.isFolder }
            .associateBy({ it.name.lowercase() }, { it.id })
            .toMutableMap()
        val regionTracker = mutableMapOf<String, MutableList<SceneNode>>()
        var lastCreatedId: String? = null
        var applied = 0

        val currentSelectedId = _uiState.value.selectedNodeId

        for (op in ops) {
            if (updatedNodes.size >= 480 && op.action.startsWith("CREATE")) {
                log(LogLevel.WARN, "Optimizer", "Scene limit (480 nodes) reached; skipping excess objects.")
                break
            }
            when (op.action) {
                "CREATE_FOLDER" -> {
                    val key = op.name.trim().lowercase()
                    if (key.isNotEmpty() && !folderIdsByName.containsKey(key)) {
                        val f = SceneNode(
                            id = "fld_${UUID.randomUUID().toString().take(8)}",
                            name = op.name.trim().take(64),
                            kind = NodeKind.FOLDER,
                            parentId = SceneNode.WORKSPACE_ROOT_ID
                        )
                        updatedNodes.add(f)
                        folderIdsByName[key] = f.id
                        regionTracker[f.id] = mutableListOf()
                        applied++
                    }
                }
                "CREATE_OBJECT" -> {
                    var parentId = SceneNode.WORKSPACE_ROOT_ID
                    val folderKey = op.folderName?.trim()?.lowercase()
                    if (!folderKey.isNullOrEmpty()) {
                        parentId = folderIdsByName.getOrPut(folderKey) {
                            val newF = SceneNode(
                                id = "fld_${UUID.randomUUID().toString().take(8)}",
                                name = op.folderName.trim().take(64),
                                kind = NodeKind.FOLDER,
                                parentId = SceneNode.WORKSPACE_ROOT_ID
                            )
                            updatedNodes.add(newF)
                            regionTracker[newF.id] = mutableListOf()
                            newF.id
                        }
                    }
                    val node = SceneNode(
                        name = op.name.trim().take(64).ifBlank { "AiPart" },
                        kind = op.kind,
                        shape = op.shape,
                        parentId = parentId,
                        position = op.position ?: Vec3(0f, 1f, 0f),
                        rotation = op.rotation ?: Vec3(0f, 0f, 0f),
                        scale = op.scale ?: Vec3(2f, 2f, 2f),
                        colorHex = op.colorHex ?: "#3B82F6",
                        material = op.material ?: ForgeMaterial.SMOOTH_PLASTIC,
                        canCollide = op.canCollide ?: true
                    )
                    updatedNodes.add(node)
                    regionTracker.getOrPut(parentId) { mutableListOf() }.add(node)
                    lastCreatedId = node.id
                    applied++
                }
                "MODIFY_OBJECT" -> {
                    val idx = when {
                        op.targetName.equals("SELECTED", ignoreCase = true) && currentSelectedId != null ->
                            updatedNodes.indexOfFirst { it.id == currentSelectedId }
                        !op.targetName.isNullOrBlank() ->
                            updatedNodes.indexOfFirst { it.name.equals(op.targetName, ignoreCase = true) }
                        currentSelectedId != null ->
                            updatedNodes.indexOfFirst { it.id == currentSelectedId }
                        else -> -1
                    }
                    if (idx >= 0) {
                        val existing = updatedNodes[idx]
                        updatedNodes[idx] = existing.copy(
                            name = if (op.name.isNotBlank() && op.name != "GeneratedPart") op.name else existing.name,
                            position = op.position ?: existing.position,
                            rotation = op.rotation ?: existing.rotation,
                            scale = op.scale ?: existing.scale,
                            colorHex = op.colorHex ?: existing.colorHex,
                            material = op.material ?: existing.material,
                            canCollide = op.canCollide ?: existing.canCollide
                        )
                        applied++
                    }
                }
                "DELETE_OBJECT" -> {
                    val targetIdx = when {
                        op.targetName.equals("SELECTED", ignoreCase = true) && currentSelectedId != null ->
                            updatedNodes.indexOfFirst { it.id == currentSelectedId }
                        !op.targetName.isNullOrBlank() ->
                            updatedNodes.indexOfFirst { it.name.equals(op.targetName, ignoreCase = true) }
                        else -> -1
                    }
                    if (targetIdx >= 0) {
                        val remIds = collectSubtreeIds(updatedNodes[targetIdx].id, updatedNodes)
                        updatedNodes.removeAll { it.id in remIds }
                        applied++
                    }
                }
                "SET_LIGHTING" -> {
                    val tod = op.timeOfDay ?: TimeOfDay.DUSK
                    updatedLighting = updatedLighting.copy(
                        timeOfDay = tod,
                        skyColorHex = tod.skyHex,
                        ambientIntensity = tod.ambient,
                        sunIntensity = tod.sun
                    )
                    applied++
                }
            }
        }

        val newRegions = if (isWorldGeneration) {
            regionTracker.entries.mapNotNull { (fId, kids) ->
                val folder = updatedNodes.firstOrNull { it.id == fId } ?: return@mapNotNull null
                if (kids.isEmpty()) return@mapNotNull null
                val avgX = kids.map { it.position.x }.average().toFloat()
                val avgZ = kids.map { it.position.z }.average().toFloat()
                WorldRegionPlan(
                    regionName = folder.name,
                    folderId = fId,
                    theme = kids.first().kind.label,
                    centerX = avgX,
                    centerZ = avgZ,
                    objectCount = kids.size
                )
            }
        } else {
            _uiState.value.worldRegions
        }

        _uiState.update {
            it.copy(
                nodes = updatedNodes,
                lighting = updatedLighting,
                selectedNodeId = lastCreatedId ?: it.selectedNodeId,
                worldRegions = newRegions,
                isDirty = true
            )
        }
        refreshCompatibilityReport()
        return applied
    }

    fun regenerateRegion(region: WorldRegionPlan) {
        val currentNodes = _uiState.value.nodes
        val subtree = collectSubtreeIds(region.folderId, currentNodes)
        pushUndoSnapshot()
        _uiState.update { state ->
            state.copy(nodes = state.nodes.filterNot { it.id in subtree })
        }
        executeAiSceneCommand(
            "Regenerate the region folder '${region.regionName}' near X=${region.centerX}, Z=${region.centerZ} with fresh buildings, terrain, and props.",
            isWorldGeneration = false
        )
    }

    // --- Multi-turn AI Assistant Chat ---
    fun sendChatMessage(prompt: String) {
        val clean = prompt.trim()
        if (clean.isEmpty()) return
        if (!settings.value.aiEnabled) {
            _uiState.update {
                it.copy(
                    aiChatMessages = it.aiChatMessages +
                        AiChatMessage(isUser = true, text = clean) +
                        AiChatMessage(isUser = false, text = "Non-AI mode is enabled. Switch AI Mode ON in Settings to chat with Gemini.")
                )
            }
            return
        }
        val cur = _uiState.value
        val selected = cur.nodes.firstOrNull { it.id == cur.selectedNodeId }
        val summary = "Project '${cur.projectName}', ${cur.nodes.count { !it.isFolder }} parts, " +
            "Selected: ${selected?.name ?: "None"}, Scripts: ${cur.scripts.size}."

        _uiState.update {
            it.copy(
                aiChatMessages = it.aiChatMessages + AiChatMessage(isUser = true, text = clean),
                isAiBusy = true,
                aiStreamingText = ""
            )
        }

        viewModelScope.launch {
            try {
                var finalText = ""
                geminiService.streamAssistantChat(
                    history = cur.aiChatMessages,
                    userPrompt = clean,
                    sceneSummary = summary,
                    modelChoice = settings.value.aiModel,
                    temperature = settings.value.temperature
                ).collect { chunk ->
                    finalText = chunk
                    _uiState.update { it.copy(aiStreamingText = chunk) }
                }
                _uiState.update {
                    it.copy(
                        isAiBusy = false,
                        aiStreamingText = "",
                        aiChatMessages = it.aiChatMessages + AiChatMessage(
                            isUser = false,
                            text = finalText.ifBlank { "No response received." }
                        )
                    )
                }
            } catch (e: CancellationException) {
                throw e
            } catch (e: Exception) {
                val msg = e.localizedMessage ?: "Chat request failed."
                _uiState.update {
                    it.copy(
                        isAiBusy = false,
                        aiStreamingText = "",
                        aiChatMessages = it.aiChatMessages + AiChatMessage(isUser = false, text = "Error: $msg")
                    )
                }
                log(LogLevel.ERROR, "AiChat", msg)
            }
        }
    }

    // --- Luau Script Editor & AI Script Assistant ---
    fun selectScript(scriptId: String) {
        _uiState.update { it.copy(activeScriptId = scriptId) }
    }

    fun updateActiveScriptCode(newCode: String) {
        val activeId = _uiState.value.activeScriptId ?: return
        _uiState.update { state ->
            state.copy(
                scripts = state.scripts.map { if (it.id == activeId) it.copy(code = newCode) else it },
                isDirty = true
            )
        }
    }

    fun createNewScript(name: String = "NewScript.luau", type: String = "Script") {
        val s = LuauScript(
            name = if (name.endsWith(".luau")) name else "$name.luau",
            scriptType = type,
            parentTarget = if (type == "LocalScript") "StarterPlayerScripts" else if (type == "ModuleScript") "ReplicatedStorage" else "ServerScriptService",
            code = "-- $name ($type)\n-- Exported for Roblox Studio\n\nprint(\"Forge AI Studio script ready!\")\n"
        )
        _uiState.update {
            it.copy(scripts = it.scripts + s, activeScriptId = s.id, isDirty = true)
        }
        refreshCompatibilityReport()
    }

    fun deleteActiveScript() {
        val activeId = _uiState.value.activeScriptId ?: return
        _uiState.update { state ->
            val rem = state.scripts.filterNot { it.id == activeId }
            state.copy(scripts = rem, activeScriptId = rem.firstOrNull()?.id, isDirty = true)
        }
    }

    fun askLuauAssistant(prompt: String, modifyCurrent: Boolean) {
        val clean = prompt.trim()
        if (clean.isEmpty()) return
        if (!settings.value.aiEnabled) {
            _uiState.update { it.copy(statusBanner = "Enable AI Mode in Settings to use the Luau Assistant.") }
            return
        }
        val activeScript = if (modifyCurrent) _uiState.value.scripts.firstOrNull { it.id == _uiState.value.activeScriptId } else null

        viewModelScope.launch {
            _uiState.update { it.copy(isAiBusy = true, aiStatusText = "Generating Luau script...") }
            val result = geminiService.generateLuauScript(
                prompt = clean,
                existingCode = activeScript?.code,
                modelChoice = settings.value.aiModel
            )
            result.onSuccess { res ->
                if (modifyCurrent && activeScript != null) {
                    _uiState.update { state ->
                        state.copy(
                            scripts = state.scripts.map {
                                if (it.id == activeScript.id) it.copy(code = res.code) else it
                            },
                            luauAiExplanation = res.explanation,
                            isAiBusy = false,
                            aiStatusText = "Ready",
                            isDirty = true
                        )
                    }
                } else {
                    val created = LuauScript(
                        name = if (res.scriptName.endsWith(".luau")) res.scriptName else "${res.scriptName}.luau",
                        scriptType = res.scriptType,
                        parentTarget = res.parentTarget,
                        code = res.code
                    )
                    _uiState.update { state ->
                        state.copy(
                            scripts = state.scripts + created,
                            activeScriptId = created.id,
                            luauAiExplanation = res.explanation,
                            isAiBusy = false,
                            aiStatusText = "Ready",
                            isDirty = true
                        )
                    }
                }
                log(LogLevel.AI, "LuauAI", "Generated '${res.scriptName}' (${res.scriptType}).")
            }.onFailure { err ->
                val msg = err.localizedMessage ?: "Luau generation failed."
                _uiState.update {
                    it.copy(isAiBusy = false, aiStatusText = "Error", luauAiExplanation = "Error: $msg")
                }
                log(LogLevel.ERROR, "LuauAI", msg)
            }
        }
    }

    // --- Multimodal AI Lab (Image Gen, Audio Transcription, Video Analysis) ---
    fun generateTextureOrConceptArt(prompt: String, aspect: ImageAspectOption, resolution: ImageResolutionOption) {
        if (prompt.isBlank()) return
        if (!settings.value.aiEnabled) {
            _uiState.update { it.copy(imageGenError = "AI Mode is disabled in Settings.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isImageGenerating = true, imageGenError = null) }
            val result = geminiService.generateConceptOrTextureImage(
                prompt = prompt,
                modelChoice = settings.value.imageModel,
                aspect = aspect,
                resolution = resolution
            )
            result.onSuccess { bmp ->
                _uiState.update { it.copy(generatedImage = bmp, isImageGenerating = false) }
                log(LogLevel.AI, "ImageStudio", "Generated ${resolution.label} (${aspect.label}) asset concept.")
            }.onFailure { err ->
                val msg = err.localizedMessage ?: "Image generation failed."
                _uiState.update { it.copy(isImageGenerating = false, imageGenError = msg) }
                log(LogLevel.ERROR, "ImageStudio", msg)
            }
        }
    }

    fun toggleAudioVoiceCommand() {
        if (_uiState.value.isRecordingAudio) {
            val wavBytes = audioRecorder.stopAndBuildWav()
            _uiState.update { it.copy(isRecordingAudio = false, isAiBusy = true, aiStatusText = "Transcribing voice command...") }
            viewModelScope.launch {
                val res = geminiService.transcribeAudioCommand(wavBytes, settings.value.aiModel)
                res.onSuccess { transcript ->
                    _uiState.update {
                        it.copy(
                            isAiBusy = false,
                            aiStatusText = "Ready",
                            commandBarText = transcript,
                            statusBanner = "Transcribed: \"$transcript\""
                        )
                    }
                    log(LogLevel.AI, "VoiceAI", "Transcribed: $transcript")
                }.onFailure { err ->
                    val msg = err.localizedMessage ?: "Audio transcription failed."
                    _uiState.update { it.copy(isAiBusy = false, aiStatusText = "Error", statusBanner = msg) }
                    log(LogLevel.ERROR, "VoiceAI", msg)
                }
            }
        } else {
            val started = audioRecorder.startRecording()
            if (started) {
                _uiState.update { it.copy(isRecordingAudio = true, statusBanner = "Listening... tap mic again to transcribe") }
            } else {
                _uiState.update { it.copy(statusBanner = "Could not start microphone recorder.") }
            }
        }
    }

    fun analyzeVideoClip(videoBytes: ByteArray, mimeType: String, prompt: String) {
        if (!settings.value.aiEnabled) {
            _uiState.update { it.copy(videoAnalysisError = "AI Mode is disabled in Settings.") }
            return
        }
        viewModelScope.launch {
            _uiState.update { it.copy(isVideoAnalyzing = true, videoAnalysisError = null) }
            val res = geminiService.analyzeVideoReference(videoBytes, mimeType, prompt, settings.value.aiModel)
            res.onSuccess { analysis ->
                _uiState.update { it.copy(isVideoAnalyzing = false, videoAnalysisResult = analysis) }
                log(LogLevel.AI, "VideoAI", "Completed video reference analysis.")
            }.onFailure { err ->
                val msg = err.localizedMessage ?: "Video analysis failed."
                _uiState.update { it.copy(isVideoAnalyzing = false, videoAnalysisError = msg) }
                log(LogLevel.ERROR, "VideoAI", msg)
            }
        }
    }

    fun testAiConnection() {
        viewModelScope.launch {
            _uiState.update { it.copy(isTestingConnection = true, aiConnectionStatus = "Testing Firebase AI Logic...") }
            val res = geminiService.testConnection(settings.value.aiModel)
            res.onSuccess { (reply, ms) ->
                _uiState.update {
                    it.copy(
                        isTestingConnection = false,
                        aiConnectionStatus = "Connected (${settings.value.aiModel.modelId}) • ${ms}ms • '$reply'"
                    )
                }
                log(LogLevel.AI, "Diagnostics", "Gemini connection verified in ${ms}ms.")
            }.onFailure { err ->
                val msg = err.localizedMessage ?: "Connection failed"
                _uiState.update {
                    it.copy(isTestingConnection = false, aiConnectionStatus = "Error: $msg")
                }
                log(LogLevel.ERROR, "Diagnostics", msg)
            }
        }
    }

    // --- Play Testing Mode (Internal 3D Preview Engine) ---
    fun togglePlayMode() {
        if (_uiState.value.isPlaying) stopPlayMode() else startPlayMode()
    }

    fun startPlayMode() {
        if (_uiState.value.isPlaying) return
        val cur = _uiState.value
        prePlaySnapshot = SceneSnapshot(cur.nodes, cur.lighting)
        playerVelY = 0f
        isPlayerGrounded = true
        _uiState.update {
            it.copy(
                isPlaying = true,
                playerPosition = Vec3(0f, 1.5f, 7.6f),
                playerYaw = 180f,
                playerWalkCycle = 0f
            )
        }
        log(LogLevel.INFO, "PlayPreview", "Started Forge Internal 3D Preview Engine (not Roblox runtime).")

        playJob?.cancel()
        playJob = viewModelScope.launch {
            val dt = 1f / 30f
            while (isActive && _uiState.value.isPlaying) {
                stepPlaySimulation(dt)
                delay(33L)
            }
        }
    }

    fun stopPlayMode() {
        playJob?.cancel()
        playJob = null
        val snap = prePlaySnapshot
        _uiState.update {
            it.copy(
                isPlaying = false,
                nodes = snap?.nodes ?: it.nodes,
                lighting = snap?.lighting ?: it.lighting
            )
        }
        prePlaySnapshot = null
        log(LogLevel.INFO, "PlayPreview", "Stopped Play Preview and restored scene state.")
    }

    fun resetPlayCharacter() {
        playerVelY = 0f
        _uiState.update {
            it.copy(playerPosition = Vec3(0f, 1.5f, 7.6f), playerYaw = 180f, playerWalkCycle = 0f)
        }
    }

    fun setPlayCameraMode(mode: PlayCameraMode) {
        _uiState.update { it.copy(playCameraMode = mode) }
    }

    fun setJoystickInput(x: Float, y: Float) {
        joystickX = x.coerceIn(-1f, 1f)
        joystickY = y.coerceIn(-1f, 1f)
    }

    fun jumpPlayCharacter() {
        if (_uiState.value.isPlaying && isPlayerGrounded) {
            playerVelY = 8.5f
            isPlayerGrounded = false
        }
    }

    fun addPlayYawDelta(deltaYaw: Float) {
        _uiState.update { it.copy(playerYaw = (it.playerYaw + deltaYaw) % 360f) }
    }

    fun updateViewportFps(fps: Int) {
        _uiState.update { it.copy(viewportFps = fps) }
    }

    private fun stepPlaySimulation(dt: Float) {
        val state = _uiState.value
        val yawRad = Math.toRadians(state.playerYaw.toDouble())
        val fwdX = sin(yawRad).toFloat()
        val fwdZ = cos(yawRad).toFloat()
        val rightX = -cos(yawRad).toFloat()
        val rightZ = sin(yawRad).toFloat()

        val speed = 7.5f
        val moveX = (fwdX * joystickY + rightX * joystickX) * speed * dt
        val moveZ = (fwdZ * joystickY + rightZ * joystickX) * speed * dt

        var p = state.playerPosition
        val colliders = state.nodes.filter { !it.isFolder && it.visible && it.canCollide }
        val pRadius = 0.45f
        val pHeight = 1.9f

        // Horizontal X/Z move with simple AABB collision pushout
        var nextX = p.x + moveX
        var nextZ = p.z + moveZ
        for (c in colliders) {
            val minX = c.position.x - c.scale.x * 0.5f - pRadius
            val maxX = c.position.x + c.scale.x * 0.5f + pRadius
            val minZ = c.position.z - c.scale.z * 0.5f - pRadius
            val maxZ = c.position.z + c.scale.z * 0.5f + pRadius
            val topY = c.position.y + c.scale.y * 0.5f
            val botY = c.position.y - c.scale.y * 0.5f

            // Skip step-up surfaces within 0.55 units of feet
            if (p.y + 0.55f < topY && p.y + pHeight > botY) {
                if (nextX in minX..maxX && nextZ in minZ..maxZ) {
                    val penLeft = abs(nextX - minX)
                    val penRight = abs(maxX - nextX)
                    val penBack = abs(nextZ - minZ)
                    val penFront = abs(maxZ - nextZ)
                    val minPen = minOf(penLeft, penRight, penBack, penFront)
                    when (minPen) {
                        penLeft -> nextX = minX
                        penRight -> nextX = maxX
                        penBack -> nextZ = minZ
                        else -> nextZ = maxZ
                    }
                }
            }
        }

        // Gravity & vertical landing
        playerVelY -= 22f * dt
        var nextY = p.y + playerVelY * dt
        var grounded = false

        if (nextY <= 0f) {
            nextY = 0f
            playerVelY = 0f
            grounded = true
        }

        for (c in colliders) {
            val minX = c.position.x - c.scale.x * 0.5f - pRadius
            val maxX = c.position.x + c.scale.x * 0.5f + pRadius
            val minZ = c.position.z - c.scale.z * 0.5f - pRadius
            val maxZ = c.position.z + c.scale.z * 0.5f + pRadius
            val topY = c.position.y + c.scale.y * 0.5f
            if (nextX in minX..maxX && nextZ in minZ..maxZ && playerVelY <= 0f) {
                if (p.y >= topY - 0.6f && nextY <= topY) {
                    nextY = topY
                    playerVelY = 0f
                    grounded = true
                }
            }
        }
        isPlayerGrounded = grounded

        val moving = abs(joystickX) > 0.1f || abs(joystickY) > 0.1f
        val nextWalk = if (moving && grounded) (state.playerWalkCycle + dt * 11f) else 0f

        _uiState.update {
            it.copy(
                playerPosition = Vec3(nextX.coerceIn(-40f, 40f), nextY, nextZ.coerceIn(-40f, 40f)),
                playerWalkCycle = nextWalk
            )
        }
    }

    // --- Export Center & Compatibility ---
    fun setExportScaleMultiplier(scale: Float) {
        _uiState.update { it.copy(exportScaleMultiplier = scale.coerceIn(0.1f, 20f)) }
        refreshCompatibilityReport()
    }

    fun refreshCompatibilityReport() {
        val state = _uiState.value
        val report = RobloxCompatibilityChecker.analyze(state.nodes, state.exportScaleMultiplier)
        _uiState.update { it.copy(compatibilityReport = report) }
    }

    fun buildGlbBytes(selectedOnly: Boolean): ByteArray {
        val targets = targetExportNodes(selectedOnly)
        return GlbExporter.exportGlb(targets, _uiState.value.exportScaleMultiplier)
    }

    fun buildGltfText(selectedOnly: Boolean): String {
        val targets = targetExportNodes(selectedOnly)
        return GlbExporter.exportGltfJson(targets, _uiState.value.exportScaleMultiplier)
    }

    fun buildObjText(selectedOnly: Boolean): String {
        val targets = targetExportNodes(selectedOnly)
        return GlbExporter.exportObj(targets, _uiState.value.exportScaleMultiplier).first
    }

    fun buildManifestText(): String {
        val state = _uiState.value
        return GlbExporter.exportRobloxManifest(state.projectName, state.nodes, state.scripts, state.exportScaleMultiplier)
    }

    fun buildProjectFileJson(): String {
        val s = _uiState.value
        return ProjectFileCodec.encode(
            PortableForgeProject(
                name = s.projectName,
                description = s.projectDescription,
                lighting = s.lighting,
                nodes = s.nodes,
                scripts = s.scripts
            )
        )
    }

    fun importProjectFileJson(jsonString: String) {
        ProjectFileCodec.decode(jsonString).onSuccess { proj ->
            undoStack.clear()
            redoStack.clear()
            _uiState.update {
                it.copy(
                    currentProjectId = null,
                    projectName = proj.name,
                    projectDescription = proj.description,
                    lighting = proj.lighting,
                    nodes = proj.nodes,
                    scripts = proj.scripts,
                    activeScriptId = proj.scripts.firstOrNull()?.id,
                    selectedNodeId = proj.nodes.firstOrNull { !it.isFolder }?.id,
                    isDirty = true,
                    statusBanner = "Imported project '${proj.name}' from file."
                )
            }
            syncHistoryFlags()
            refreshCompatibilityReport()
            log(LogLevel.INFO, "ProjectIO", "Imported '${proj.name}' (${proj.nodes.size} nodes).")
        }.onFailure { err ->
            _uiState.update { it.copy(statusBanner = "Project import failed: ${err.message}") }
            log(LogLevel.ERROR, "ProjectIO", err.message ?: "Failed to import .forge.json")
        }
    }

    private fun targetExportNodes(selectedOnly: Boolean): List<SceneNode> {
        val state = _uiState.value
        if (!selectedOnly || state.selectedNodeId == null) return state.nodes
        val ids = collectSubtreeIds(state.selectedNodeId, state.nodes)
        return state.nodes.filter { it.id in ids }
    }

    // --- Cloud Project Persistence (Firestore) ---
    fun newBlankProject(name: String, useCitadelTemplate: Boolean) {
        undoStack.clear()
        redoStack.clear()
        val (nodes, scripts) = if (useCitadelTemplate) ScenePresets.createStarterCitadelScene() else ScenePresets.createEmptyBaseplate()
        _uiState.update {
            it.copy(
                currentProjectId = null,
                projectName = name.trim().ifBlank { "Untitled Forge Project" },
                projectDescription = if (useCitadelTemplate) "Fantasy Citadel starter template" else "Clean baseplate workspace",
                nodes = nodes,
                scripts = scripts,
                activeScriptId = scripts.firstOrNull()?.id,
                selectedNodeId = nodes.firstOrNull { !it.isFolder }?.id,
                lighting = LightingSettings(),
                worldRegions = emptyList(),
                isDirty = false,
                statusBanner = "Created project '${name.ifBlank { "Untitled Forge Project" }}'"
            )
        }
        syncHistoryFlags()
        refreshCompatibilityReport()
    }

    fun renameCurrentProject(newName: String) {
        val clean = newName.trim().take(80)
        if (clean.isEmpty()) return
        _uiState.update { it.copy(projectName = clean, isDirty = true) }
        val pid = _uiState.value.currentProjectId ?: return
        viewModelScope.launch {
            projectRepository.renameProject(currentUserId, pid, clean).onSuccess {
                _uiState.update { it.copy(statusBanner = "Renamed project to '$clean'") }
            }.onFailure { err ->
                log(LogLevel.ERROR, "CloudSave", err.message ?: "Rename failed")
            }
        }
    }

    fun saveProjectToCloud() {
        val s = _uiState.value
        viewModelScope.launch {
            _uiState.update { it.copy(isSavingCloud = true) }
            val existingId = s.currentProjectId
            if (existingId == null) {
                projectRepository.createProject(
                    userId = currentUserId,
                    name = s.projectName,
                    description = s.projectDescription,
                    lighting = s.lighting,
                    objects = s.nodes,
                    scripts = s.scripts
                ).onSuccess { newId ->
                    _uiState.update {
                        it.copy(
                            currentProjectId = newId,
                            isSavingCloud = false,
                            isDirty = false,
                            statusBanner = "Saved '${s.projectName}' to Firestore Cloud."
                        )
                    }
                    log(LogLevel.INFO, "CloudSave", "Created cloud project '${s.projectName}' ($newId).")
                }.onFailure { err ->
                    val msg = err.localizedMessage ?: "Cloud save failed."
                    _uiState.update { it.copy(isSavingCloud = false, statusBanner = msg) }
                    log(LogLevel.ERROR, "CloudSave", msg)
                }
            } else {
                projectRepository.saveProject(
                    userId = currentUserId,
                    projectId = existingId,
                    name = s.projectName,
                    description = s.projectDescription,
                    lighting = s.lighting,
                    objects = s.nodes,
                    scripts = s.scripts
                ).onSuccess {
                    _uiState.update {
                        it.copy(
                            isSavingCloud = false,
                            isDirty = false,
                            statusBanner = "Updated '${s.projectName}' in Firestore Cloud."
                        )
                    }
                    log(LogLevel.INFO, "CloudSave", "Saved changes to '${s.projectName}'.")
                }.onFailure { err ->
                    val msg = err.localizedMessage ?: "Cloud update failed."
                    _uiState.update { it.copy(isSavingCloud = false, statusBanner = msg) }
                    log(LogLevel.ERROR, "CloudSave", msg)
                }
            }
        }
    }

    fun loadCloudProject(project: ForgeProjectSummary) {
        undoStack.clear()
        redoStack.clear()
        _uiState.update {
            it.copy(
                currentProjectId = project.id,
                projectName = project.name,
                projectDescription = project.description,
                lighting = project.lighting,
                nodes = project.objects,
                scripts = project.scripts,
                activeScriptId = project.scripts.firstOrNull()?.id,
                selectedNodeId = project.objects.firstOrNull { !it.isFolder }?.id,
                worldRegions = emptyList(),
                isDirty = false,
                statusBanner = "Loaded '${project.name}'"
            )
        }
        syncHistoryFlags()
        refreshCompatibilityReport()
        log(LogLevel.INFO, "CloudLoad", "Loaded '${project.name}' (${project.objects.size} nodes).")
    }

    fun deleteCloudProject(projectId: String) {
        viewModelScope.launch {
            projectRepository.deleteProject(currentUserId, projectId).onSuccess {
                _uiState.update { state ->
                    if (state.currentProjectId == projectId) {
                        state.copy(currentProjectId = null, statusBanner = "Deleted cloud project.")
                    } else {
                        state.copy(statusBanner = "Deleted cloud project.")
                    }
                }
            }.onFailure { err ->
                log(LogLevel.ERROR, "CloudSave", err.message ?: "Delete failed")
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        playJob?.cancel()
    }

    companion object {
        private const val TAG = "ForgeStudioVM"

        fun provideFactory(
            currentUserId: String,
            projectRepository: ProjectRepository,
            settingsDataStore: SettingsDataStore
        ): ViewModelProvider.Factory = viewModelFactory {
            initializer {
                ForgeStudioViewModel(
                    currentUserId = currentUserId,
                    projectRepository = projectRepository,
                    settingsDataStore = settingsDataStore
                )
            }
        }
    }
}
