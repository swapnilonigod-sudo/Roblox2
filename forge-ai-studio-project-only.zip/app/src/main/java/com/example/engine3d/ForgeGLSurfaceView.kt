package com.example.engine3d

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Color
import android.opengl.GLES20
import android.opengl.GLSurfaceView
import android.opengl.Matrix
import android.view.MotionEvent
import com.example.model.AxisConstraint
import com.example.model.CameraPreset
import com.example.model.EditorTool
import com.example.model.ForgeMaterial
import com.example.model.LightingSettings
import com.example.model.PlayCameraMode
import com.example.model.SceneNode
import com.example.model.SceneShape
import com.example.model.Vec3
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.nio.FloatBuffer
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

data class ViewportRenderState(
    val nodes: List<SceneNode> = emptyList(),
    val selectedNodeId: String? = null,
    val lighting: LightingSettings = LightingSettings(),
    val activeTool: EditorTool = EditorTool.SELECT,
    val axisConstraint: AxisConstraint = AxisConstraint.FREE,
    val showGrid: Boolean = true,
    val showCollisions: Boolean = false,
    val snapEnabled: Boolean = false,
    val isPlaying: Boolean = false,
    val playCameraMode: PlayCameraMode = PlayCameraMode.THIRD_PERSON,
    val playerPosition: Vec3 = Vec3(0f, 1.0f, 7.6f),
    val playerYaw: Float = 180f,
    val playerWalkCycle: Float = 0f
)

@SuppressLint("ViewConstructor")
class ForgeGLSurfaceView(
    context: Context,
    private val onSelectNode: (String?) -> Unit,
    private val onTransformLive: (nodeId: String, pos: Vec3, rot: Vec3, scale: Vec3) -> Unit,
    private val onTransformCommit: () -> Unit,
    private val onPlayLookDelta: (deltaYaw: Float) -> Unit,
    private val onFpsMeasured: (Int) -> Unit
) : GLSurfaceView(context) {

    private val renderer = ForgeRenderer()

    private var camYaw = 38f
    private var camPitch = 28f
    private var camDistance = 20f
    private var camTarget = Vec3(0f, 1.5f, 0f)

    private var activeDragAxis: AxisConstraint? = null
    private var isDraggingObject = false
    private var isOrbiting = false
    private var lastTouchX = 0f
    private var lastTouchY = 0f
    private var downTouchX = 0f
    private var downTouchY = 0f
    private var downTimeMs = 0L
    private var prevPinchDist = 0f
    private var prevMidX = 0f
    private var prevMidY = 0f
    private var wasMultiTouch = false

    init {
        setEGLContextClientVersion(2)
        setRenderer(renderer)
        renderMode = RENDERMODE_CONTINUOUSLY
    }

    fun updateRenderState(state: ViewportRenderState) {
        renderer.updateState(state)
    }

    fun applyCameraPreset(preset: CameraPreset) {
        when (preset) {
            CameraPreset.PERSPECTIVE -> {
                camYaw = 38f; camPitch = 28f; camDistance = 20f; camTarget = Vec3(0f, 1.5f, 0f)
            }
            CameraPreset.TOP -> {
                camYaw = 0f; camPitch = 88f; camDistance = 26f; camTarget = Vec3(0f, 0f, 0f)
            }
            CameraPreset.FRONT -> {
                camYaw = 0f; camPitch = 8f; camDistance = 22f; camTarget = Vec3(0f, 2.0f, 0f)
            }
            CameraPreset.SIDE -> {
                camYaw = 90f; camPitch = 10f; camDistance = 22f; camTarget = Vec3(0f, 2.0f, 0f)
            }
            CameraPreset.ISOMETRIC -> {
                camYaw = 45f; camPitch = 35.26f; camDistance = 24f; camTarget = Vec3(0f, 1.2f, 0f)
            }
        }
        renderer.setCamera(camYaw, camPitch, camDistance, camTarget)
    }

    fun focusOnNode(node: SceneNode) {
        camTarget = node.position
        camDistance = (maxOf(node.scale.x, node.scale.y, node.scale.z) * 3.2f).coerceIn(6f, 36f)
        renderer.setCamera(camYaw, camPitch, camDistance, camTarget)
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(event: MotionEvent): Boolean {
        val state = renderer.currentState
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                downTouchX = event.x
                downTouchY = event.y
                lastTouchX = event.x
                lastTouchY = event.y
                downTimeMs = System.currentTimeMillis()
                wasMultiTouch = false
                isDraggingObject = false
                isOrbiting = false
                activeDragAxis = null

                if (!state.isPlaying && state.activeTool != EditorTool.SELECT) {
                    val selected = state.nodes.firstOrNull { it.id == state.selectedNodeId && !it.isFolder }
                    if (selected != null) {
                        val ray = RayPicker.screenToRay(
                            event.x, event.y, width, height, renderer.lastViewProjMatrix
                        )
                        if (ray != null) {
                            val gizmoSize = (camDistance * 0.16f).coerceIn(1.5f, 4.5f)
                            val hitAxis = RayPicker.pickGizmoAxis(ray, selected, gizmoSize)
                            if (hitAxis != null) {
                                activeDragAxis = hitAxis
                                isDraggingObject = true
                            } else if (state.axisConstraint != AxisConstraint.FREE) {
                                val hitNode = RayPicker.pickSceneNode(ray, listOf(selected))
                                if (hitNode != null) {
                                    activeDragAxis = state.axisConstraint
                                    isDraggingObject = true
                                }
                            } else {
                                val hitNode = RayPicker.pickSceneNode(ray, listOf(selected))
                                if (hitNode != null) {
                                    activeDragAxis = AxisConstraint.FREE
                                    isDraggingObject = true
                                }
                            }
                        }
                    }
                }
                if (!isDraggingObject) {
                    isOrbiting = true
                }
                return true
            }

            MotionEvent.ACTION_POINTER_DOWN -> {
                if (event.pointerCount >= 2) {
                    wasMultiTouch = true
                    isDraggingObject = false
                    isOrbiting = false
                    prevPinchDist = pinchDistance(event)
                    prevMidX = (event.getX(0) + event.getX(1)) * 0.5f
                    prevMidY = (event.getY(0) + event.getY(1)) * 0.5f
                }
                return true
            }

            MotionEvent.ACTION_MOVE -> {
                if (event.pointerCount >= 2 && !state.isPlaying) {
                    wasMultiTouch = true
                    val newDist = pinchDistance(event)
                    if (prevPinchDist > 5f) {
                        val scaleFactor = prevPinchDist / newDist.coerceAtLeast(5f)
                        camDistance = (camDistance * scaleFactor).coerceIn(4f, 65f)
                    }
                    val midX = (event.getX(0) + event.getX(1)) * 0.5f
                    val midY = (event.getY(0) + event.getY(1)) * 0.5f
                    val panDx = midX - prevMidX
                    val panDy = midY - prevMidY
                    val yawRad = Math.toRadians(camYaw.toDouble())
                    val rightX = cos(yawRad).toFloat()
                    val rightZ = -sin(yawRad).toFloat()
                    val panSpeed = camDistance * 0.0014f
                    camTarget = Vec3(
                        camTarget.x - rightX * panDx * panSpeed,
                        (camTarget.y + panDy * panSpeed).coerceIn(-10f, 30f),
                        camTarget.z - rightZ * panDx * panSpeed
                    )
                    prevPinchDist = newDist
                    prevMidX = midX
                    prevMidY = midY
                    renderer.setCamera(camYaw, camPitch, camDistance, camTarget)
                } else if (!wasMultiTouch) {
                    val dx = event.x - lastTouchX
                    val dy = event.y - lastTouchY
                    lastTouchX = event.x
                    lastTouchY = event.y

                    if (state.isPlaying) {
                        onPlayLookDelta(-dx * 0.32f)
                        camPitch = (camPitch + dy * 0.25f).coerceIn(-15f, 65f)
                        renderer.setCamera(camYaw, camPitch, camDistance, camTarget)
                    } else if (isDraggingObject) {
                        val selected = state.nodes.firstOrNull { it.id == state.selectedNodeId }
                        if (selected != null) {
                            applyDragTransform(selected, state.activeTool, activeDragAxis ?: state.axisConstraint, state.snapEnabled, dx, dy)
                        }
                    } else if (isOrbiting) {
                        camYaw = (camYaw - dx * 0.35f) % 360f
                        camPitch = (camPitch + dy * 0.32f).coerceIn(-80f, 88f)
                        renderer.setCamera(camYaw, camPitch, camDistance, camTarget)
                    }
                }
                return true
            }

            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                val moveDist = hypot(event.x - downTouchX, event.y - downTouchY)
                val elapsed = System.currentTimeMillis() - downTimeMs

                if (isDraggingObject) {
                    onTransformCommit()
                } else if (!wasMultiTouch && !state.isPlaying && moveDist < 18f && elapsed < 350L) {
                    val ray = RayPicker.screenToRay(
                        event.x, event.y, width, height, renderer.lastViewProjMatrix
                    )
                    if (ray != null) {
                        val hit = RayPicker.pickSceneNode(ray, state.nodes)
                        onSelectNode(hit?.id)
                    }
                }
                isDraggingObject = false
                isOrbiting = false
                activeDragAxis = null
                return true
            }
        }
        return super.onTouchEvent(event)
    }

    private fun applyDragTransform(
        node: SceneNode,
        tool: EditorTool,
        axis: AxisConstraint,
        snap: Boolean,
        dx: Float,
        dy: Float
    ) {
        val sensitivity = (camDistance * 0.0028f).coerceIn(0.01f, 0.12f)
        val yawRad = Math.toRadians(camYaw.toDouble())
        val rightX = cos(yawRad).toFloat()
        val rightZ = -sin(yawRad).toFloat()
        val fwdX = -sin(yawRad).toFloat()
        val fwdZ = -cos(yawRad).toFloat()

        fun maybeSnap(v: Float, step: Float): Float =
            if (snap) (v / step).roundToInt() * step else v

        var pos = node.position
        var rot = node.rotation
        var scale = node.scale

        when (tool) {
            EditorTool.MOVE -> {
                when (axis) {
                    AxisConstraint.X -> pos = pos.copy(x = maybeSnap(pos.x + dx * sensitivity * rightX - dy * sensitivity * fwdX, 0.5f))
                    AxisConstraint.Y -> pos = pos.copy(y = maybeSnap(pos.y - dy * sensitivity, 0.5f))
                    AxisConstraint.Z -> pos = pos.copy(z = maybeSnap(pos.z + dx * sensitivity * rightZ - dy * sensitivity * fwdZ, 0.5f))
                    AxisConstraint.FREE -> {
                        val nx = pos.x + dx * sensitivity * rightX - dy * sensitivity * fwdX
                        val nz = pos.z + dx * sensitivity * rightZ - dy * sensitivity * fwdZ
                        pos = pos.copy(x = maybeSnap(nx, 0.5f), z = maybeSnap(nz, 0.5f))
                    }
                }
            }
            EditorTool.ROTATE -> {
                val rotSens = 0.65f
                when (axis) {
                    AxisConstraint.X -> rot = rot.copy(x = maybeSnap((rot.x + dy * rotSens) % 360f, 15f))
                    AxisConstraint.Y -> rot = rot.copy(y = maybeSnap((rot.y + dx * rotSens) % 360f, 15f))
                    AxisConstraint.Z -> rot = rot.copy(z = maybeSnap((rot.z - dx * rotSens) % 360f, 15f))
                    AxisConstraint.FREE -> rot = rot.copy(y = maybeSnap((rot.y + dx * rotSens) % 360f, 15f))
                }
            }
            EditorTool.SCALE -> {
                val sSens = 0.015f
                val delta = (dx - dy) * sSens
                when (axis) {
                    AxisConstraint.X -> scale = scale.copy(x = maybeSnap((scale.x + dx * sSens).coerceIn(0.1f, 80f), 0.25f))
                    AxisConstraint.Y -> scale = scale.copy(y = maybeSnap((scale.y - dy * sSens).coerceIn(0.1f, 80f), 0.25f))
                    AxisConstraint.Z -> scale = scale.copy(z = maybeSnap((scale.z + dx * sSens).coerceIn(0.1f, 80f), 0.25f))
                    AxisConstraint.FREE -> {
                        scale = Vec3(
                            maybeSnap((scale.x + delta).coerceIn(0.1f, 80f), 0.25f),
                            maybeSnap((scale.y + delta).coerceIn(0.1f, 80f), 0.25f),
                            maybeSnap((scale.z + delta).coerceIn(0.1f, 80f), 0.25f)
                        )
                    }
                }
            }
            EditorTool.SELECT -> Unit
        }
        onTransformLive(node.id, pos, rot, scale)
    }

    private fun pinchDistance(e: MotionEvent): Float {
        val dx = e.getX(0) - e.getX(1)
        val dy = e.getY(0) - e.getY(1)
        return hypot(dx, dy)
    }

    private inner class ForgeRenderer : Renderer {
        @Volatile
        var currentState: ViewportRenderState = ViewportRenderState()
            private set

        @Volatile
        var lastViewProjMatrix: FloatArray = FloatArray(16)
            private set

        private var rYaw = 38f
        private var rPitch = 28f
        private var rDist = 20f
        private var rTarget = Vec3(0f, 1.5f, 0f)

        private var litProgram = 0
        private var lineProgram = 0

        private var uMvpHandle = 0
        private var uModelHandle = 0
        private var uColorHandle = 0
        private var uLightDirHandle = 0
        private var uAmbientHandle = 0
        private var uSunHandle = 0
        private var uEmissiveHandle = 0
        private var uSpecPowerHandle = 0
        private var uCamPosHandle = 0
        private var aPosHandle = 0
        private var aNormHandle = 0

        private var uLineMvpHandle = 0
        private var uLineColorHandle = 0
        private var aLinePosHandle = 0

        private lateinit var gridBuffer: FloatBuffer
        private var gridVertexCount = 0
        private lateinit var boxWireBuffer: FloatBuffer
        private lateinit var circleWireBuffer: FloatBuffer
        private var circleVertexCount = 0

        private val projMatrix = FloatArray(16)
        private val viewMatrix = FloatArray(16)
        private val viewProjMatrix = FloatArray(16)
        private val modelMatrix = FloatArray(16)
        private val mvpMatrix = FloatArray(16)

        private var frameCounter = 0
        private var lastFpsTimestamp = System.currentTimeMillis()

        fun updateState(state: ViewportRenderState) {
            currentState = state
        }

        fun setCamera(yaw: Float, pitch: Float, dist: Float, target: Vec3) {
            rYaw = yaw
            rPitch = pitch
            rDist = dist
            rTarget = target
        }

        override fun onSurfaceCreated(gl: GL10?, config: EGLConfig?) {
            GLES20.glEnable(GLES20.GL_DEPTH_TEST)
            GLES20.glDepthFunc(GLES20.GL_LEQUAL)
            GLES20.glEnable(GLES20.GL_BLEND)
            GLES20.glBlendFunc(GLES20.GL_SRC_ALPHA, GLES20.GL_ONE_MINUS_SRC_ALPHA)

            litProgram = buildProgram(LIT_VERTEX_SHADER, LIT_FRAGMENT_SHADER)
            uMvpHandle = GLES20.glGetUniformLocation(litProgram, "uMVP")
            uModelHandle = GLES20.glGetUniformLocation(litProgram, "uModel")
            uColorHandle = GLES20.glGetUniformLocation(litProgram, "uColor")
            uLightDirHandle = GLES20.glGetUniformLocation(litProgram, "uLightDir")
            uAmbientHandle = GLES20.glGetUniformLocation(litProgram, "uAmbient")
            uSunHandle = GLES20.glGetUniformLocation(litProgram, "uSun")
            uEmissiveHandle = GLES20.glGetUniformLocation(litProgram, "uEmissive")
            uSpecPowerHandle = GLES20.glGetUniformLocation(litProgram, "uSpecPower")
            uCamPosHandle = GLES20.glGetUniformLocation(litProgram, "uCamPos")
            aPosHandle = GLES20.glGetAttribLocation(litProgram, "aPosition")
            aNormHandle = GLES20.glGetAttribLocation(litProgram, "aNormal")

            lineProgram = buildProgram(LINE_VERTEX_SHADER, LINE_FRAGMENT_SHADER)
            uLineMvpHandle = GLES20.glGetUniformLocation(lineProgram, "uMVP")
            uLineColorHandle = GLES20.glGetUniformLocation(lineProgram, "uColor")
            aLinePosHandle = GLES20.glGetAttribLocation(lineProgram, "aPosition")

            initStaticBuffers()
        }

        override fun onSurfaceChanged(gl: GL10?, width: Int, height: Int) {
            GLES20.glViewport(0, 0, width, height)
            val aspect = width.toFloat() / height.coerceAtLeast(1).toFloat()
            Matrix.perspectiveM(projMatrix, 0, 48f, aspect, 0.25f, 220f)
        }

        override fun onDrawFrame(gl: GL10?) {
            val state = currentState
            val skyColor = parseHexColor(state.lighting.skyColorHex, 0x11, 0x16, 0x29)
            GLES20.glClearColor(skyColor[0], skyColor[1], skyColor[2], 1f)
            GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT or GLES20.GL_DEPTH_BUFFER_BIT)

            val camEye = computeCameraAndViewMatrix(state)
            Matrix.multiplyMM(viewProjMatrix, 0, projMatrix, 0, viewMatrix, 0)
            lastViewProjMatrix = viewProjMatrix.clone()

            if (state.showGrid) {
                drawGrid()
            }

            drawSceneNodes(state, camEye)

            if (state.isPlaying && state.playCameraMode == PlayCameraMode.THIRD_PERSON) {
                drawPlayerAvatar(state, camEye)
            }

            if (!state.isPlaying && state.selectedNodeId != null) {
                val selected = state.nodes.firstOrNull { it.id == state.selectedNodeId && !it.isFolder && it.visible }
                if (selected != null) {
                    drawSelectionBox(selected, 0.23f, 0.51f, 0.96f, 1f)
                    if (state.activeTool != EditorTool.SELECT) {
                        drawTransformGizmo(selected, state.activeTool, camEye)
                    }
                }
            }

            if (state.showCollisions) {
                for (node in state.nodes) {
                    if (!node.isFolder && node.visible && node.canCollide) {
                        drawSelectionBox(node, 0.06f, 0.72f, 0.50f, 0.7f)
                    }
                }
            }

            frameCounter++
            val now = System.currentTimeMillis()
            if (now - lastFpsTimestamp >= 500L) {
                val fps = ((frameCounter * 1000f) / (now - lastFpsTimestamp)).roundToInt()
                frameCounter = 0
                lastFpsTimestamp = now
                post { onFpsMeasured(fps) }
            }
        }

        private fun computeCameraAndViewMatrix(state: ViewportRenderState): FloatArray {
            if (state.isPlaying) {
                val p = state.playerPosition
                val yawRad = Math.toRadians(state.playerYaw.toDouble())
                return if (state.playCameraMode == PlayCameraMode.FIRST_PERSON) {
                    val eyeX = p.x
                    val eyeY = p.y + 1.55f
                    val eyeZ = p.z
                    val lookX = eyeX + sin(yawRad).toFloat() * 5f
                    val lookY = eyeY - sin(Math.toRadians(rPitch.toDouble())).toFloat() * 2.5f
                    val lookZ = eyeZ + cos(yawRad).toFloat() * 5f
                    Matrix.setLookAtM(viewMatrix, 0, eyeX, eyeY, eyeZ, lookX, lookY, lookZ, 0f, 1f, 0f)
                    floatArrayOf(eyeX, eyeY, eyeZ)
                } else {
                    val backDist = 7.5f
                    val pitchRad = Math.toRadians(rPitch.coerceIn(10f, 60f).toDouble())
                    val eyeX = p.x - (sin(yawRad) * cos(pitchRad) * backDist).toFloat()
                    val eyeY = p.y + 1.8f + (sin(pitchRad) * backDist).toFloat()
                    val eyeZ = p.z - (cos(yawRad) * cos(pitchRad) * backDist).toFloat()
                    Matrix.setLookAtM(viewMatrix, 0, eyeX, eyeY, eyeZ, p.x, p.y + 1.1f, p.z, 0f, 1f, 0f)
                    floatArrayOf(eyeX, eyeY, eyeZ)
                }
            } else {
                val yawRad = Math.toRadians(rYaw.toDouble())
                val pitchRad = Math.toRadians(rPitch.toDouble())
                val eyeX = rTarget.x + (rDist * cos(pitchRad) * sin(yawRad)).toFloat()
                val eyeY = rTarget.y + (rDist * sin(pitchRad)).toFloat()
                val eyeZ = rTarget.z + (rDist * cos(pitchRad) * cos(yawRad)).toFloat()
                Matrix.setLookAtM(viewMatrix, 0, eyeX, eyeY, eyeZ, rTarget.x, rTarget.y, rTarget.z, 0f, 1f, 0f)
                return floatArrayOf(eyeX, eyeY, eyeZ)
            }
        }

        private fun drawGrid() {
            GLES20.glUseProgram(lineProgram)
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.multiplyMM(mvpMatrix, 0, viewProjMatrix, 0, modelMatrix, 0)
            GLES20.glUniformMatrix4fv(uLineMvpHandle, 1, false, mvpMatrix, 0)
            GLES20.glUniform4f(uLineColorHandle, 0.20f, 0.25f, 0.38f, 0.65f)
            GLES20.glLineWidth(1.5f)
            GLES20.glEnableVertexAttribArray(aLinePosHandle)
            GLES20.glVertexAttribPointer(aLinePosHandle, 3, GLES20.GL_FLOAT, false, 0, gridBuffer)
            GLES20.glDrawArrays(GLES20.GL_LINES, 0, gridVertexCount)
            GLES20.glDisableVertexAttribArray(aLinePosHandle)
        }

        private fun drawSceneNodes(state: ViewportRenderState, camEye: FloatArray) {
            val opaque = state.nodes.filter { !it.isFolder && it.visible && it.transparency <= 0.02f && it.material != ForgeMaterial.GLASS }
            val transparent = state.nodes.filter { !it.isFolder && it.visible && (it.transparency > 0.02f || it.material == ForgeMaterial.GLASS) }

            GLES20.glUseProgram(litProgram)
            GLES20.glUniform3f(uLightDirHandle, 0.55f, 0.85f, 0.42f)
            GLES20.glUniform1f(uAmbientHandle, state.lighting.ambientIntensity)
            GLES20.glUniform1f(uSunHandle, state.lighting.sunIntensity)
            GLES20.glUniform3f(uCamPosHandle, camEye[0], camEye[1], camEye[2])

            for (node in opaque) {
                drawSingleNode(node, 1f)
            }

            if (transparent.isNotEmpty()) {
                GLES20.glDepthMask(false)
                for (node in transparent) {
                    val alpha = if (node.material == ForgeMaterial.GLASS && node.transparency < 0.25f) 0.55f else (1f - node.transparency)
                    drawSingleNode(node, alpha.coerceIn(0.15f, 0.95f))
                }
                GLES20.glDepthMask(true)
            }
        }

        private fun drawSingleNode(node: SceneNode, alpha: Float) {
            val mesh = ProceduralMeshGenerator.getMesh(node.shape, node.customMesh)
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, node.position.x, node.position.y, node.position.z)
            Matrix.rotateM(modelMatrix, 0, node.rotation.y, 0f, 1f, 0f)
            Matrix.rotateM(modelMatrix, 0, node.rotation.x, 1f, 0f, 0f)
            Matrix.rotateM(modelMatrix, 0, node.rotation.z, 0f, 0f, 1f)
            Matrix.scaleM(
                modelMatrix, 0,
                node.scale.x.coerceAtLeast(0.05f),
                node.scale.y.coerceAtLeast(0.05f),
                node.scale.z.coerceAtLeast(0.05f)
            )
            Matrix.multiplyMM(mvpMatrix, 0, viewProjMatrix, 0, modelMatrix, 0)

            val rgb = parseHexColor(node.colorHex, 0x3B, 0x82, 0xF6)
            GLES20.glUniformMatrix4fv(uMvpHandle, 1, false, mvpMatrix, 0)
            GLES20.glUniformMatrix4fv(uModelHandle, 1, false, modelMatrix, 0)
            GLES20.glUniform4f(uColorHandle, rgb[0], rgb[1], rgb[2], alpha)
            GLES20.glUniform1f(uEmissiveHandle, node.material.emissive)
            GLES20.glUniform1f(uSpecPowerHandle, if (node.material.metallic > 0.5f) 48f else 16f)

            GLES20.glEnableVertexAttribArray(aPosHandle)
            GLES20.glVertexAttribPointer(aPosHandle, 3, GLES20.GL_FLOAT, false, 0, mesh.vertexBuffer)
            GLES20.glEnableVertexAttribArray(aNormHandle)
            GLES20.glVertexAttribPointer(aNormHandle, 3, GLES20.GL_FLOAT, false, 0, mesh.normalBuffer)

            GLES20.glDrawElements(GLES20.GL_TRIANGLES, mesh.indexCount, GLES20.GL_UNSIGNED_SHORT, mesh.indexBuffer)

            GLES20.glDisableVertexAttribArray(aPosHandle)
            GLES20.glDisableVertexAttribArray(aNormHandle)
        }

        private fun drawPlayerAvatar(state: ViewportRenderState, camEye: FloatArray) {
            val p = state.playerPosition
            val swing = sin(state.playerWalkCycle) * 28f
            val parts = listOf(
                // Torso
                Triple(Vec3(0f, 1.05f, 0f), Vec3(0f, 0f, 0f), Vec3(0.75f, 0.9f, 0.42f)) to "#3B82F6",
                // Head
                Triple(Vec3(0f, 1.78f, 0f), Vec3(0f, 0f, 0f), Vec3(0.55f, 0.55f, 0.55f)) to "#FDE68A",
                // Left Arm
                Triple(Vec3(-0.56f, 1.05f, 0f), Vec3(swing, 0f, 0f), Vec3(0.30f, 0.82f, 0.32f)) to "#60A5FA",
                // Right Arm
                Triple(Vec3(0.56f, 1.05f, 0f), Vec3(-swing, 0f, 0f), Vec3(0.30f, 0.82f, 0.32f)) to "#60A5FA",
                // Left Leg
                Triple(Vec3(-0.20f, 0.38f, 0f), Vec3(-swing, 0f, 0f), Vec3(0.33f, 0.76f, 0.36f)) to "#1E293B",
                // Right Leg
                Triple(Vec3(0.20f, 0.38f, 0f), Vec3(swing, 0f, 0f), Vec3(0.33f, 0.76f, 0.36f)) to "#1E293B"
            )

            GLES20.glUseProgram(litProgram)
            GLES20.glUniform3f(uCamPosHandle, camEye[0], camEye[1], camEye[2])
            val mesh = ProceduralMeshGenerator.getMesh(SceneShape.BOX)
            val yawRad = Math.toRadians(state.playerYaw.toDouble())
            val cosY = cos(yawRad).toFloat()
            val sinY = sin(yawRad).toFloat()

            for ((geom, colorHex) in parts) {
                val (localPos, localRot, scale) = geom
                val wx = p.x + localPos.x * cosY + localPos.z * sinY
                val wz = p.z - localPos.x * sinY + localPos.z * cosY
                Matrix.setIdentityM(modelMatrix, 0)
                Matrix.translateM(modelMatrix, 0, wx, p.y + localPos.y, wz)
                Matrix.rotateM(modelMatrix, 0, state.playerYaw, 0f, 1f, 0f)
                Matrix.rotateM(modelMatrix, 0, localRot.x, 1f, 0f, 0f)
                Matrix.scaleM(modelMatrix, 0, scale.x, scale.y, scale.z)
                Matrix.multiplyMM(mvpMatrix, 0, viewProjMatrix, 0, modelMatrix, 0)

                val rgb = parseHexColor(colorHex, 0x3B, 0x82, 0xF6)
                GLES20.glUniformMatrix4fv(uMvpHandle, 1, false, mvpMatrix, 0)
                GLES20.glUniformMatrix4fv(uModelHandle, 1, false, modelMatrix, 0)
                GLES20.glUniform4f(uColorHandle, rgb[0], rgb[1], rgb[2], 1f)
                GLES20.glUniform1f(uEmissiveHandle, 0.05f)
                GLES20.glUniform1f(uSpecPowerHandle, 16f)

                GLES20.glEnableVertexAttribArray(aPosHandle)
                GLES20.glVertexAttribPointer(aPosHandle, 3, GLES20.GL_FLOAT, false, 0, mesh.vertexBuffer)
                GLES20.glEnableVertexAttribArray(aNormHandle)
                GLES20.glVertexAttribPointer(aNormHandle, 3, GLES20.GL_FLOAT, false, 0, mesh.normalBuffer)
                GLES20.glDrawElements(GLES20.GL_TRIANGLES, mesh.indexCount, GLES20.GL_UNSIGNED_SHORT, mesh.indexBuffer)
                GLES20.glDisableVertexAttribArray(aPosHandle)
                GLES20.glDisableVertexAttribArray(aNormHandle)
            }
        }

        private fun drawSelectionBox(node: SceneNode, r: Float, g: Float, b: Float, a: Float) {
            GLES20.glUseProgram(lineProgram)
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, node.position.x, node.position.y, node.position.z)
            Matrix.rotateM(modelMatrix, 0, node.rotation.y, 0f, 1f, 0f)
            Matrix.rotateM(modelMatrix, 0, node.rotation.x, 1f, 0f, 0f)
            Matrix.rotateM(modelMatrix, 0, node.rotation.z, 0f, 0f, 1f)
            Matrix.scaleM(
                modelMatrix, 0,
                node.scale.x.coerceAtLeast(0.05f) * 1.03f,
                node.scale.y.coerceAtLeast(0.05f) * 1.03f,
                node.scale.z.coerceAtLeast(0.05f) * 1.03f
            )
            Matrix.multiplyMM(mvpMatrix, 0, viewProjMatrix, 0, modelMatrix, 0)
            GLES20.glUniformMatrix4fv(uLineMvpHandle, 1, false, mvpMatrix, 0)
            GLES20.glUniform4f(uLineColorHandle, r, g, b, a)
            GLES20.glLineWidth(3f)
            GLES20.glEnableVertexAttribArray(aLinePosHandle)
            GLES20.glVertexAttribPointer(aLinePosHandle, 3, GLES20.GL_FLOAT, false, 0, boxWireBuffer)
            GLES20.glDrawArrays(GLES20.GL_LINES, 0, 24)
            GLES20.glDisableVertexAttribArray(aLinePosHandle)
        }

        private fun drawTransformGizmo(node: SceneNode, tool: EditorTool, camEye: FloatArray) {
            val dx = camEye[0] - node.position.x
            val dy = camEye[1] - node.position.y
            val dz = camEye[2] - node.position.z
            val dist = sqrt(dx * dx + dy * dy + dz * dz).coerceAtLeast(1f)
            val gizmoLen = (dist * 0.16f).coerceIn(1.5f, 4.5f)

            GLES20.glDisable(GLES20.GL_DEPTH_TEST)
            val p = node.position

            if (tool == EditorTool.ROTATE) {
                GLES20.glUseProgram(lineProgram)
                GLES20.glLineWidth(4.5f)
                // Y ring (green)
                drawCircleGizmo(p, gizmoLen * 0.85f, 0f, 0f, 0f, 0.13f, 0.90f, 0.52f)
                // X ring (red)
                drawCircleGizmo(p, gizmoLen * 0.85f, 0f, 0f, 90f, 1.0f, 0.30f, 0.42f)
                // Z ring (blue)
                drawCircleGizmo(p, gizmoLen * 0.85f, 90f, 0f, 0f, 0.22f, 0.60f, 1.0f)
            } else {
                val handleShape = if (tool == EditorTool.SCALE) SceneShape.BOX else SceneShape.CONE
                val tipSize = gizmoLen * 0.22f
                val shaftThickness = gizmoLen * 0.045f

                GLES20.glUseProgram(litProgram)
                GLES20.glUniform1f(uAmbientHandle, 0.9f)
                GLES20.glUniform1f(uSunHandle, 0.3f)
                GLES20.glUniform1f(uEmissiveHandle, 0.7f)
                GLES20.glUniform1f(uSpecPowerHandle, 8f)

                // X axis (Red)
                drawGizmoPart(SceneShape.BOX, Vec3(p.x + gizmoLen * 0.5f, p.y, p.z), Vec3(0f, 0f, 0f), Vec3(gizmoLen, shaftThickness, shaftThickness), 1.0f, 0.30f, 0.42f)
                drawGizmoPart(handleShape, Vec3(p.x + gizmoLen, p.y, p.z), Vec3(0f, 0f, -90f), Vec3(tipSize, tipSize * 1.4f, tipSize), 1.0f, 0.30f, 0.42f)

                // Y axis (Green)
                drawGizmoPart(SceneShape.BOX, Vec3(p.x, p.y + gizmoLen * 0.5f, p.z), Vec3(0f, 0f, 0f), Vec3(shaftThickness, gizmoLen, shaftThickness), 0.13f, 0.90f, 0.52f)
                drawGizmoPart(handleShape, Vec3(p.x, p.y + gizmoLen, p.z), Vec3(0f, 0f, 0f), Vec3(tipSize, tipSize * 1.4f, tipSize), 0.13f, 0.90f, 0.52f)

                // Z axis (Blue)
                drawGizmoPart(SceneShape.BOX, Vec3(p.x, p.y, p.z + gizmoLen * 0.5f), Vec3(0f, 0f, 0f), Vec3(shaftThickness, shaftThickness, gizmoLen), 0.22f, 0.60f, 1.0f)
                drawGizmoPart(handleShape, Vec3(p.x, p.y, p.z + gizmoLen), Vec3(90f, 0f, 0f), Vec3(tipSize, tipSize * 1.4f, tipSize), 0.22f, 0.60f, 1.0f)
            }
            GLES20.glEnable(GLES20.GL_DEPTH_TEST)
        }

        private fun drawCircleGizmo(
            center: Vec3, radius: Float,
            rx: Float, ry: Float, rz: Float,
            r: Float, g: Float, b: Float
        ) {
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, center.x, center.y, center.z)
            Matrix.rotateM(modelMatrix, 0, rx, 1f, 0f, 0f)
            Matrix.rotateM(modelMatrix, 0, ry, 0f, 1f, 0f)
            Matrix.rotateM(modelMatrix, 0, rz, 0f, 0f, 1f)
            Matrix.scaleM(modelMatrix, 0, radius, radius, radius)
            Matrix.multiplyMM(mvpMatrix, 0, viewProjMatrix, 0, modelMatrix, 0)

            GLES20.glUniformMatrix4fv(uLineMvpHandle, 1, false, mvpMatrix, 0)
            GLES20.glUniform4f(uLineColorHandle, r, g, b, 1f)
            GLES20.glEnableVertexAttribArray(aLinePosHandle)
            GLES20.glVertexAttribPointer(aLinePosHandle, 3, GLES20.GL_FLOAT, false, 0, circleWireBuffer)
            GLES20.glDrawArrays(GLES20.GL_LINE_LOOP, 0, circleVertexCount)
            GLES20.glDisableVertexAttribArray(aLinePosHandle)
        }

        private fun drawGizmoPart(
            shape: SceneShape, pos: Vec3, rot: Vec3, scale: Vec3,
            r: Float, g: Float, b: Float
        ) {
            val mesh = ProceduralMeshGenerator.getMesh(shape)
            Matrix.setIdentityM(modelMatrix, 0)
            Matrix.translateM(modelMatrix, 0, pos.x, pos.y, pos.z)
            Matrix.rotateM(modelMatrix, 0, rot.x, 1f, 0f, 0f)
            Matrix.rotateM(modelMatrix, 0, rot.y, 0f, 1f, 0f)
            Matrix.rotateM(modelMatrix, 0, rot.z, 0f, 0f, 1f)
            Matrix.scaleM(modelMatrix, 0, scale.x, scale.y, scale.z)
            Matrix.multiplyMM(mvpMatrix, 0, viewProjMatrix, 0, modelMatrix, 0)

            GLES20.glUniformMatrix4fv(uMvpHandle, 1, false, mvpMatrix, 0)
            GLES20.glUniformMatrix4fv(uModelHandle, 1, false, modelMatrix, 0)
            GLES20.glUniform4f(uColorHandle, r, g, b, 1f)
            GLES20.glEnableVertexAttribArray(aPosHandle)
            GLES20.glVertexAttribPointer(aPosHandle, 3, GLES20.GL_FLOAT, false, 0, mesh.vertexBuffer)
            GLES20.glEnableVertexAttribArray(aNormHandle)
            GLES20.glVertexAttribPointer(aNormHandle, 3, GLES20.GL_FLOAT, false, 0, mesh.normalBuffer)
            GLES20.glDrawElements(GLES20.GL_TRIANGLES, mesh.indexCount, GLES20.GL_UNSIGNED_SHORT, mesh.indexBuffer)
            GLES20.glDisableVertexAttribArray(aPosHandle)
            GLES20.glDisableVertexAttribArray(aNormHandle)
        }

        private fun initStaticBuffers() {
            val gridLines = mutableListOf<Float>()
            val extent = 20
            for (i in -extent..extent) {
                val f = i.toFloat()
                gridLines.addAll(listOf(f, 0f, -extent.toFloat(), f, 0f, extent.toFloat()))
                gridLines.addAll(listOf(-extent.toFloat(), 0f, f, extent.toFloat(), 0f, f))
            }
            gridVertexCount = gridLines.size / 3
            gridBuffer = ByteBuffer.allocateDirect(gridLines.size * 4)
                .order(ByteOrder.nativeOrder()).asFloatBuffer()
                .apply { put(gridLines.toFloatArray()); position(0) }

            val h = 0.5f
            val boxLines = floatArrayOf(
                -h, -h, -h,  h, -h, -h,   h, -h, -h,  h, -h,  h,   h, -h,  h, -h, -h,  h,  -h, -h,  h, -h, -h, -h,
                -h,  h, -h,  h,  h, -h,   h,  h, -h,  h,  h,  h,   h,  h,  h, -h,  h,  h,  -h,  h,  h, -h,  h, -h,
                -h, -h, -h, -h,  h, -h,   h, -h, -h,  h,  h, -h,   h, -h,  h,  h,  h,  h,  -h, -h,  h, -h,  h,  h
            )
            boxWireBuffer = ByteBuffer.allocateDirect(boxLines.size * 4)
                .order(ByteOrder.nativeOrder()).asFloatBuffer()
                .apply { put(boxLines); position(0) }

            val segs = 36
            val cVerts = FloatArray(segs * 3)
            for (i in 0 until segs) {
                val a = 2.0 * PI * i / segs
                cVerts[i * 3] = cos(a).toFloat()
                cVerts[i * 3 + 1] = 0f
                cVerts[i * 3 + 2] = sin(a).toFloat()
            }
            circleVertexCount = segs
            circleWireBuffer = ByteBuffer.allocateDirect(cVerts.size * 4)
                .order(ByteOrder.nativeOrder()).asFloatBuffer()
                .apply { put(cVerts); position(0) }
        }

        private fun parseHexColor(hex: String, defR: Int, defG: Int, defB: Int): FloatArray {
            return try {
                val c = Color.parseColor(if (hex.startsWith("#")) hex else "#$hex")
                floatArrayOf(Color.red(c) / 255f, Color.green(c) / 255f, Color.blue(c) / 255f)
            } catch (_: Exception) {
                floatArrayOf(defR / 255f, defG / 255f, defB / 255f)
            }
        }

        private fun buildProgram(vertSrc: String, fragSrc: String): Int {
            val vs = compileShader(GLES20.GL_VERTEX_SHADER, vertSrc)
            val fs = compileShader(GLES20.GL_FRAGMENT_SHADER, fragSrc)
            val prog = GLES20.glCreateProgram()
            GLES20.glAttachShader(prog, vs)
            GLES20.glAttachShader(prog, fs)
            GLES20.glLinkProgram(prog)
            return prog
        }

        private fun compileShader(type: Int, src: String): Int {
            val shader = GLES20.glCreateShader(type)
            GLES20.glShaderSource(shader, src)
            GLES20.glCompileShader(shader)
            return shader
        }
    }

    companion object {
        private const val LIT_VERTEX_SHADER = """
            uniform mat4 uMVP;
            uniform mat4 uModel;
            attribute vec3 aPosition;
            attribute vec3 aNormal;
            varying vec3 vWorldNormal;
            varying vec3 vWorldPos;
            void main() {
                vec4 wp = uModel * vec4(aPosition, 1.0);
                vWorldPos = wp.xyz;
                vWorldNormal = normalize(mat3(uModel) * aNormal);
                gl_Position = uMVP * vec4(aPosition, 1.0);
            }
        """

        private const val LIT_FRAGMENT_SHADER = """
            precision mediump float;
            uniform vec4 uColor;
            uniform vec3 uLightDir;
            uniform float uAmbient;
            uniform float uSun;
            uniform float uEmissive;
            uniform float uSpecPower;
            uniform vec3 uCamPos;
            varying vec3 vWorldNormal;
            varying vec3 vWorldPos;
            void main() {
                vec3 n = normalize(vWorldNormal);
                vec3 l = normalize(uLightDir);
                vec3 v = normalize(uCamPos - vWorldPos);
                vec3 h = normalize(l + v);
                float diff = max(dot(n, l), 0.0);
                float rim = pow(1.0 - max(dot(n, v), 0.0), 2.5) * 0.18;
                float spec = pow(max(dot(n, h), 0.0), uSpecPower) * 0.28;
                float lit = max(uAmbient + diff * uSun + rim, uEmissive);
                vec3 rgb = uColor.rgb * lit + vec3(spec);
                gl_FragColor = vec4(clamp(rgb, 0.0, 1.0), uColor.a);
            }
        """

        private const val LINE_VERTEX_SHADER = """
            uniform mat4 uMVP;
            attribute vec3 aPosition;
            void main() {
                gl_Position = uMVP * vec4(aPosition, 1.0);
            }
        """

        private const val LINE_FRAGMENT_SHADER = """
            precision mediump float;
            uniform vec4 uColor;
            void main() {
                gl_FragColor = uColor;
            }
        """
    }
}
