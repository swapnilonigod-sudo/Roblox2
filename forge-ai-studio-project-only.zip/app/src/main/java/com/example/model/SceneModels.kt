package com.example.model

import androidx.annotation.Keep
import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.IgnoreExtraProperties
import java.util.UUID

enum class SceneShape(val label: String, val robloxHint: String) {
    BOX("Part (Block)", "Part / Block"),
    SPHERE("Sphere", "Part / Ball"),
    CYLINDER("Cylinder", "Part / Cylinder"),
    CONE("Cone / Roof", "MeshPart / Cone"),
    WEDGE("Wedge / Ramp", "WedgePart"),
    TORUS("Ring / Torus", "MeshPart / Torus"),
    TERRAIN_PLANE("Terrain Patch", "Terrain / MeshPart"),
    CUSTOM_MESH("Custom Mesh", "MeshPart")
}

enum class NodeKind(val label: String) {
    FOLDER("Folder"),
    PART("Part"),
    TERRAIN("Terrain"),
    BUILDING("Building"),
    TREE("Tree"),
    PROP("Prop"),
    FURNITURE("Furniture"),
    DECORATION("Decoration"),
    NPC("NPC"),
    LIGHT("Light"),
    IMPORTED_MESH("Imported")
}

enum class ForgeMaterial(
    val label: String,
    val robloxEnum: String,
    val roughness: Float,
    val metallic: Float,
    val emissive: Float
) {
    SMOOTH_PLASTIC("Smooth Plastic", "Enum.Material.SmoothPlastic", 0.35f, 0.0f, 0.0f),
    WOOD("Wood", "Enum.Material.Wood", 0.72f, 0.0f, 0.0f),
    BRICK("Brick", "Enum.Material.Brick", 0.85f, 0.0f, 0.0f),
    METAL("Metal", "Enum.Material.Metal", 0.25f, 0.85f, 0.0f),
    NEON("Neon", "Enum.Material.Neon", 0.20f, 0.0f, 0.75f),
    GLASS("Glass", "Enum.Material.Glass", 0.12f, 0.1f, 0.0f),
    ROCK("Rock", "Enum.Material.Rock", 0.90f, 0.0f, 0.0f),
    GRASS("Grass", "Enum.Material.Grass", 0.88f, 0.0f, 0.0f),
    SAND("Sand", "Enum.Material.Sand", 0.92f, 0.0f, 0.0f),
    LAVA("Cracked Lava", "Enum.Material.CrackedLava", 0.45f, 0.0f, 0.55f);

    companion object {
        fun fromRaw(raw: String?): ForgeMaterial =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: SMOOTH_PLASTIC
    }
}

enum class TimeOfDay(val label: String, val skyHex: String, val ambient: Float, val sun: Float) {
    DAWN("Dawn", "#1E2238", 0.45f, 0.80f),
    DAY("Daylight", "#284066", 0.58f, 1.15f),
    DUSK("Cyber Dusk", "#111629", 0.42f, 0.92f),
    NIGHT("Midnight", "#080B14", 0.26f, 0.45f);

    companion object {
        fun fromRaw(raw: String?): TimeOfDay =
            entries.firstOrNull { it.name.equals(raw, ignoreCase = true) } ?: DUSK
    }
}

enum class EditorTool(val label: String) {
    SELECT("Select"),
    MOVE("Move"),
    ROTATE("Rotate"),
    SCALE("Scale")
}

enum class AxisConstraint(val label: String) {
    FREE("Free"),
    X("X"),
    Y("Y"),
    Z("Z")
}

enum class CameraPreset(val label: String) {
    PERSPECTIVE("Persp"),
    TOP("Top"),
    FRONT("Front"),
    SIDE("Side"),
    ISOMETRIC("Iso")
}

enum class PlayCameraMode(val label: String) {
    THIRD_PERSON("3rd Person"),
    FIRST_PERSON("1st Person")
}

enum class LogLevel(val label: String) {
    INFO("INFO"),
    WARN("WARN"),
    ERROR("ERR"),
    AI("AI")
}

enum class AiModelChoice(val modelId: String, val displayName: String, val tierHint: String) {
    GEMINI_3_8_FLASH("gemini-3.8-flash", "Gemini 3.8 Flash", "Default • Fast & Capable"),
    GEMINI_4_ARGON("gemini-4-argon", "Gemini 4 Argon", "Deep Reasoning • Blaze Plan"),
    GEMINI_3_5_FLASH_LITE("gemini-3.5-flash-lite", "Gemini 3.5 Flash-Lite", "Ultra Fast • Lightweight");

    companion object {
        fun fromId(id: String?): AiModelChoice =
            entries.firstOrNull { it.modelId == id } ?: GEMINI_3_8_FLASH
    }
}

enum class ImageModelChoice(val modelId: String, val displayName: String) {
    NANO_BANANA_2_1("gemini-nano-banana-2.1", "Nano Banana 2.1 (Fast)"),
    GEMINI_3_PRO_IMAGE("gemini-3-pro-image", "Gemini 3 Pro Image (Studio)");

    companion object {
        fun fromId(id: String?): ImageModelChoice =
            entries.firstOrNull { it.modelId == id } ?: NANO_BANANA_2_1
    }
}

enum class ImageResolutionOption(val label: String) {
    RES_1K("1K"),
    RES_2K("2K"),
    RES_4K("4K")
}

enum class ImageAspectOption(val label: String) {
    RATIO_1_1("1:1"),
    RATIO_16_9("16:9"),
    RATIO_9_16("9:16"),
    RATIO_4_3("4:3"),
    RATIO_3_4("3:4"),
    RATIO_3_2("3:2"),
    RATIO_2_3("2:3")
}

data class Vec3(val x: Float = 0f, val y: Float = 0f, val z: Float = 0f)

data class CustomMeshData(
    val vertices: List<Float>,
    val normals: List<Float>,
    val indices: List<Int>,
    val triangleCount: Int
)

data class SceneNode(
    val id: String = UUID.randomUUID().toString().take(12),
    val name: String = "Part",
    val kind: NodeKind = NodeKind.PART,
    val shape: SceneShape = SceneShape.BOX,
    val parentId: String = WORKSPACE_ROOT_ID,
    val position: Vec3 = Vec3(0f, 0.5f, 0f),
    val rotation: Vec3 = Vec3(0f, 0f, 0f),
    val scale: Vec3 = Vec3(2f, 1f, 2f),
    val colorHex: String = "#3B82F6",
    val material: ForgeMaterial = ForgeMaterial.SMOOTH_PLASTIC,
    val visible: Boolean = true,
    val canCollide: Boolean = true,
    val anchored: Boolean = true,
    val transparency: Float = 0f,
    val expanded: Boolean = true,
    val customMesh: CustomMeshData? = null
) {
    val isFolder: Boolean get() = kind == NodeKind.FOLDER

    fun toFirestoreMap(): Map<String, Any> {
        val map = mutableMapOf<String, Any>(
            "id" to id,
            "name" to name.take(64),
            "kind" to kind.name,
            "shape" to shape.name,
            "parentId" to parentId,
            "px" to position.x.toDouble(),
            "py" to position.y.toDouble(),
            "pz" to position.z.toDouble(),
            "rx" to rotation.x.toDouble(),
            "ry" to rotation.y.toDouble(),
            "rz" to rotation.z.toDouble(),
            "sx" to scale.x.toDouble(),
            "sy" to scale.y.toDouble(),
            "sz" to scale.z.toDouble(),
            "colorHex" to colorHex,
            "material" to material.name,
            "visible" to visible,
            "canCollide" to canCollide,
            "anchored" to anchored,
            "transparency" to transparency.toDouble(),
            "expanded" to expanded
        )
        return map
    }

    companion object {
        const val WORKSPACE_ROOT_ID = "workspace"

        fun fromFirestoreMap(raw: Map<*, *>): SceneNode {
            val kindName = raw["kind"] as? String
            val shapeName = raw["shape"] as? String
            return SceneNode(
                id = (raw["id"] as? String)?.ifBlank { null } ?: UUID.randomUUID().toString().take(12),
                name = (raw["name"] as? String) ?: "Part",
                kind = NodeKind.entries.firstOrNull { it.name == kindName } ?: NodeKind.PART,
                shape = SceneShape.entries.firstOrNull { it.name == shapeName } ?: SceneShape.BOX,
                parentId = (raw["parentId"] as? String) ?: WORKSPACE_ROOT_ID,
                position = Vec3(
                    (raw["px"] as? Number)?.toFloat() ?: 0f,
                    (raw["py"] as? Number)?.toFloat() ?: 0.5f,
                    (raw["pz"] as? Number)?.toFloat() ?: 0f
                ),
                rotation = Vec3(
                    (raw["rx"] as? Number)?.toFloat() ?: 0f,
                    (raw["ry"] as? Number)?.toFloat() ?: 0f,
                    (raw["rz"] as? Number)?.toFloat() ?: 0f
                ),
                scale = Vec3(
                    ((raw["sx"] as? Number)?.toFloat() ?: 2f).coerceAtLeast(0.05f),
                    ((raw["sy"] as? Number)?.toFloat() ?: 1f).coerceAtLeast(0.05f),
                    ((raw["sz"] as? Number)?.toFloat() ?: 2f).coerceAtLeast(0.05f)
                ),
                colorHex = (raw["colorHex"] as? String) ?: "#3B82F6",
                material = ForgeMaterial.fromRaw(raw["material"] as? String),
                visible = (raw["visible"] as? Boolean) ?: true,
                canCollide = (raw["canCollide"] as? Boolean) ?: true,
                anchored = (raw["anchored"] as? Boolean) ?: true,
                transparency = (raw["transparency"] as? Number)?.toFloat()?.coerceIn(0f, 0.95f) ?: 0f,
                expanded = (raw["expanded"] as? Boolean) ?: true
            )
        }
    }
}

data class LightingSettings(
    val ambientIntensity: Float = 0.44f,
    val sunIntensity: Float = 0.96f,
    val skyColorHex: String = "#111629",
    val fogEnabled: Boolean = true,
    val timeOfDay: TimeOfDay = TimeOfDay.DUSK
) {
    fun toFirestoreMap(): Map<String, Any> = mapOf(
        "ambientIntensity" to ambientIntensity.toDouble(),
        "sunIntensity" to sunIntensity.toDouble(),
        "skyColorHex" to skyColorHex,
        "fogEnabled" to fogEnabled,
        "timeOfDay" to timeOfDay.name
    )

    companion object {
        fun fromFirestoreMap(raw: Map<*, *>?): LightingSettings {
            if (raw == null) return LightingSettings()
            return LightingSettings(
                ambientIntensity = (raw["ambientIntensity"] as? Number)?.toFloat()?.coerceIn(0.1f, 1.0f) ?: 0.44f,
                sunIntensity = (raw["sunIntensity"] as? Number)?.toFloat()?.coerceIn(0.1f, 1.8f) ?: 0.96f,
                skyColorHex = (raw["skyColorHex"] as? String) ?: "#111629",
                fogEnabled = (raw["fogEnabled"] as? Boolean) ?: true,
                timeOfDay = TimeOfDay.fromRaw(raw["timeOfDay"] as? String)
            )
        }
    }
}

data class LuauScript(
    val id: String = UUID.randomUUID().toString().take(10),
    val name: String = "MainScript.luau",
    val scriptType: String = "Script",
    val parentTarget: String = "ServerScriptService",
    val code: String = ""
) {
    fun toFirestoreMap(): Map<String, Any> = mapOf(
        "id" to id,
        "name" to name.take(64),
        "scriptType" to scriptType,
        "parentTarget" to parentTarget,
        "code" to code.take(15000)
    )

    companion object {
        fun fromFirestoreMap(raw: Map<*, *>): LuauScript = LuauScript(
            id = (raw["id"] as? String)?.ifBlank { null } ?: UUID.randomUUID().toString().take(10),
            name = (raw["name"] as? String) ?: "Script.luau",
            scriptType = (raw["scriptType"] as? String) ?: "Script",
            parentTarget = (raw["parentTarget"] as? String) ?: "ServerScriptService",
            code = (raw["code"] as? String) ?: ""
        )
    }
}

data class ConsoleLog(
    val id: String = UUID.randomUUID().toString().take(8),
    val timestamp: String,
    val level: LogLevel,
    val source: String,
    val message: String
)

data class AiChatMessage(
    val id: String = UUID.randomUUID().toString().take(8),
    val isUser: Boolean,
    val text: String,
    val actionSummary: String? = null
)

data class WorldRegionPlan(
    val regionName: String,
    val folderId: String,
    val theme: String,
    val centerX: Float,
    val centerZ: Float,
    val objectCount: Int
)

@Keep
@IgnoreExtraProperties
data class ForgeProjectSummary(
    val id: String = "",
    val userId: String = "",
    val name: String = "Untitled Project",
    val description: String = "",
    val objectCount: Long = 0L,
    val scriptCount: Long = 0L,
    val lighting: LightingSettings = LightingSettings(),
    val objects: List<SceneNode> = emptyList(),
    val scripts: List<LuauScript> = emptyList(),
    val createdAt: Timestamp? = null,
    val updatedAt: Timestamp? = null
) {
    companion object {
        fun fromSnapshot(doc: DocumentSnapshot): ForgeProjectSummary {
            val lightingMap = doc.get("lighting") as? Map<*, *>
            val rawObjects = doc.get("objects") as? List<*> ?: emptyList<Any>()
            val rawScripts = doc.get("scripts") as? List<*> ?: emptyList<Any>()
            return ForgeProjectSummary(
                id = doc.id,
                userId = doc.getString("userId") ?: "",
                name = doc.getString("name") ?: "Untitled Project",
                description = doc.getString("description") ?: "",
                objectCount = doc.getLong("objectCount") ?: rawObjects.size.toLong(),
                scriptCount = doc.getLong("scriptCount") ?: rawScripts.size.toLong(),
                lighting = LightingSettings.fromFirestoreMap(lightingMap),
                objects = rawObjects.mapNotNull { (it as? Map<*, *>)?.let(SceneNode::fromFirestoreMap) },
                scripts = rawScripts.mapNotNull { (it as? Map<*, *>)?.let(LuauScript::fromFirestoreMap) },
                createdAt = doc.getTimestamp("createdAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE),
                updatedAt = doc.getTimestamp("updatedAt", DocumentSnapshot.ServerTimestampBehavior.ESTIMATE)
            )
        }

        fun createPayload(
            userId: String,
            name: String,
            description: String,
            lighting: LightingSettings,
            objects: List<SceneNode>,
            scripts: List<LuauScript>
        ): Map<String, Any> {
            val boundedObjects = objects.take(500).map { it.toFirestoreMap() }
            val boundedScripts = scripts.take(100).map { it.toFirestoreMap() }
            return mapOf(
                "userId" to userId,
                "name" to name.trim().take(80).ifBlank { "Untitled Forge Project" },
                "description" to description.trim().take(400),
                "objectCount" to boundedObjects.size,
                "scriptCount" to boundedScripts.size,
                "lighting" to lighting.toFirestoreMap(),
                "objects" to boundedObjects,
                "scripts" to boundedScripts,
                "createdAt" to FieldValue.serverTimestamp(),
                "updatedAt" to FieldValue.serverTimestamp()
            )
        }
    }
}

data class AssetCatalogItem(
    val id: String,
    val name: String,
    val category: String,
    val kind: NodeKind,
    val description: String,
    val accentHex: String,
    val builder: (parentId: String, offset: Vec3) -> List<SceneNode>
)

data class CompatibilityIssue(
    val severity: String, // "PASS", "WARN", "ERROR"
    val targetName: String,
    val message: String,
    val recommendation: String
)

data class CompatibilityReport(
    val totalParts: Int,
    val totalTriangles: Int,
    val estimatedGlbKb: Int,
    val readyForRoblox: Boolean,
    val issues: List<CompatibilityIssue>
)
