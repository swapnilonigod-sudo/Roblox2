package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.CreateNewFolder
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Folder
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Park
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Terrain
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.model.NodeKind
import com.example.model.SceneNode
import com.example.ui.theme.ForgeAmber
import com.example.ui.theme.ForgeBackground
import com.example.ui.theme.ForgeBlue
import com.example.ui.theme.ForgeBorder
import com.example.ui.theme.ForgeEmerald
import com.example.ui.theme.ForgePanel
import com.example.ui.theme.ForgePurple
import com.example.ui.theme.ForgeRed
import com.example.ui.theme.ForgeSurface
import com.example.ui.theme.ForgeTextMuted
import com.example.ui.theme.ForgeTextPrimary
import com.example.ui.theme.ForgeTextSecondary

private data class TreeRow(
    val node: SceneNode,
    val depth: Int
)

@Composable
fun SceneExplorerPanel(
    nodes: List<SceneNode>,
    selectedNodeId: String?,
    onSelectNode: (String?) -> Unit,
    onToggleExpanded: (String) -> Unit,
    onToggleVisibility: (String) -> Unit,
    onCreateFolder: (String) -> Unit,
    onRenameNode: (String, String) -> Unit,
    onDuplicateSelected: () -> Unit,
    onDeleteSelected: () -> Unit,
    modifier: Modifier = Modifier
) {
    var showNewFolderDialog by remember { mutableStateOf(false) }
    var renameTarget by remember { mutableStateOf<SceneNode?>(null) }

    val flattenedTree = remember(nodes) {
        val byParent = nodes.groupBy { it.parentId }
        val result = mutableListOf<TreeRow>()
        fun walk(parentId: String, depth: Int) {
            val children = byParent[parentId].orEmpty()
                .sortedWith(compareByDescending<SceneNode> { it.isFolder }.thenBy { it.name.lowercase() })
            for (child in children) {
                result.add(TreeRow(child, depth))
                if (child.isFolder && child.expanded) {
                    walk(child.id, depth + 1)
                }
            }
        }
        walk(SceneNode.WORKSPACE_ROOT_ID, 0)
        // Catch any orphaned nodes whose parentId is missing
        val visitedIds = result.map { it.node.id }.toSet()
        for (n in nodes) {
            if (n.id !in visitedIds && n.parentId != SceneNode.WORKSPACE_ROOT_ID && nodes.none { it.id == n.parentId }) {
                result.add(TreeRow(n, 0))
            }
        }
        result
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ForgePanel)
    ) {
        // Header + Quick Actions
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Icon(Icons.Default.Public, contentDescription = null, tint = ForgeBlue, modifier = Modifier.size(16.dp))
                Text(
                    text = "Workspace (${nodes.size})",
                    style = MaterialTheme.typography.titleSmall,
                    color = ForgeTextPrimary
                )
            }
            Row(horizontalArrangement = Arrangement.spacedBy(2.dp)) {
                IconButton(
                    onClick = { showNewFolderDialog = true },
                    modifier = Modifier.size(40.dp).testTag("create_folder_button")
                ) {
                    Icon(Icons.Default.CreateNewFolder, contentDescription = "New Folder", tint = ForgePurple, modifier = Modifier.size(18.dp))
                }
                if (selectedNodeId != null) {
                    val selNode = nodes.firstOrNull { it.id == selectedNodeId }
                    IconButton(
                        onClick = { renameTarget = selNode },
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = "Rename", tint = ForgeTextSecondary, modifier = Modifier.size(17.dp))
                    }
                    IconButton(
                        onClick = onDuplicateSelected,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(Icons.Default.ContentCopy, contentDescription = "Duplicate", tint = ForgeTextSecondary, modifier = Modifier.size(17.dp))
                    }
                    IconButton(
                        onClick = onDeleteSelected,
                        modifier = Modifier.size(40.dp)
                    ) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = ForgeRed, modifier = Modifier.size(17.dp))
                    }
                }
            }
        }
        HorizontalDivider(color = ForgeBorder)

        if (flattenedTree.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text(
                    text = "Workspace is empty.\nInsert shapes or ask AI to build!",
                    style = MaterialTheme.typography.bodySmall,
                    color = ForgeTextMuted
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(vertical = 4.dp)
            ) {
                items(flattenedTree, key = { it.node.id }) { row ->
                    val node = row.node
                    val isSelected = node.id == selectedNodeId
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 6.dp, vertical = 1.dp)
                            .clip(RoundedCornerShape(6.dp))
                            .background(if (isSelected) ForgeBlue.copy(alpha = 0.22f) else Color.Transparent)
                            .border(
                                1.dp,
                                if (isSelected) ForgeBlue else Color.Transparent,
                                RoundedCornerShape(6.dp)
                            )
                            .clickable { onSelectNode(node.id) }
                            .padding(start = (8 + row.depth * 14).dp, end = 4.dp, top = 4.dp, bottom = 4.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (node.isFolder) {
                            IconButton(
                                onClick = { onToggleExpanded(node.id) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = if (node.expanded) Icons.Default.ExpandMore else Icons.Default.ExpandLess,
                                    contentDescription = "Expand Folder",
                                    tint = ForgeTextSecondary,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        } else {
                            Spacer(Modifier.width(8.dp))
                        }

                        Icon(
                            imageVector = when {
                                node.isFolder && node.expanded -> Icons.Default.FolderOpen
                                node.isFolder -> Icons.Default.Folder
                                node.kind == NodeKind.TREE -> Icons.Default.Park
                                node.kind == NodeKind.TERRAIN -> Icons.Default.Terrain
                                else -> Icons.Default.ViewInAr
                            },
                            contentDescription = null,
                            tint = when {
                                node.isFolder -> ForgeAmber
                                node.kind == NodeKind.TREE -> ForgeEmerald
                                node.kind == NodeKind.BUILDING -> ForgePurple
                                else -> ForgeBlue
                            },
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(Modifier.width(7.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = node.name,
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                                color = if (node.visible) ForgeTextPrimary else ForgeTextMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Text(
                                text = if (node.isFolder) "Folder" else "${node.shape.label} • ${node.material.label}",
                                style = MaterialTheme.typography.labelSmall,
                                color = ForgeTextMuted,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                        }

                        if (!node.isFolder) {
                            IconButton(
                                onClick = { onToggleVisibility(node.id) },
                                modifier = Modifier.size(34.dp)
                            ) {
                                Icon(
                                    imageVector = if (node.visible) Icons.Default.Visibility else Icons.Default.VisibilityOff,
                                    contentDescription = if (node.visible) "Hide" else "Show",
                                    tint = if (node.visible) ForgeTextSecondary else ForgeTextMuted,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                // Engine Environment Reference Rows (Lighting & Camera)
                item {
                    HorizontalDivider(color = ForgeBorder, modifier = Modifier.padding(vertical = 6.dp))
                    Surface(
                        onClick = { onSelectNode(null) },
                        color = ForgeSurface,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 8.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "Lighting & Sky Settings (Tap to Inspect)",
                            style = MaterialTheme.typography.labelMedium,
                            color = ForgeTextSecondary,
                            modifier = Modifier.padding(10.dp)
                        )
                    }
                }
            }
        }
    }

    if (showNewFolderDialog) {
        var folderName by remember { mutableStateOf("RegionFolder") }
        AlertDialog(
            onDismissRequest = { showNewFolderDialog = false },
            containerColor = ForgePanel,
            title = { Text("Create Explorer Folder", color = ForgeTextPrimary) },
            text = {
                OutlinedTextField(
                    value = folderName,
                    onValueChange = { folderName = it },
                    label = { Text("Folder Name") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    onCreateFolder(folderName)
                    showNewFolderDialog = false
                }) { Text("Create") }
            },
            dismissButton = {
                TextButton(onClick = { showNewFolderDialog = false }) { Text("Cancel") }
            }
        )
    }

    val target = renameTarget
    if (target != null) {
        var updatedName by remember(target.id) { mutableStateOf(target.name) }
        AlertDialog(
            onDismissRequest = { renameTarget = null },
            containerColor = ForgePanel,
            title = { Text("Rename Object", color = ForgeTextPrimary) },
            text = {
                OutlinedTextField(
                    value = updatedName,
                    onValueChange = { updatedName = it },
                    label = { Text("Object Name") },
                    singleLine = true
                )
            },
            confirmButton = {
                Button(onClick = {
                    if (updatedName.isNotBlank()) {
                        onRenameNode(target.id, updatedName.trim())
                    }
                    renameTarget = null
                }) { Text("Rename") }
            },
            dismissButton = {
                TextButton(onClick = { renameTarget = null }) { Text("Cancel") }
            }
        )
    }
}
