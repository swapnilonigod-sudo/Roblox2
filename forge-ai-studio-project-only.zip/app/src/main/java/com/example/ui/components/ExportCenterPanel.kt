package com.example.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.CompatibilityReport
import com.example.ui.theme.ForgeAmber
import com.example.ui.theme.ForgeBlue
import com.example.ui.theme.ForgeBorder
import com.example.ui.theme.ForgeEmerald
import com.example.ui.theme.ForgePanel
import com.example.ui.theme.ForgePurple
import com.example.ui.theme.ForgeRed
import com.example.ui.theme.ForgeSurface
import com.example.ui.theme.ForgeTextMuted
import com.example.ui.theme.ForgeTextPrimary
import com.example.ui.theme.ForgeTextSecondary

@Composable
fun ExportCenterPanel(
    projectName: String,
    hasSelection: Boolean,
    scaleMultiplier: Float,
    report: CompatibilityReport?,
    onSetScaleMultiplier: (Float) -> Unit,
    onRefreshCheck: () -> Unit,
    onBuildGlb: (Boolean) -> ByteArray,
    onBuildGltf: (Boolean) -> String,
    onBuildObj: (Boolean) -> String,
    onBuildManifest: () -> String,
    onLogExport: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedOnly by remember { mutableStateOf(false) }
    var exportStatus by remember { mutableStateOf<String?>(null) }

    val safeBase = projectName.replace(Regex("[^A-Za-z0-9_\\-]"), "_").ifBlank { "ForgeScene" }

    val glbLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("model/gltf-binary")
    ) { uri ->
        if (uri != null) {
            try {
                val bytes = onBuildGlb(selectedOnly)
                context.contentResolver.openOutputStream(uri)?.use { it.write(bytes) }
                exportStatus = "Exported binary GLB (${bytes.size / 1024} KB)."
                onLogExport(exportStatus!!)
            } catch (e: Exception) {
                exportStatus = "GLB export failed: ${e.message}"
            }
        }
    }

    val gltfLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("model/gltf+json")
    ) { uri ->
        if (uri != null) {
            try {
                val txt = onBuildGltf(selectedOnly)
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(txt) }
                exportStatus = "Exported glTF 2.0 JSON (${txt.length / 1024} KB)."
                onLogExport(exportStatus!!)
            } catch (e: Exception) {
                exportStatus = "glTF export failed: ${e.message}"
            }
        }
    }

    val objLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null) {
            try {
                val txt = onBuildObj(selectedOnly)
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(txt) }
                exportStatus = "Exported Wavefront OBJ (${txt.length / 1024} KB)."
                onLogExport(exportStatus!!)
            } catch (e: Exception) {
                exportStatus = "OBJ export failed: ${e.message}"
            }
        }
    }

    val manifestLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            try {
                val txt = onBuildManifest()
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use { it.write(txt) }
                exportStatus = "Exported Roblox Import Manifest JSON."
                onLogExport(exportStatus!!)
            } catch (e: Exception) {
                exportStatus = "Manifest export failed: ${e.message}"
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ForgePanel)
            .verticalScroll(rememberScrollState())
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("Roblox Export Center", style = MaterialTheme.typography.titleMedium, color = ForgeTextPrimary)
        Text(
            text = "Prepares real GLB / glTF 2.0 / Wavefront OBJ meshes and a project manifest for Roblox Studio's 3D Importer. Does not claim to export proprietary .rbxl binary place files.",
            style = MaterialTheme.typography.bodySmall,
            color = ForgeTextSecondary
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(
                text = if (selectedOnly) "Scope: Selected Object / Folder Only" else "Scope: Entire Workspace Scene",
                style = MaterialTheme.typography.bodyMedium,
                color = ForgeTextPrimary
            )
            Switch(
                checked = selectedOnly,
                onCheckedChange = { selectedOnly = it },
                enabled = hasSelection
            )
        }

        Text("Roblox Stud Scale Multiplier: ${String.format("%.2f", scaleMultiplier)}x", style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary)
        Slider(
            value = scaleMultiplier,
            onValueChange = onSetScaleMultiplier,
            valueRange = 0.25f..8.0f
        )

        // Export Format Buttons
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(
                onClick = { glbLauncher.launch("${safeBase}.glb") },
                colors = ButtonDefaults.buttonColors(containerColor = ForgeBlue),
                modifier = Modifier.weight(1f).testTag("export_glb_button")
            ) {
                Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.size(4.dp))
                Text("Export .GLB")
            }
            Button(
                onClick = { gltfLauncher.launch("${safeBase}.gltf") },
                colors = ButtonDefaults.buttonColors(containerColor = ForgePurple),
                modifier = Modifier.weight(1f).testTag("export_gltf_button")
            ) {
                Text("Export .glTF")
            }
        }

        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(
                onClick = { objLauncher.launch("${safeBase}.obj") },
                modifier = Modifier.weight(1f).testTag("export_obj_button")
            ) {
                Text("Export .OBJ")
            }
            OutlinedButton(
                onClick = { manifestLauncher.launch("${safeBase}_manifest.json") },
                modifier = Modifier.weight(1f).testTag("export_manifest_button")
            ) {
                Text("Manifest .JSON")
            }
        }

        if (exportStatus != null) {
            Surface(
                color = ForgeEmerald.copy(alpha = 0.16f),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, ForgeEmerald, RoundedCornerShape(8.dp))
            ) {
                Text(exportStatus.orEmpty(), style = MaterialTheme.typography.bodySmall, color = ForgeEmerald, modifier = Modifier.padding(10.dp))
            }
        }

        HorizontalDivider(color = ForgeBorder)
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text("Roblox Compatibility Checker", style = MaterialTheme.typography.titleSmall, color = ForgeTextPrimary)
            OutlinedButton(onClick = onRefreshCheck) {
                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                Spacer(Modifier.size(4.dp))
                Text("Re-scan")
            }
        }

        if (report != null) {
            Surface(
                color = ForgeSurface,
                shape = RoundedCornerShape(10.dp),
                modifier = Modifier.fillMaxWidth().border(1.dp, ForgeBorder, RoundedCornerShape(10.dp))
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("Parts: ${report.totalParts}", style = MaterialTheme.typography.labelMedium, color = ForgeTextPrimary)
                        Text("Tris: ${report.totalTriangles}", style = MaterialTheme.typography.labelMedium, color = ForgeTextPrimary)
                        Text("Est. GLB: ~${report.estimatedGlbKb} KB", style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary)
                    }
                    report.issues.forEach { issue ->
                        val (icon, color) = when (issue.severity) {
                            "ERROR" -> Icons.Default.Error to ForgeRed
                            "WARN" -> Icons.Default.Warning to ForgeAmber
                            else -> Icons.Default.CheckCircle to ForgeEmerald
                        }
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(color.copy(alpha = 0.08f), RoundedCornerShape(6.dp))
                                .padding(8.dp),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Icon(icon, contentDescription = issue.severity, tint = color, modifier = Modifier.size(16.dp))
                            Column {
                                Text("${issue.targetName}: ${issue.message}", style = MaterialTheme.typography.bodySmall, color = ForgeTextPrimary, fontWeight = FontWeight.Medium)
                                Text(issue.recommendation, style = MaterialTheme.typography.labelSmall, color = ForgeTextMuted)
                            }
                        }
                    }
                }
            }
        }

        Surface(
            color = ForgeSurface,
            shape = RoundedCornerShape(8.dp),
            modifier = Modifier.fillMaxWidth().border(1.dp, ForgeBorder, RoundedCornerShape(8.dp))
        ) {
            Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Text("Roblox Studio Import Guide", style = MaterialTheme.typography.labelMedium, color = ForgeBlue, fontWeight = FontWeight.Bold)
                Text("1. Export .GLB (preserves hierarchy, PBR colors, and transforms).", style = MaterialTheme.typography.bodySmall, color = ForgeTextSecondary)
                Text("2. In Roblox Studio, click Home > Import 3D and select the .glb file.", style = MaterialTheme.typography.bodySmall, color = ForgeTextSecondary)
                Text("3. Download .luau scripts from the Scripts tab and place them into ServerScriptService or StarterPlayerScripts.", style = MaterialTheme.typography.bodySmall, color = ForgeTextSecondary)
            }
        }
    }
}
