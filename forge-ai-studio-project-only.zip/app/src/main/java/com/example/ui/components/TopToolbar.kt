package com.example.ui.components

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Logout
import androidx.compose.material.icons.automirrored.filled.Redo
import androidx.compose.material.icons.automirrored.filled.Undo
import androidx.compose.material.icons.filled.AddBox
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.CloudUpload
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import com.example.R
import com.example.model.SceneShape
import com.example.ui.theme.ForgeAmber
import com.example.ui.theme.ForgeBackground
import com.example.ui.theme.ForgeBlue
import com.example.ui.theme.ForgeBorder
import com.example.ui.theme.ForgeEmerald
import com.example.ui.theme.ForgePanel
import com.example.ui.theme.ForgePurple
import com.example.ui.theme.ForgeRed
import com.example.ui.theme.ForgeSurface
import com.example.ui.theme.ForgeTextMuted
import com.example.ui.theme.ForgeTextPrimary
import com.example.ui.theme.ForgeTextSecondary

@Composable
fun TopToolbar(
    projectName: String,
    isDirty: Boolean,
    isSaving: Boolean,
    canUndo: Boolean,
    canRedo: Boolean,
    hasSelection: Boolean,
    isPlaying: Boolean,
    aiEnabled: Boolean,
    isFloatingAiOpen: Boolean,
    onOpenProjects: () -> Unit,
    onSaveProject: () -> Unit,
    onUndo: () -> Unit,
    onRedo: () -> Unit,
    onDuplicate: () -> Unit,
    onDelete: () -> Unit,
    onInsertShape: (SceneShape) -> Unit,
    onTogglePlay: () -> Unit,
    onResetPlay: () -> Unit,
    onOpenExport: () -> Unit,
    onToggleFloatingAi: () -> Unit,
    onOpenSettings: () -> Unit,
    onSignOut: () -> Unit
) {
    var showInsertMenu by remember { mutableStateOf(false) }

    Surface(
        color = ForgePanel,
        modifier = Modifier
            .fillMaxWidth()
            .statusBarsPadding()
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // Top Menu & Project Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 6.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Image(
                        painter = painterResource(id = R.drawable.forge_app_icon_1795699688008),
                        contentDescription = "Forge AI Studio",
                        modifier = Modifier
                            .size(28.dp)
                            .clip(RoundedCornerShape(6.dp))
                    )
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Text(
                                text = "FORGE AI STUDIO",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = ForgeBlue
                            )
                            Text(
                                text = if (isDirty) "• Unsaved" else "• Synced",
                                style = MaterialTheme.typography.labelSmall,
                                color = if (isDirty) ForgeAmber else ForgeEmerald
                            )
                        }
                        Text(
                            text = projectName,
                            style = MaterialTheme.typography.titleSmall,
                            color = ForgeTextPrimary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    // Play / Stop / Reset controls always immediately visible
                    Surface(
                        onClick = onTogglePlay,
                        color = if (isPlaying) ForgeRed.copy(alpha = 0.2f) else ForgeEmerald.copy(alpha = 0.2f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .border(
                                1.dp,
                                if (isPlaying) ForgeRed else ForgeEmerald,
                                RoundedCornerShape(8.dp)
                            )
                            .testTag("play_toggle_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = if (isPlaying) Icons.Default.Stop else Icons.Default.PlayArrow,
                                contentDescription = if (isPlaying) "Stop Preview" else "Play Preview",
                                tint = if (isPlaying) ForgeRed else ForgeEmerald,
                                modifier = Modifier.size(16.dp)
                            )
                            Text(
                                text = if (isPlaying) "Stop" else "Play",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = if (isPlaying) ForgeRed else ForgeEmerald
                            )
                        }
                    }

                    if (isPlaying) {
                        IconButton(
                            onClick = onResetPlay,
                            modifier = Modifier.testTag("reset_play_button")
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "Reset Character", tint = ForgeTextPrimary)
                        }
                    }

                    Surface(
                        onClick = onToggleFloatingAi,
                        color = if (isFloatingAiOpen) ForgePurple else ForgePurple.copy(alpha = 0.16f),
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .minimumInteractiveComponentSize()
                            .border(1.dp, ForgePurple, RoundedCornerShape(8.dp))
                            .testTag("ai_builder_toggle_button")
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "AI Builder",
                                tint = ForgeTextPrimary,
                                modifier = Modifier.size(15.dp)
                            )
                            Text(
                                text = if (aiEnabled) "AI" else "AI Off",
                                style = MaterialTheme.typography.labelMedium,
                                color = ForgeTextPrimary
                            )
                        }
                    }
                }
            }

            // Studio Action Ribbon (Scrollable for Compact/Tablet)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(ForgeBackground)
                    .horizontalScroll(rememberScrollState())
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                RibbonButton(
                    icon = Icons.Default.FolderOpen,
                    label = "Projects",
                    onClick = onOpenProjects,
                    tag = "projects_button"
                )
                RibbonButton(
                    icon = Icons.Default.CloudUpload,
                    label = if (isSaving) "Saving..." else "Save",
                    onClick = onSaveProject,
                    enabled = !isSaving,
                    accent = ForgeBlue,
                    loading = isSaving,
                    tag = "save_project_button"
                )

                ToolbarDivider()

                RibbonButton(
                    icon = Icons.AutoMirrored.Filled.Undo,
                    label = "Undo",
                    onClick = onUndo,
                    enabled = canUndo && !isPlaying,
                    tag = "undo_button"
                )
                RibbonButton(
                    icon = Icons.AutoMirrored.Filled.Redo,
                    label = "Redo",
                    onClick = onRedo,
                    enabled = canRedo && !isPlaying,
                    tag = "redo_button"
                )

                ToolbarDivider()

                Box {
                    RibbonButton(
                        icon = Icons.Default.AddBox,
                        label = "Insert",
                        onClick = { showInsertMenu = true },
                        enabled = !isPlaying,
                        accent = ForgePurple,
                        tag = "insert_menu_button"
                    )
                    DropdownMenu(
                        expanded = showInsertMenu,
                        onDismissRequest = { showInsertMenu = false },
                        modifier = Modifier.background(ForgeSurface)
                    ) {
                        SceneShape.entries.filter { it != SceneShape.CUSTOM_MESH }.forEach { shape ->
                            DropdownMenuItem(
                                text = { Text(shape.label, color = ForgeTextPrimary) },
                                onClick = {
                                    showInsertMenu = false
                                    onInsertShape(shape)
                                }
                            )
                        }
                    }
                }

                RibbonButton(
                    icon = Icons.Default.ContentCopy,
                    label = "Duplicate",
                    onClick = onDuplicate,
                    enabled = hasSelection && !isPlaying,
                    tag = "duplicate_button"
                )
                RibbonButton(
                    icon = Icons.Default.Delete,
                    label = "Delete",
                    onClick = onDelete,
                    enabled = hasSelection && !isPlaying,
                    accent = if (hasSelection) ForgeRed else ForgeTextMuted,
                    tag = "delete_button"
                )

                ToolbarDivider()

                RibbonButton(
                    icon = Icons.Default.IosShare,
                    label = "Export",
                    onClick = onOpenExport,
                    accent = ForgeEmerald,
                    tag = "export_center_button"
                )
                RibbonButton(
                    icon = Icons.Default.Settings,
                    label = "AI & Settings",
                    onClick = onOpenSettings,
                    tag = "settings_button"
                )
                RibbonButton(
                    icon = Icons.AutoMirrored.Filled.Logout,
                    label = "Sign Out",
                    onClick = onSignOut,
                    tag = "sign_out_button"
                )
            }
            HorizontalDivider(color = ForgeBorder, thickness = 1.dp)
        }
    }
}

@Composable
private fun RibbonButton(
    icon: ImageVector,
    label: String,
    onClick: () -> Unit,
    enabled: Boolean = true,
    accent: Color = ForgeTextPrimary,
    loading: Boolean = false,
    tag: String
) {
    val tint = if (enabled) accent else ForgeTextMuted.copy(alpha = 0.5f)
    Surface(
        onClick = onClick,
        enabled = enabled,
        color = ForgeSurface,
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier
            .minimumInteractiveComponentSize()
            .border(1.dp, ForgeBorder.copy(alpha = if (enabled) 1f else 0.4f), RoundedCornerShape(6.dp))
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 9.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(5.dp)
        ) {
            if (loading) {
                CircularProgressIndicator(modifier = Modifier.size(13.dp), strokeWidth = 2.dp, color = tint)
            } else {
                Icon(icon, contentDescription = label, tint = tint, modifier = Modifier.size(15.dp))
            }
            Text(
                text = label,
                style = MaterialTheme.typography.labelMedium,
                color = if (enabled) ForgeTextPrimary else ForgeTextMuted
            )
        }
    }
}

@Composable
private fun ToolbarDivider() {
    Box(
        modifier = Modifier
            .padding(horizontal = 4.dp)
            .width(1.dp)
            .height(22.dp)
            .background(ForgeBorder)
    )
}
