package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.CloudQueue
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.model.AssetCatalogItem
import com.example.model.CustomMeshData
import com.example.model.ForgeMaterial
import com.example.model.NodeKind
import com.example.model.SceneNode
import com.example.model.ScenePresets
import com.example.model.SceneShape
import com.example.model.Vec3
import com.example.ui.theme.ForgeBlue
import com.example.ui.theme.ForgeBorder
import com.example.ui.theme.ForgeEmerald
import com.example.ui.theme.ForgePanel
import com.example.ui.theme.ForgePurple
import com.example.ui.theme.ForgeSurface
import com.example.ui.theme.ForgeTextMuted
import com.example.ui.theme.ForgeTextPrimary
import com.example.ui.theme.ForgeTextSecondary

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AssetLibraryAndBuilderPanel(
    importedAssets: List<SceneNode>,
    external3dProviderUrl: String,
    onInsertCatalogAsset: (AssetCatalogItem) -> Unit,
    onBuildCustomAsset: (name: String, kind: NodeKind, shape: SceneShape, scale: Vec3, colorHex: String, material: ForgeMaterial, customMesh: CustomMeshData?) -> Unit,
    onImportObjFile: (fileName: String, content: String) -> Unit,
    onRequestAiAssetBuild: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var subTab by remember { mutableIntStateOf(0) }

    val objPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        if (uri != null) {
            val text = try {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
            } catch (_: Exception) {
                null
            }
            if (text != null) {
                val name = uri.lastPathSegment?.substringAfterLast('/') ?: "ImportedModel.obj"
                onImportObjFile(name, text)
            }
        }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ForgePanel)
    ) {
        TabRow(
            selectedTabIndex = subTab,
            containerColor = ForgePanel,
            contentColor = ForgeBlue
        ) {
            Tab(selected = subTab == 0, onClick = { subTab = 0 }, text = { Text("Asset Library", maxLines = 1) })
            Tab(selected = subTab == 1, onClick = { subTab = 1 }, text = { Text("3D Asset Builder", maxLines = 1) })
        }

        if (subTab == 0) {
            val categories = listOf("All", "Primitives", "Buildings", "Terrain", "Trees", "Props", "Furniture", "Decorations", "Models", "Imported")
            var selectedCat by remember { mutableStateOf("All") }

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState())
                    .padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                categories.forEach { cat ->
                    val active = selectedCat == cat
                    Surface(
                        onClick = { selectedCat = cat },
                        color = if (active) ForgeBlue else ForgeSurface,
                        shape = RoundedCornerShape(6.dp),
                        modifier = Modifier.border(1.dp, if (active) ForgeBlue else ForgeBorder, RoundedCornerShape(6.dp))
                    ) {
                        Text(cat, style = MaterialTheme.typography.labelMedium, color = ForgeTextPrimary, modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp))
                    }
                }
            }

            OutlinedButton(
                onClick = { objPickerLauncher.launch(arrayOf("*/*")) },
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp)
                    .testTag("import_obj_button")
            ) {
                Icon(Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(Modifier.size(6.dp))
                Text("Import .OBJ 3D File into Scene")
            }
            Spacer(Modifier.height(6.dp))

            val filteredCatalog = remember(selectedCat) {
                if (selectedCat == "All") ScenePresets.assetCatalog
                else ScenePresets.assetCatalog.filter { it.category == selectedCat }
            }

            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 10.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                if (selectedCat == "All" || selectedCat == "Imported") {
                    items(importedAssets, key = { "imp_${it.id}" }) { asset ->
                        Surface(
                            color = ForgeSurface,
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .border(1.dp, ForgePurple.copy(alpha = 0.5f), RoundedCornerShape(10.dp))
                        ) {
                            Row(
                                modifier = Modifier.padding(10.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(asset.name, style = MaterialTheme.typography.titleSmall, color = ForgeTextPrimary)
                                    Text("Imported OBJ • ${asset.customMesh?.triangleCount ?: 0} triangles", style = MaterialTheme.typography.labelSmall, color = ForgePurple)
                                }
                                Button(
                                    onClick = {
                                        onBuildCustomAsset(asset.name, NodeKind.IMPORTED_MESH, SceneShape.CUSTOM_MESH, asset.scale, asset.colorHex, asset.material, asset.customMesh)
                                    },
                                    colors = ButtonDefaults.buttonColors(containerColor = ForgePurple)
                                ) {
                                    Text("Place")
                                }
                            }
                        }
                    }
                }

                items(filteredCatalog, key = { it.id }) { item ->
                    Surface(
                        color = ForgeSurface,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, ForgeBorder, RoundedCornerShape(10.dp))
                    ) {
                        Row(
                            modifier = Modifier.padding(10.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .background(parseColorSafe(item.accentHex).copy(alpha = 0.2f), RoundedCornerShape(8.dp))
                                    .border(1.dp, parseColorSafe(item.accentHex), RoundedCornerShape(8.dp)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.ViewInAr, contentDescription = null, tint = parseColorSafe(item.accentHex))
                            }
                            Column(modifier = Modifier.weight(1f)) {
                                Text(item.name, style = MaterialTheme.typography.titleSmall, color = ForgeTextPrimary)
                                Text("${item.category} • ${item.description}", style = MaterialTheme.typography.bodySmall, color = ForgeTextSecondary)
                            }
                            Button(
                                onClick = { onInsertCatalogAsset(item) },
                                colors = ButtonDefaults.buttonColors(containerColor = ForgeBlue),
                                modifier = Modifier.testTag("insert_${item.id}")
                            ) {
                                Icon(Icons.Default.AddCircle, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(Modifier.size(4.dp))
                                Text("Add")
                            }
                        }
                    }
                }
                item { Spacer(Modifier.height(14.dp)) }
            }
        } else {
            // 3D Asset Builder Tab
            var assetName by remember { mutableStateOf("ForgeTowerModule") }
            var selectedKind by remember { mutableStateOf(NodeKind.BUILDING) }
            var selectedShape by remember { mutableStateOf(SceneShape.CYLINDER) }
            var selectedMaterial by remember { mutableStateOf(ForgeMaterial.BRICK) }
            var selectedColor by remember { mutableStateOf("#8B5CF6") }
            var width by remember { mutableFloatStateOf(2.5f) }
            var height by remember { mutableFloatStateOf(4.5f) }
            var depth by remember { mutableFloatStateOf(2.5f) }
            var aiAssetPrompt by remember { mutableStateOf("") }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(12.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Procedural & Modular 3D Asset Builder", style = MaterialTheme.typography.titleSmall, color = ForgeTextPrimary)
                OutlinedTextField(
                    value = assetName,
                    onValueChange = { assetName = it },
                    label = { Text("Asset Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )

                Text("Primitive Base Geometry", style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    SceneShape.entries.filter { it != SceneShape.CUSTOM_MESH }.forEach { s ->
                        val active = selectedShape == s
                        Surface(
                            onClick = { selectedShape = s },
                            color = if (active) ForgeBlue else ForgeSurface,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.border(1.dp, if (active) ForgeBlue else ForgeBorder, RoundedCornerShape(6.dp))
                        ) {
                            Text(s.label, style = MaterialTheme.typography.labelMedium, color = ForgeTextPrimary, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                        }
                    }
                }

                Text("Category", style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf(NodeKind.BUILDING, NodeKind.PROP, NodeKind.FURNITURE, NodeKind.DECORATION, NodeKind.TERRAIN, NodeKind.TREE).forEach { k ->
                        val active = selectedKind == k
                        Surface(
                            onClick = { selectedKind = k },
                            color = if (active) ForgePurple else ForgeSurface,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.border(1.dp, if (active) ForgePurple else ForgeBorder, RoundedCornerShape(6.dp))
                        ) {
                            Text(k.label, style = MaterialTheme.typography.labelMedium, color = ForgeTextPrimary, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                        }
                    }
                }

                Text("Dimensions (W: ${String.format("%.1f", width)}  H: ${String.format("%.1f", height)}  D: ${String.format("%.1f", depth)})", style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary)
                Slider(value = width, onValueChange = { width = it }, valueRange = 0.5f..12f)
                Slider(value = height, onValueChange = { height = it }, valueRange = 0.5f..16f)
                Slider(value = depth, onValueChange = { depth = it }, valueRange = 0.5f..12f)

                Text("Material", style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary)
                FlowRow(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    ForgeMaterial.entries.forEach { m ->
                        val active = selectedMaterial == m
                        Surface(
                            onClick = { selectedMaterial = m },
                            color = if (active) ForgeBlue else ForgeSurface,
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.border(1.dp, if (active) ForgeBlue else ForgeBorder, RoundedCornerShape(6.dp))
                        ) {
                            Text(m.label, style = MaterialTheme.typography.labelMedium, color = ForgeTextPrimary, modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp))
                        }
                    }
                }

                Button(
                    onClick = {
                        onBuildCustomAsset(assetName, selectedKind, selectedShape, Vec3(width, height, depth), selectedColor, selectedMaterial, null)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = ForgeEmerald),
                    modifier = Modifier.fillMaxWidth().testTag("build_custom_asset_button")
                ) {
                    Icon(Icons.Default.Build, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.size(6.dp))
                    Text("Create & Place Asset in 3D Scene")
                }

                HorizontalDivider(color = ForgeBorder)
                Text("AI Modular Structure Composer (Gemini)", style = MaterialTheme.typography.titleSmall, color = ForgePurple)
                Text(
                    text = "Describe a multi-part asset (e.g., \"ornate fantasy throne\", \"stone bridge arch\", \"medieval weapon rack\"). Gemini composes it from editable 3D primitives.",
                    style = MaterialTheme.typography.bodySmall,
                    color = ForgeTextSecondary
                )
                OutlinedTextField(
                    value = aiAssetPrompt,
                    onValueChange = { aiAssetPrompt = it },
                    label = { Text("Describe 3D model to compose") },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    onClick = {
                        if (aiAssetPrompt.isNotBlank()) {
                            onRequestAiAssetBuild("Compose a detailed modular 3D asset for '$aiAssetPrompt' organized inside one folder using multiple primitives.")
                            aiAssetPrompt = ""
                        }
                    },
                    enabled = aiAssetPrompt.isNotBlank(),
                    colors = ButtonDefaults.buttonColors(containerColor = ForgePurple),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(16.dp))
                    Spacer(Modifier.size(6.dp))
                    Text("Compose Modular Asset with Gemini")
                }

                HorizontalDivider(color = ForgeBorder)
                Surface(
                    color = ForgeSurface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, ForgeBorder, RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.CloudQueue, contentDescription = null, tint = ForgeTextSecondary, modifier = Modifier.size(16.dp))
                            Text("External AI 3D Mesh Provider Connector", style = MaterialTheme.typography.labelMedium, color = ForgeTextPrimary)
                        }
                        Text(
                            text = if (external3dProviderUrl.isBlank()) {
                                "Gemini does not output binary .glb/.obj meshes directly. Configure an external 3D mesh provider endpoint in AI & Settings, or import .OBJ files directly above."
                            } else {
                                "Configured external 3D endpoint: $external3dProviderUrl"
                            },
                            style = MaterialTheme.typography.bodySmall,
                            color = ForgeTextMuted
                        )
                    }
                }
            }
        }
    }
}

private fun parseColorSafe(hex: String): Color = try {
    Color(android.graphics.Color.parseColor(hex))
} catch (_: Exception) {
    ForgeBlue
}
