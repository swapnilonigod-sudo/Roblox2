package com.example.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ClearAll
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.FileUpload
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.example.data.StudioSettings
import com.example.model.AiModelChoice
import com.example.model.ConsoleLog
import com.example.model.ForgeProjectSummary
import com.example.model.ImageModelChoice
import com.example.model.LogLevel
import com.example.ui.theme.ForgeAmber
import com.example.ui.theme.ForgeBackground
import com.example.ui.theme.ForgeBlue
import com.example.ui.theme.ForgeBorder
import com.example.ui.theme.ForgeEmerald
import com.example.ui.theme.ForgePanel
import com.example.ui.theme.ForgePurple
import com.example.ui.theme.ForgeRed
import com.example.ui.theme.ForgeSurface
import com.example.ui.theme.ForgeTextMuted
import com.example.ui.theme.ForgeTextPrimary
import com.example.ui.theme.ForgeTextSecondary
import com.example.ui.theme.JetBrainsMonoFontFamily
import com.example.viewmodel.CloudProjectsUiState

@Composable
fun ConsolePanel(
    logs: List<ConsoleLog>,
    onClear: () -> Unit,
    modifier: Modifier = Modifier
) {
    var filter by remember { mutableStateOf<LogLevel?>(null) }
    val shown = remember(logs, filter) {
        if (filter == null) logs else logs.filter { it.level == filter }
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ForgePanel)
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                FilterChipBtn("All (${logs.size})", filter == null) { filter = null }
                FilterChipBtn("AI", filter == LogLevel.AI) { filter = LogLevel.AI }
                FilterChipBtn("Warn", filter == LogLevel.WARN) { filter = LogLevel.WARN }
                FilterChipBtn("Err", filter == LogLevel.ERROR) { filter = LogLevel.ERROR }
            }
            IconButton(onClick = onClear, modifier = Modifier.size(36.dp)) {
                Icon(Icons.Default.ClearAll, contentDescription = "Clear Console", tint = ForgeTextSecondary)
            }
        }
        HorizontalDivider(color = ForgeBorder)

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(ForgeBackground)
                .padding(8.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            items(shown, key = { it.id }) { entry ->
                val color = when (entry.level) {
                    LogLevel.ERROR -> ForgeRed
                    LogLevel.WARN -> ForgeAmber
                    LogLevel.AI -> ForgePurple
                    LogLevel.INFO -> ForgeEmerald
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = "[${entry.timestamp}]",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                        color = ForgeTextMuted
                    )
                    Text(
                        text = "[${entry.level.label}/${entry.source}]",
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                        color = color,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = entry.message,
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = JetBrainsMonoFontFamily),
                        color = ForgeTextPrimary
                    )
                }
            }
        }
    }
}

@Composable
private fun FilterChipBtn(label: String, active: Boolean, onClick: () -> Unit) {
    Surface(
        onClick = onClick,
        color = if (active) ForgeBlue else ForgeSurface,
        shape = RoundedCornerShape(6.dp),
        modifier = Modifier.border(1.dp, if (active) ForgeBlue else ForgeBorder, RoundedCornerShape(6.dp))
    ) {
        Text(label, style = MaterialTheme.typography.labelSmall, color = ForgeTextPrimary, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
    }
}

@Composable
fun ProjectsDialog(
    currentProjectName: String,
    cloudProjectsState: CloudProjectsUiState,
    onDismiss: () -> Unit,
    onCreateNew: (String, Boolean) -> Unit,
    onRenameCurrent: (String) -> Unit,
    onSaveToCloud: () -> Unit,
    onLoadCloudProject: (ForgeProjectSummary) -> Unit,
    onDeleteCloudProject: (String) -> Unit,
    onBuildProjectJson: () -> String,
    onImportProjectJson: (String) -> Unit
) {
    val context = LocalContext.current
    var newName by remember { mutableStateOf("") }
    var renameText by remember(currentProjectName) { mutableStateOf(currentProjectName) }

    val exportJsonLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        if (uri != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use {
                    it.write(onBuildProjectJson())
                }
            } catch (_: Exception) {
            }
        }
    }

    val importJsonLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri ->
        if (uri != null) {
            try {
                val txt = context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                if (txt != null) {
                    onImportProjectJson(txt)
                    onDismiss()
                }
            } catch (_: Exception) {
            }
        }
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ForgePanel,
        title = { Text("Forge Projects & Cloud Sync", color = ForgeTextPrimary) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 460.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = renameText,
                        onValueChange = { renameText = it },
                        label = { Text("Current Project Name") },
                        singleLine = true,
                        modifier = Modifier.weight(1f)
                    )
                    Button(onClick = { onRenameCurrent(renameText) }) { Text("Rename") }
                }

                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = {
                            onSaveToCloud()
                            onDismiss()
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = ForgeBlue),
                        modifier = Modifier.weight(1f)
                    ) { Text("Save to Cloud") }
                    OutlinedButton(
                        onClick = {
                            val safe = currentProjectName.replace(Regex("[^A-Za-z0-9_\\-]"), "_").ifBlank { "project" }
                            exportJsonLauncher.launch("${safe}.forge.json")
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(Modifier.size(4.dp))
                        Text("Export File")
                    }
                }

                OutlinedButton(
                    onClick = { importJsonLauncher.launch(arrayOf("application/json", "*/*")) },
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Icon(Icons.Default.FileUpload, contentDescription = null, modifier = Modifier.size(15.dp))
                    Spacer(Modifier.size(6.dp))
                    Text("Import .forge.json Project File")
                }

                HorizontalDivider(color = ForgeBorder)
                Text("Create New Project", style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary)
                OutlinedTextField(
                    value = newName,
                    onValueChange = { newName = it },
                    placeholder = { Text("New World Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    Button(
                        onClick = {
                            onCreateNew(newName.ifBlank { "Sky Citadel" }, true)
                            onDismiss()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                        Text("Citadel")
                    }
                    OutlinedButton(
                        onClick = {
                            onCreateNew(newName.ifBlank { "Blank Baseplate" }, false)
                            onDismiss()
                        },
                        modifier = Modifier.weight(1f)
                    ) {
                        Text("Baseplate")
                    }
                }

                HorizontalDivider(color = ForgeBorder)
                Text("Saved Cloud Projects (Firestore)", style = MaterialTheme.typography.labelMedium, color = ForgePurple)

                when (cloudProjectsState) {
                    is CloudProjectsUiState.Loading -> {
                        Box(Modifier.fillMaxWidth().padding(12.dp), contentAlignment = Alignment.Center) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp))
                        }
                    }
                    is CloudProjectsUiState.Error -> {
                        Text(cloudProjectsState.message, style = MaterialTheme.typography.bodySmall, color = ForgeRed)
                    }
                    is CloudProjectsUiState.Success -> {
                        if (cloudProjectsState.projects.isEmpty()) {
                            Text("No cloud projects yet. Tap 'Save to Cloud' to store this scene.", style = MaterialTheme.typography.bodySmall, color = ForgeTextMuted)
                        } else {
                            cloudProjectsState.projects.forEach { proj ->
                                Surface(
                                    color = ForgeSurface,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth().border(1.dp, ForgeBorder, RoundedCornerShape(8.dp))
                                ) {
                                    Row(
                                        modifier = Modifier.padding(8.dp),
                                        verticalAlignment = Alignment.CenterVertically,
                                        horizontalArrangement = Arrangement.SpaceBetween
                                    ) {
                                        Column(modifier = Modifier.weight(1f)) {
                                            Text(proj.name, style = MaterialTheme.typography.titleSmall, color = ForgeTextPrimary)
                                            Text("${proj.objectCount} objects • ${proj.scriptCount} scripts", style = MaterialTheme.typography.labelSmall, color = ForgeTextMuted)
                                        }
                                        Row {
                                            TextButton(onClick = {
                                                onLoadCloudProject(proj)
                                                onDismiss()
                                            }) { Text("Load") }
                                            IconButton(onClick = { onDeleteCloudProject(proj.id) }) {
                                                Icon(Icons.Default.Delete, contentDescription = "Delete Project", tint = ForgeRed, modifier = Modifier.size(18.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Close") }
        }
    )
}

@Composable
fun AiSettingsDialog(
    settings: StudioSettings,
    connectionStatus: String,
    isTestingConnection: Boolean,
    onDismiss: () -> Unit,
    onSelectAiModel: (AiModelChoice) -> Unit,
    onSelectImageModel: (ImageModelChoice) -> Unit,
    onChangeTemperature: (Float) -> Unit,
    onToggleAiEnabled: (Boolean) -> Unit,
    onUpdateExternal3dUrl: (String) -> Unit,
    onTestConnection: () -> Unit
) {
    var extUrl by remember(settings.external3dProviderUrl) { mutableStateOf(settings.external3dProviderUrl) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = ForgePanel,
        title = { Text("Gemini AI & Engine Settings", color = ForgeTextPrimary) },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 480.dp)
                    .verticalScroll(rememberScrollState()),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Surface(
                    color = ForgeSurface,
                    shape = RoundedCornerShape(8.dp),
                    modifier = Modifier.fillMaxWidth().border(1.dp, ForgeBorder, RoundedCornerShape(8.dp))
                ) {
                    Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = ForgeEmerald, modifier = Modifier.size(16.dp))
                            Text("Provider: Firebase AI Logic + App Check", style = MaterialTheme.typography.labelMedium, color = ForgeTextPrimary)
                        }
                        Text(
                            text = "No client API key is stored or exposed in APK code. Authentication and rate attestation are handled by Firebase App Check.",
                            style = MaterialTheme.typography.bodySmall,
                            color = ForgeTextSecondary
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text("Enable Gemini AI Mode", style = MaterialTheme.typography.bodyMedium, color = ForgeTextPrimary)
                        Text("Turn off to run Forge AI Studio in pure offline 3D editor mode", style = MaterialTheme.typography.labelSmall, color = ForgeTextMuted)
                    }
                    Switch(checked = settings.aiEnabled, onCheckedChange = onToggleAiEnabled)
                }

                HorizontalDivider(color = ForgeBorder)
                Text("Gemini Scene & Luau Model", style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary)
                AiModelChoice.entries.forEach { choice ->
                    val active = settings.aiModel == choice
                    Surface(
                        onClick = { onSelectAiModel(choice) },
                        color = if (active) ForgeBlue.copy(alpha = 0.22f) else ForgeSurface,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, if (active) ForgeBlue else ForgeBorder, RoundedCornerShape(8.dp))
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text(choice.displayName, style = MaterialTheme.typography.titleSmall, color = ForgeTextPrimary)
                            Text("${choice.modelId} • ${choice.tierHint}", style = MaterialTheme.typography.labelSmall, color = ForgeTextSecondary)
                        }
                    }
                }

                Text("Image / Texture Model", style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary)
                ImageModelChoice.entries.forEach { choice ->
                    val active = settings.imageModel == choice
                    Surface(
                        onClick = { onSelectImageModel(choice) },
                        color = if (active) ForgePurple.copy(alpha = 0.22f) else ForgeSurface,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .border(1.dp, if (active) ForgePurple else ForgeBorder, RoundedCornerShape(8.dp))
                    ) {
                        Text(choice.displayName, style = MaterialTheme.typography.bodySmall, color = ForgeTextPrimary, modifier = Modifier.padding(8.dp))
                    }
                }

                Text("Creativity Temperature: ${String.format("%.2f", settings.temperature)}", style = MaterialTheme.typography.labelMedium, color = ForgeTextSecondary)
                Slider(
                    value = settings.temperature,
                    onValueChange = onChangeTemperature,
                    valueRange = 0f..1.4f
                )

                Button(
                    onClick = onTestConnection,
                    enabled = !isTestingConnection,
                    colors = ButtonDefaults.buttonColors(containerColor = ForgeEmerald),
                    modifier = Modifier.fillMaxWidth().testTag("test_ai_connection_button")
                ) {
                    if (isTestingConnection) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = ForgeTextPrimary)
                        Spacer(Modifier.size(6.dp))
                    }
                    Text("Test Gemini Connection")
                }
                Text(connectionStatus, style = MaterialTheme.typography.labelSmall, color = ForgeTextSecondary)

                HorizontalDivider(color = ForgeBorder)
                OutlinedTextField(
                    value = extUrl,
                    onValueChange = {
                        extUrl = it
                        onUpdateExternal3dUrl(it)
                    },
                    label = { Text("External 3D Mesh Provider URL (Optional)") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) { Text("Done") }
        }
    )
}
