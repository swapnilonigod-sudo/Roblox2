package com.example.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val ForgeDarkColorScheme = darkColorScheme(
    primary = ForgeBlue,
    onPrimary = ForgeTextPrimary,
    primaryContainer = ForgeBlueContainer,
    onPrimaryContainer = ForgeBlueBright,
    secondary = ForgePurple,
    onSecondary = ForgeTextPrimary,
    secondaryContainer = ForgePurpleContainer,
    onSecondaryContainer = ForgePurpleBright,
    tertiary = ForgeCyan,
    onTertiary = ForgeBackground,
    background = ForgeBackground,
    onBackground = ForgeTextPrimary,
    surface = ForgePanel,
    onSurface = ForgeTextPrimary,
    surfaceVariant = ForgeSurface,
    onSurfaceVariant = ForgeTextSecondary,
    outline = ForgeBorder,
    outlineVariant = ForgeBorderBright,
    error = ForgeRed,
    onError = ForgeTextPrimary,
    errorContainer = ForgeRedContainer,
    onErrorContainer = Color(0xFFFCA5A5)
)

private val ForgeShapes = Shapes(
    extraSmall = RoundedCornerShape(4.dp),
    small = RoundedCornerShape(6.dp),
    medium = RoundedCornerShape(10.dp),
    large = RoundedCornerShape(14.dp),
    extraLarge = RoundedCornerShape(20.dp)
)

@Composable
fun ForgeStudioTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = ForgeDarkColorScheme,
        typography = ForgeTypography,
        shapes = ForgeShapes,
        content = content
    )
}
