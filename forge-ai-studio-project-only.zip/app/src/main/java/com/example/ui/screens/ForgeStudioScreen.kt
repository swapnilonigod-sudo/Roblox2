package com.example.ui.screens

import android.app.Application
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxWithConstraints
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountTree
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.ExpandLess
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.IosShare
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.VerticalDivider
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.credentials.CredentialManager
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.ProjectRepository
import com.example.data.SettingsDataStore
import com.example.firebase.signOutUser
import com.example.model.LogLevel
import com.example.model.SceneNode
import com.example.ui.components.AiSettingsDialog
import com.example.ui.components.AiStudioPanel
import com.example.ui.components.AssetLibraryAndBuilderPanel
import com.example.ui.components.ConsolePanel
import com.example.ui.components.ExportCenterPanel
import com.example.ui.components.ProjectsDialog
import com.example.ui.components.PropertiesInspectorPanel
import com.example.ui.components.SceneExplorerPanel
import com.example.ui.components.ScriptEditorPanel
import com.example.ui.components.TopToolbar
import com.example.ui.components.ViewportSection
import com.example.ui.theme.ForgeBackground
import com.example.ui.theme.ForgeBlue
import com.example.ui.theme.ForgeBorder
import com.example.ui.theme.ForgeEmerald
import com.example.ui.theme.ForgePanel
import com.example.ui.theme.ForgePurple
import com.example.ui.theme.ForgeSurface
import com.example.ui.theme.ForgeTextMuted
import com.example.ui.theme.ForgeTextPrimary
import com.example.ui.theme.ForgeTextSecondary
import com.example.viewmodel.ForgeStudioViewModel
import kotlinx.coroutines.delay

private enum class CompactStudioTab(val label: String, val icon: ImageVector) {
    VIEWPORT("Viewport", Icons.Default.ViewInAr),
    EXPLORER("Explorer", Icons.Default.AccountTree),
    INSPECTOR("Inspect", Icons.Default.Tune),
    AI_STUDIO("AI", Icons.Default.AutoAwesome),
    SCRIPTS("Scripts", Icons.Default.Code),
    EXPORT("Export", Icons.Default.IosShare)
}

@Composable
fun ForgeStudioScreen(
    currentUserId: String
) {
    val context = LocalContext.current
    val app = context.applicationContext as Application
    val scope = rememberCoroutineScope()
    val credentialManager = remember { CredentialManager.create(context) }

    val viewModel: ForgeStudioViewModel = viewModel(
        key = currentUserId,
        factory = ForgeStudioViewModel.provideFactory(
            currentUserId = currentUserId,
            projectRepository = ProjectRepository(app),
            settingsDataStore = SettingsDataStore(app)
        )
    )

    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val settings by viewModel.settings.collectAsStateWithLifecycle()
    val cloudProjects by viewModel.cloudProjects.collectAsStateWithLifecycle()

    var showProjectsDialog by remember { mutableStateOf(false) }
    var showSettingsDialog by remember { mutableStateOf(false) }
    var isFloatingAiOpen by remember { mutableStateOf(false) }
    var compactTab by remember { mutableStateOf(CompactStudioTab.VIEWPORT) }

    var leftPanelTab by remember { mutableIntStateOf(0) }
    var bottomPanelTab by remember { mutableIntStateOf(0) }
    var isBottomCollapsed by remember { mutableStateOf(false) }
    var exportConsoleSubTab by remember { mutableIntStateOf(0) }

    // Auto-dismiss transient status banner after 4.5 seconds
    LaunchedEffect(uiState.statusBanner) {
        if (uiState.statusBanner != null) {
            delay(4500L)
            viewModel.dismissBanner()
        }
    }

    BackHandler(enabled = showProjectsDialog || showSettingsDialog || isFloatingAiOpen || compactTab != CompactStudioTab.VIEWPORT) {
        when {
            showProjectsDialog -> showProjectsDialog = false
            showSettingsDialog -> showSettingsDialog = false
            isFloatingAiOpen -> isFloatingAiOpen = false
            compactTab != CompactStudioTab.VIEWPORT -> compactTab = CompactStudioTab.VIEWPORT
        }
    }

    val selectedNode = remember(uiState.nodes, uiState.selectedNodeId) {
        uiState.nodes.firstOrNull { it.id == uiState.selectedNodeId }
    }
    val allFolders = remember(uiState.nodes) {
        uiState.nodes.filter { it.isFolder }
    }

    Surface(
        color = ForgeBackground,
        modifier = Modifier
            .fillMaxSize()
            .imePadding()
    ) {
        BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
            val isWideStudio = maxWidth >= 840.dp

            Column(modifier = Modifier.fillMaxSize()) {
                TopToolbar(
                    projectName = uiState.projectName,
                    isDirty = uiState.isDirty,
                    isSaving = uiState.isSavingCloud,
                    canUndo = uiState.canUndo,
                    canRedo = uiState.canRedo,
                    hasSelection = uiState.selectedNodeId != null,
                    isPlaying = uiState.isPlaying,
                    aiEnabled = settings.aiEnabled,
                    isFloatingAiOpen = isFloatingAiOpen,
                    onOpenProjects = { showProjectsDialog = true },
                    onSaveProject = { viewModel.saveProjectToCloud() },
                    onUndo = { viewModel.undo() },
                    onRedo = { viewModel.redo() },
                    onDuplicate = { viewModel.duplicateSelected() },
                    onDelete = { viewModel.deleteSelected() },
                    onInsertShape = { shape -> viewModel.insertPrimitive(shape) },
                    onTogglePlay = { viewModel.togglePlayMode() },
                    onResetPlay = { viewModel.resetPlayCharacter() },
                    onOpenExport = {
                        if (isWideStudio) {
                            isBottomCollapsed = false
                            bottomPanelTab = 2
                        } else {
                            exportConsoleSubTab = 0
                            compactTab = CompactStudioTab.EXPORT
                        }
                    },
                    onToggleFloatingAi = {
                        isFloatingAiOpen = !isFloatingAiOpen
                    },
                    onOpenSettings = { showSettingsDialog = true },
                    onSignOut = { signOutUser(credentialManager, scope) }
                )

                if (isWideStudio) {
                    // Desktop / Tablet 4-Pane Game Engine Workspace
                    Row(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                            .navigationBarsPadding()
                    ) {
                        // Left Panel: Scene Explorer & Asset Library / 3D Asset Builder
                        Column(
                            modifier = Modifier
                                .width(280.dp)
                                .fillMaxHeight()
                                .background(ForgePanel)
                        ) {
                            TabRow(
                                selectedTabIndex = leftPanelTab,
                                containerColor = ForgePanel,
                                contentColor = ForgeBlue
                            ) {
                                Tab(
                                    selected = leftPanelTab == 0,
                                    onClick = { leftPanelTab = 0 },
                                    text = { Text("Explorer", maxLines = 1, overflow = TextOverflow.Ellipsis) }
                                )
                                Tab(
                                    selected = leftPanelTab == 1,
                                    onClick = { leftPanelTab = 1 },
                                    text = { Text("Assets & Build", maxLines = 1, overflow = TextOverflow.Ellipsis) }
                                )
                            }
                            if (leftPanelTab == 0) {
                                SceneExplorerPanel(
                                    nodes = uiState.nodes,
                                    selectedNodeId = uiState.selectedNodeId,
                                    onSelectNode = { viewModel.selectNode(it) },
                                    onToggleExpanded = { viewModel.toggleFolderExpanded(it) },
                                    onToggleVisibility = { viewModel.toggleNodeVisibility(it) },
                                    onCreateFolder = { viewModel.createFolder(it) },
                                    onRenameNode = { id, name -> viewModel.updateNode(id) { it.copy(name = name) } },
                                    onDuplicateSelected = { viewModel.duplicateSelected() },
                                    onDeleteSelected = { viewModel.deleteSelected() }
                                )
                            } else {
                                AssetLibraryAndBuilderPanel(
                                    importedAssets = uiState.importedAssets,
                                    external3dProviderUrl = settings.external3dProviderUrl,
                                    onInsertCatalogAsset = { viewModel.insertCatalogAsset(it) },
                                    onBuildCustomAsset = { name, kind, shape, scale, colorHex, mat, mesh ->
                                        viewModel.insertCustomBuiltPart(name, kind, shape, scale, colorHex, mat, mesh)
                                    },
                                    onImportObjFile = { fileName, content -> viewModel.importObjText(fileName, content) },
                                    onRequestAiAssetBuild = { prompt -> viewModel.executeAiSceneCommand(prompt) }
                                )
                            }
                        }

                        VerticalDivider(color = ForgeBorder)

                        // Center Column: 3D Viewport + Collapsible Bottom Panel (Console / Luau Scripts / Export Center)
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .fillMaxHeight()
                        ) {
                            ViewportSection(
                                uiState = uiState,
                                showGrid = settings.showGrid,
                                showCollisions = settings.showCollisions,
                                snapEnabled = settings.snapEnabled,
                                onToggleGrid = { viewModel.setShowGrid(it) },
                                onToggleCollisions = { viewModel.setShowCollisions(it) },
                                onToggleSnap = { viewModel.setSnapEnabled(it) },
                                onSelectTool = { viewModel.setActiveTool(it) },
                                onSelectAxis = { viewModel.setAxisConstraint(it) },
                                onSelectNode = { viewModel.selectNode(it) },
                                onTransformLive = { id, p, r, s -> viewModel.onLiveTransform(id, p, r, s) },
                                onTransformCommit = { viewModel.onCommitLiveTransform() },
                                onPlayLookDelta = { viewModel.addPlayYawDelta(it) },
                                onPlayJoystick = { x, y -> viewModel.setJoystickInput(x, y) },
                                onPlayJump = { viewModel.jumpPlayCharacter() },
                                onPlayCameraMode = { viewModel.setPlayCameraMode(it) },
                                onFpsMeasured = { viewModel.updateViewportFps(it) },
                                onCommandBarChange = { viewModel.updateCommandBarText(it) },
                                onExecuteAiCommand = { viewModel.executeAiSceneCommand(it) },
                                onToggleVoiceCommand = { viewModel.toggleAudioVoiceCommand() },
                                modifier = Modifier
                                    .weight(1f)
                                    .fillMaxWidth()
                            )

                            HorizontalDivider(color = ForgeBorder)

                            // Bottom Panel Header Strip
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .background(ForgePanel)
                                    .padding(horizontal = 8.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(modifier = Modifier.weight(1f)) {
                                    TabRow(
                                        selectedTabIndex = bottomPanelTab,
                                        containerColor = ForgePanel,
                                        contentColor = ForgePurple
                                    ) {
                                        Tab(
                                            selected = bottomPanelTab == 0,
                                            onClick = { bottomPanelTab = 0; isBottomCollapsed = false },
                                            text = { Text("Console (${uiState.consoleLogs.size})", maxLines = 1) }
                                        )
                                        Tab(
                                            selected = bottomPanelTab == 1,
                                            onClick = { bottomPanelTab = 1; isBottomCollapsed = false },
                                            text = { Text("Luau Scripts (${uiState.scripts.size})", maxLines = 1) }
                                        )
                                        Tab(
                                            selected = bottomPanelTab == 2,
                                            onClick = { bottomPanelTab = 2; isBottomCollapsed = false },
                                            text = { Text("Roblox Export", maxLines = 1) }
                                        )
                                    }
                                }
                                IconButton(
                                    onClick = { isBottomCollapsed = !isBottomCollapsed },
                                    modifier = Modifier.testTag("toggle_bottom_panel")
                                ) {
                                    Icon(
                                        imageVector = if (isBottomCollapsed) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                                        contentDescription = if (isBottomCollapsed) "Expand Bottom Panel" else "Collapse Bottom Panel",
                                        tint = ForgeTextSecondary
                                    )
                                }
                            }

                            if (!isBottomCollapsed) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(235.dp)
                                ) {
                                    when (bottomPanelTab) {
                                        0 -> ConsolePanel(
                                            logs = uiState.consoleLogs,
                                            onClear = { viewModel.clearConsole() }
                                        )
                                        1 -> ScriptEditorPanel(
                                            scripts = uiState.scripts,
                                            activeScriptId = uiState.activeScriptId,
                                            isAiBusy = uiState.isAiBusy,
                                            aiExplanation = uiState.luauAiExplanation,
                                            onSelectScript = { viewModel.selectScript(it) },
                                            onCreateScript = { name, type -> viewModel.createNewScript(name, type) },
                                            onDeleteActiveScript = { viewModel.deleteActiveScript() },
                                            onUpdateCode = { viewModel.updateActiveScriptCode(it) },
                                            onAskLuauAssistant = { p, mod -> viewModel.askLuauAssistant(p, mod) }
                                        )
                                        else -> ExportCenterPanel(
                                            projectName = uiState.projectName,
                                            hasSelection = uiState.selectedNodeId != null,
                                            scaleMultiplier = uiState.exportScaleMultiplier,
                                            report = uiState.compatibilityReport,
                                            onSetScaleMultiplier = { viewModel.setExportScaleMultiplier(it) },
                                            onRefreshCheck = { viewModel.refreshCompatibilityReport() },
                                            onBuildGlb = { viewModel.buildGlbBytes(it) },
                                            onBuildGltf = { viewModel.buildGltfText(it) },
                                            onBuildObj = { viewModel.buildObjText(it) },
                                            onBuildManifest = { viewModel.buildManifestText() },
                                            onLogExport = { msg -> viewModel.log(LogLevel.INFO, "Exporter", msg) }
                                        )
                                    }
                                }
                            }
                        }

                        VerticalDivider(color = ForgeBorder)

                        // Right Panel: Properties Inspector
                        PropertiesInspectorPanel(
                            selectedNode = selectedNode,
                            allFolders = allFolders,
                            lighting = uiState.lighting,
                            onUpdateNode = { id, fn -> viewModel.updateNode(id, fn) },
                            onUpdateLighting = { fn -> viewModel.updateLighting(fn) },
                            onApplyTimeOfDay = { viewModel.applyTimeOfDay(it) },
                            modifier = Modifier
                                .width(290.dp)
                                .fillMaxHeight()
                        )
                    }
                } else {
                    // Compact / Handheld Phone Layout
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .fillMaxWidth()
                    ) {
                        when (compactTab) {
                            CompactStudioTab.VIEWPORT -> {
                                ViewportSection(
                                    uiState = uiState,
                                    showGrid = settings.showGrid,
                                    showCollisions = settings.showCollisions,
                                    snapEnabled = settings.snapEnabled,
                                    onToggleGrid = { viewModel.setShowGrid(it) },
                                    onToggleCollisions = { viewModel.setShowCollisions(it) },
                                    onToggleSnap = { viewModel.setSnapEnabled(it) },
                                    onSelectTool = { viewModel.setActiveTool(it) },
                                    onSelectAxis = { viewModel.setAxisConstraint(it) },
                                    onSelectNode = { viewModel.selectNode(it) },
                                    onTransformLive = { id, p, r, s -> viewModel.onLiveTransform(id, p, r, s) },
                                    onTransformCommit = { viewModel.onCommitLiveTransform() },
                                    onPlayLookDelta = { viewModel.addPlayYawDelta(it) },
                                    onPlayJoystick = { x, y -> viewModel.setJoystickInput(x, y) },
                                    onPlayJump = { viewModel.jumpPlayCharacter() },
                                    onPlayCameraMode = { viewModel.setPlayCameraMode(it) },
                                    onFpsMeasured = { viewModel.updateViewportFps(it) },
                                    onCommandBarChange = { viewModel.updateCommandBarText(it) },
                                    onExecuteAiCommand = { viewModel.executeAiSceneCommand(it) },
                                    onToggleVoiceCommand = { viewModel.toggleAudioVoiceCommand() },
                                    modifier = Modifier.fillMaxSize()
                                )
                            }
                            CompactStudioTab.EXPLORER -> {
                                Column(modifier = Modifier.fillMaxSize()) {
                                    TabRow(
                                        selectedTabIndex = leftPanelTab,
                                        containerColor = ForgePanel,
                                        contentColor = ForgeBlue
                                    ) {
                                        Tab(
                                            selected = leftPanelTab == 0,
                                            onClick = { leftPanelTab = 0 },
                                            text = { Text("Scene Explorer") }
                                        )
                                        Tab(
                                            selected = leftPanelTab == 1,
                                            onClick = { leftPanelTab = 1 },
                                            text = { Text("Assets & Builder") }
                                        )
                                    }
                                    if (leftPanelTab == 0) {
                                        SceneExplorerPanel(
                                            nodes = uiState.nodes,
                                            selectedNodeId = uiState.selectedNodeId,
                                            onSelectNode = { viewModel.selectNode(it) },
                                            onToggleExpanded = { viewModel.toggleFolderExpanded(it) },
                                            onToggleVisibility = { viewModel.toggleNodeVisibility(it) },
                                            onCreateFolder = { viewModel.createFolder(it) },
                                            onRenameNode = { id, name -> viewModel.updateNode(id) { it.copy(name = name) } },
                                            onDuplicateSelected = { viewModel.duplicateSelected() },
                                            onDeleteSelected = { viewModel.deleteSelected() }
                                        )
                                    } else {
                                        AssetLibraryAndBuilderPanel(
                                            importedAssets = uiState.importedAssets,
                                            external3dProviderUrl = settings.external3dProviderUrl,
                                            onInsertCatalogAsset = {
                                                viewModel.insertCatalogAsset(it)
                                                compactTab = CompactStudioTab.VIEWPORT
                                            },
                                            onBuildCustomAsset = { name, kind, shape, scale, colorHex, mat, mesh ->
                                                viewModel.insertCustomBuiltPart(name, kind, shape, scale, colorHex, mat, mesh)
                                                compactTab = CompactStudioTab.VIEWPORT
                                            },
                                            onImportObjFile = { fileName, content -> viewModel.importObjText(fileName, content) },
                                            onRequestAiAssetBuild = { prompt -> viewModel.executeAiSceneCommand(prompt) }
                                        )
                                    }
                                }
                            }
                            CompactStudioTab.INSPECTOR -> {
                                PropertiesInspectorPanel(
                                    selectedNode = selectedNode,
                                    allFolders = allFolders,
                                    lighting = uiState.lighting,
                                    onUpdateNode = { id, fn -> viewModel.updateNode(id, fn) },
                                    onUpdateLighting = { fn -> viewModel.updateLighting(fn) },
                                    onApplyTimeOfDay = { viewModel.applyTimeOfDay(it) }
                                )
                            }
                            CompactStudioTab.AI_STUDIO -> {
                                AiStudioPanel(
                                    uiState = uiState,
                                    aiEnabled = settings.aiEnabled,
                                    onExecuteSceneCommand = { viewModel.executeAiSceneCommand(it) },
                                    onGenerateWorld = { viewModel.executeAiSceneCommand(it, isWorldGeneration = true) },
                                    onRegenerateRegion = { viewModel.regenerateRegion(it) },
                                    onSendChatMessage = { viewModel.sendChatMessage(it) },
                                    onGenerateTextureImage = { p, asp, res -> viewModel.generateTextureOrConceptArt(p, asp, res) },
                                    onAnalyzeVideo = { bytes, mime, prompt -> viewModel.analyzeVideoClip(bytes, mime, prompt) }
                                )
                            }
                            CompactStudioTab.SCRIPTS -> {
                                ScriptEditorPanel(
                                    scripts = uiState.scripts,
                                    activeScriptId = uiState.activeScriptId,
                                    isAiBusy = uiState.isAiBusy,
                                    aiExplanation = uiState.luauAiExplanation,
                                    onSelectScript = { viewModel.selectScript(it) },
                                    onCreateScript = { name, type -> viewModel.createNewScript(name, type) },
                                    onDeleteActiveScript = { viewModel.deleteActiveScript() },
                                    onUpdateCode = { viewModel.updateActiveScriptCode(it) },
                                    onAskLuauAssistant = { p, mod -> viewModel.askLuauAssistant(p, mod) }
                                )
                            }
                            CompactStudioTab.EXPORT -> {
                                Column(modifier = Modifier.fillMaxSize()) {
                                    TabRow(
                                        selectedTabIndex = exportConsoleSubTab,
                                        containerColor = ForgePanel,
                                        contentColor = ForgeEmerald
                                    ) {
                                        Tab(
                                            selected = exportConsoleSubTab == 0,
                                            onClick = { exportConsoleSubTab = 0 },
                                            text = { Text("Roblox Export") }
                                        )
                                        Tab(
                                            selected = exportConsoleSubTab == 1,
                                            onClick = { exportConsoleSubTab = 1 },
                                            text = { Text("Console (${uiState.consoleLogs.size})") }
                                        )
                                    }
                                    if (exportConsoleSubTab == 0) {
                                        ExportCenterPanel(
                                            projectName = uiState.projectName,
                                            hasSelection = uiState.selectedNodeId != null,
                                            scaleMultiplier = uiState.exportScaleMultiplier,
                                            report = uiState.compatibilityReport,
                                            onSetScaleMultiplier = { viewModel.setExportScaleMultiplier(it) },
                                            onRefreshCheck = { viewModel.refreshCompatibilityReport() },
                                            onBuildGlb = { viewModel.buildGlbBytes(it) },
                                            onBuildGltf = { viewModel.buildGltfText(it) },
                                            onBuildObj = { viewModel.buildObjText(it) },
                                            onBuildManifest = { viewModel.buildManifestText() },
                                            onLogExport = { msg -> viewModel.log(LogLevel.INFO, "Exporter", msg) }
                                        )
                                    } else {
                                        ConsolePanel(
                                            logs = uiState.consoleLogs,
                                            onClear = { viewModel.clearConsole() }
                                        )
                                    }
                                }
                            }
                        }
                    }

                    NavigationBar(
                        containerColor = ForgePanel,
                        contentColor = ForgeTextPrimary,
                        modifier = Modifier.navigationBarsPadding()
                    ) {
                        CompactStudioTab.entries.forEach { tab ->
                            val selected = compactTab == tab
                            NavigationBarItem(
                                selected = selected,
                                onClick = { compactTab = tab },
                                icon = {
                                    Icon(
                                        imageVector = tab.icon,
                                        contentDescription = tab.label,
                                        modifier = Modifier.size(20.dp)
                                    )
                                },
                                label = {
                                    Text(
                                        text = tab.label,
                                        style = MaterialTheme.typography.labelSmall,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                },
                                colors = NavigationBarItemDefaults.colors(
                                    selectedIconColor = ForgeBlue,
                                    selectedTextColor = ForgeBlue,
                                    unselectedIconColor = ForgeTextMuted,
                                    unselectedTextColor = ForgeTextMuted,
                                    indicatorColor = ForgeBlue.copy(alpha = 0.16f)
                                ),
                                modifier = Modifier.testTag("nav_${tab.name.lowercase()}")
                            )
                        }
                    }
                }
            }

            // Floating AI Builder Panel Overlay (Tablet & Mobile quick-access floating assistant)
            AnimatedVisibility(
                visible = isFloatingAiOpen,
                enter = fadeIn(),
                exit = fadeOut(),
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .padding(
                        end = if (isWideStudio) 302.dp else 12.dp,
                        start = 12.dp,
                        bottom = if (isWideStudio) 24.dp else 86.dp,
                        top = 108.dp
                    )
            ) {
                Surface(
                    color = ForgePanel,
                    shape = RoundedCornerShape(14.dp),
                    modifier = Modifier
                        .width(if (isWideStudio) 420.dp else 380.dp)
                        .fillMaxHeight(if (isWideStudio) 0.78f else 0.85f)
                        .shadow(16.dp, RoundedCornerShape(14.dp))
                        .border(1.5.dp, ForgePurple.copy(alpha = 0.75f), RoundedCornerShape(14.dp))
                ) {
                    Column(modifier = Modifier.fillMaxSize()) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(ForgeSurface)
                                .padding(horizontal = 12.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = ForgePurple, modifier = Modifier.size(18.dp))
                                Text(
                                    text = "Floating AI Builder",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = ForgeTextPrimary
                                )
                            }
                            IconButton(
                                onClick = { isFloatingAiOpen = false },
                                modifier = Modifier.size(36.dp).testTag("close_floating_ai_button")
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Close AI Panel", tint = ForgeTextSecondary)
                            }
                        }
                        HorizontalDivider(color = ForgeBorder)
                        AiStudioPanel(
                            uiState = uiState,
                            aiEnabled = settings.aiEnabled,
                            onExecuteSceneCommand = { viewModel.executeAiSceneCommand(it) },
                            onGenerateWorld = { viewModel.executeAiSceneCommand(it, isWorldGeneration = true) },
                            onRegenerateRegion = { viewModel.regenerateRegion(it) },
                            onSendChatMessage = { viewModel.sendChatMessage(it) },
                            onGenerateTextureImage = { p, asp, res -> viewModel.generateTextureOrConceptArt(p, asp, res) },
                            onAnalyzeVideo = { bytes, mime, prompt -> viewModel.analyzeVideoClip(bytes, mime, prompt) },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }

            // Transient Studio Status Banner
            uiState.statusBanner?.let { banner ->
                Surface(
                    color = ForgeSurface,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier
                        .align(Alignment.TopCenter)
                        .padding(top = 108.dp, start = 16.dp, end = 16.dp)
                        .shadow(8.dp, RoundedCornerShape(10.dp))
                        .border(1.dp, ForgeBlue.copy(alpha = 0.7f), RoundedCornerShape(10.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(
                            text = banner,
                            style = MaterialTheme.typography.bodySmall,
                            color = ForgeTextPrimary,
                            modifier = Modifier.weight(1f, fill = false)
                        )
                        TextButton(onClick = { viewModel.dismissBanner() }) {
                            Text("OK", color = ForgeBlue)
                        }
                    }
                }
            }
        }
    }

    if (showProjectsDialog) {
        ProjectsDialog(
            currentProjectName = uiState.projectName,
            cloudProjectsState = cloudProjects,
            onDismiss = { showProjectsDialog = false },
            onCreateNew = { name, useCitadel -> viewModel.newBlankProject(name, useCitadel) },
            onRenameCurrent = { viewModel.renameCurrentProject(it) },
            onSaveToCloud = { viewModel.saveProjectToCloud() },
            onLoadCloudProject = { viewModel.loadCloudProject(it) },
            onDeleteCloudProject = { viewModel.deleteCloudProject(it) },
            onBuildProjectJson = { viewModel.buildProjectFileJson() },
            onImportProjectJson = { viewModel.importProjectFileJson(it) }
        )
    }

    if (showSettingsDialog) {
        AiSettingsDialog(
            settings = settings,
            connectionStatus = uiState.aiConnectionStatus,
            isTestingConnection = uiState.isTestingConnection,
            onDismiss = { showSettingsDialog = false },
            onSelectAiModel = { viewModel.setAiModel(it) },
            onSelectImageModel = { viewModel.setImageModel(it) },
            onChangeTemperature = { viewModel.setTemperature(it) },
            onToggleAiEnabled = { viewModel.setAiEnabled(it) },
            onUpdateExternal3dUrl = { viewModel.setExternal3dUrl(it) },
            onTestConnection = { viewModel.testAiConnection() }
        )
    }
}
