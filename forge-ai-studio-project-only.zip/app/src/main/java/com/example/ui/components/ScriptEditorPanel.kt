package com.example.ui.components

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Download
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import com.example.model.LuauScript
import com.example.ui.theme.ForgeAmber
import com.example.ui.theme.ForgeBackground
import com.example.ui.theme.ForgeBlue
import com.example.ui.theme.ForgeBorder
import com.example.ui.theme.ForgeCyan
import com.example.ui.theme.ForgeEmerald
import com.example.ui.theme.ForgePanel
import com.example.ui.theme.ForgePurple
import com.example.ui.theme.ForgeRed
import com.example.ui.theme.ForgeSurface
import com.example.ui.theme.ForgeTextMuted
import com.example.ui.theme.ForgeTextPrimary
import com.example.ui.theme.ForgeTextSecondary
import com.example.ui.theme.JetBrainsMonoFontFamily

@Composable
fun ScriptEditorPanel(
    scripts: List<LuauScript>,
    activeScriptId: String?,
    isAiBusy: Boolean,
    aiExplanation: String?,
    onSelectScript: (String) -> Unit,
    onCreateScript: (String, String) -> Unit,
    onDeleteActiveScript: () -> Unit,
    onUpdateCode: (String) -> Unit,
    onAskLuauAssistant: (String, Boolean) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val clipboard = LocalClipboardManager.current
    val activeScript = scripts.firstOrNull { it.id == activeScriptId } ?: scripts.firstOrNull()
    var aiPrompt by remember { mutableStateOf("") }
    var searchQuery by remember { mutableStateOf("") }
    var showPreviewSyntax by remember { mutableStateOf(false) }

    val saveLuauLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("text/plain")
    ) { uri ->
        if (uri != null && activeScript != null) {
            try {
                context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use {
                    it.write(activeScript.code)
                }
            } catch (_: Exception) {
            }
        }
    }

    val quickTemplates = listOf(
        "Create a sprint system",
        "Create an NPC dialogue script",
        "Make a simple inventory system",
        "Create a door proximity script",
        "Create a teleport pad system",
        "Create a PvP sword combat system"
    )

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(ForgePanel)
    ) {
        // Script Tabs
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .background(ForgeBackground)
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 8.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            scripts.forEach { scr ->
                val active = scr.id == activeScript?.id
                Surface(
                    onClick = { onSelectScript(scr.id) },
                    color = if (active) ForgeBlue.copy(alpha = 0.25f) else ForgeSurface,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.border(1.dp, if (active) ForgeBlue else ForgeBorder, RoundedCornerShape(6.dp))
                ) {
                    Text(
                        text = "${scr.name} (${scr.scriptType})",
                        style = MaterialTheme.typography.labelMedium,
                        color = if (active) ForgeTextPrimary else ForgeTextSecondary,
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                    )
                }
            }
            IconButton(
                onClick = { onCreateScript("Script_${scripts.size + 1}.luau", "Script") },
                modifier = Modifier.size(36.dp).testTag("new_script_button")
            ) {
                Icon(Icons.Default.Add, contentDescription = "New Script", tint = ForgeEmerald)
            }
        }

        // Toolbar row: Search, Copy, Download, Syntax view toggle
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Search code...", style = MaterialTheme.typography.bodySmall) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp)) },
                singleLine = true,
                modifier = Modifier.weight(1f)
            )
            Surface(
                onClick = { showPreviewSyntax = !showPreviewSyntax },
                color = if (showPreviewSyntax) ForgePurple else ForgeSurface,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier.border(1.dp, ForgeBorder, RoundedCornerShape(6.dp))
            ) {
                Text(
                    text = if (showPreviewSyntax) "Edit" else "Highlight",
                    style = MaterialTheme.typography.labelMedium,
                    color = ForgeTextPrimary,
                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 10.dp)
                )
            }
            IconButton(
                onClick = {
                    activeScript?.let { clipboard.setText(AnnotatedString(it.code)) }
                },
                enabled = activeScript != null
            ) {
                Icon(Icons.Default.ContentCopy, contentDescription = "Copy Script", tint = ForgeTextPrimary)
            }
            IconButton(
                onClick = {
                    activeScript?.let { saveLuauLauncher.launch(it.name) }
                },
                enabled = activeScript != null
            ) {
                Icon(Icons.Default.Download, contentDescription = "Download .luau", tint = ForgeEmerald)
            }
            IconButton(
                onClick = onDeleteActiveScript,
                enabled = activeScript != null
            ) {
                Icon(Icons.Default.Delete, contentDescription = "Delete Script", tint = ForgeRed)
            }
        }

        if (activeScript != null) {
            Text(
                text = "Target Roblox Service: ${activeScript.parentTarget} • Designed for Roblox Studio (local preview does not execute Luau)",
                style = MaterialTheme.typography.labelSmall,
                color = ForgeTextMuted,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 2.dp)
            )
        }

        // Code Editor / Highlighted View
        Box(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 4.dp)
                .background(ForgeBackground, RoundedCornerShape(8.dp))
                .border(1.dp, ForgeBorder, RoundedCornerShape(8.dp))
        ) {
            if (activeScript == null) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("No script selected. Tap + or generate one with AI below.", color = ForgeTextMuted)
                }
            } else if (showPreviewSyntax) {
                Text(
                    text = highlightLuau(activeScript.code, searchQuery),
                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = JetBrainsMonoFontFamily),
                    modifier = Modifier
                        .fillMaxSize()
                        .verticalScroll(rememberScrollState())
                        .padding(10.dp)
                )
            } else {
                OutlinedTextField(
                    value = activeScript.code,
                    onValueChange = onUpdateCode,
                    textStyle = MaterialTheme.typography.bodySmall.copy(
                        fontFamily = JetBrainsMonoFontFamily,
                        color = ForgeTextPrimary
                    ),
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("luau_code_editor")
                )
            }
        }

        if (!aiExplanation.isNullOrBlank()) {
            Surface(
                color = ForgeSurface,
                shape = RoundedCornerShape(6.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 4.dp)
                    .border(1.dp, ForgePurple.copy(alpha = 0.5f), RoundedCornerShape(6.dp))
            ) {
                Text(
                    text = aiExplanation,
                    style = MaterialTheme.typography.bodySmall,
                    color = ForgeTextSecondary,
                    maxLines = 3,
                    modifier = Modifier.padding(8.dp)
                )
            }
        }

        HorizontalDivider(color = ForgeBorder)
        // Quick Luau Prompts + AI Script Assistant Bar
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState())
                .padding(horizontal = 10.dp, vertical = 5.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            quickTemplates.forEach { tpl ->
                Surface(
                    onClick = { onAskLuauAssistant(tpl, false) },
                    color = ForgeSurface,
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.border(1.dp, ForgeBorder, RoundedCornerShape(6.dp))
                ) {
                    Text(tpl, style = MaterialTheme.typography.labelSmall, color = ForgeCyan, modifier = Modifier.padding(horizontal = 8.dp, vertical = 5.dp))
                }
            }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 10.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedTextField(
                value = aiPrompt,
                onValueChange = { aiPrompt = it },
                placeholder = { Text("Ask Luau AI (generate, explain, fix)...", style = MaterialTheme.typography.bodySmall) },
                singleLine = true,
                modifier = Modifier.weight(1f).testTag("luau_ai_input")
            )
            Button(
                onClick = {
                    val p = aiPrompt; aiPrompt = ""
                    onAskLuauAssistant(p, false)
                },
                enabled = !isAiBusy && aiPrompt.isNotBlank(),
                colors = ButtonDefaults.buttonColors(containerColor = ForgePurple),
                modifier = Modifier.testTag("luau_generate_button")
            ) {
                if (isAiBusy) CircularProgressIndicator(Modifier.size(14.dp), strokeWidth = 2.dp, color = ForgeTextPrimary)
                else Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(15.dp))
                Spacer(Modifier.size(4.dp))
                Text("New")
            }
            OutlinedButton(
                onClick = {
                    val p = aiPrompt; aiPrompt = ""
                    onAskLuauAssistant(p, true)
                },
                enabled = !isAiBusy && aiPrompt.isNotBlank() && activeScript != null
            ) {
                Text("Modify")
            }
        }
    }
}

private fun highlightLuau(code: String, search: String): AnnotatedString {
    val keywords = setOf(
        "local", "function", "end", "if", "then", "else", "elseif",
        "for", "in", "do", "while", "return", "true", "false", "nil", "and", "or", "not"
    )
    return buildAnnotatedString {
        for (line in code.lines()) {
            val trimmed = line.trimStart()
            if (trimmed.startsWith("--")) {
                withStyle(SpanStyle(color = ForgeTextMuted)) { append(line) }
            } else {
                val tokens = line.split(Regex("(?<=\\W)|(?=\\W)"))
                for (tok in tokens) {
                    val isMatch = search.isNotBlank() && tok.contains(search, ignoreCase = true)
                    when {
                        isMatch -> withStyle(SpanStyle(color = Color.Black, background = ForgeAmber, fontWeight = FontWeight.Bold)) { append(tok) }
                        tok in keywords -> withStyle(SpanStyle(color = ForgePurple, fontWeight = FontWeight.SemiBold)) { append(tok) }
                        tok.toDoubleOrNull() != null -> withStyle(SpanStyle(color = ForgeAmber)) { append(tok) }
                        else -> withStyle(SpanStyle(color = ForgeTextPrimary)) { append(tok) }
                    }
                }
            }
            append("\n")
        }
    }
}
