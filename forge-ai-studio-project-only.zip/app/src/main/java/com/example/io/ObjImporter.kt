package com.example.io

import com.example.model.CustomMeshData
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

object ObjImporter {

    fun parseObj(objText: String): Result<CustomMeshData> {
        return try {
            val positions = mutableListOf<Float>()
            val outVerts = mutableListOf<Float>()
            val outNorms = mutableListOf<Float>()
            val outIndices = mutableListOf<Int>()

            var minX = Float.MAX_VALUE; var minY = Float.MAX_VALUE; var minZ = Float.MAX_VALUE
            var maxX = -Float.MAX_VALUE; var maxY = -Float.MAX_VALUE; var maxZ = -Float.MAX_VALUE

            for (rawLine in objText.lineSequence()) {
                val line = rawLine.trim()
                if (line.isEmpty() || line.startsWith("#")) continue
                val parts = line.split(Regex("\\s+"))
                when (parts[0]) {
                    "v" -> if (parts.size >= 4) {
                        val x = parts[1].toFloatOrNull() ?: 0f
                        val y = parts[2].toFloatOrNull() ?: 0f
                        val z = parts[3].toFloatOrNull() ?: 0f
                        positions.add(x); positions.add(y); positions.add(z)
                        minX = min(minX, x); minY = min(minY, y); minZ = min(minZ, z)
                        maxX = max(maxX, x); maxY = max(maxY, y); maxZ = max(maxZ, z)
                    }
                    "f" -> if (parts.size >= 4) {
                        val faceVertIndices = mutableListOf<Int>()
                        for (i in 1 until parts.size) {
                            val vIdxStr = parts[i].substringBefore('/')
                            val rawIdx = vIdxStr.toIntOrNull() ?: continue
                            val zeroIdx = if (rawIdx > 0) rawIdx - 1 else (positions.size / 3) + rawIdx
                            if (zeroIdx in 0 until (positions.size / 3)) {
                                faceVertIndices.add(zeroIdx)
                            }
                        }
                        if (faceVertIndices.size >= 3) {
                            for (k in 1 until faceVertIndices.size - 1) {
                                val i0 = faceVertIndices[0]
                                val i1 = faceVertIndices[k]
                                val i2 = faceVertIndices[k + 1]
                                val p0x = positions[i0 * 3]; val p0y = positions[i0 * 3 + 1]; val p0z = positions[i0 * 3 + 2]
                                val p1x = positions[i1 * 3]; val p1y = positions[i1 * 3 + 1]; val p1z = positions[i1 * 3 + 2]
                                val p2x = positions[i2 * 3]; val p2y = positions[i2 * 3 + 1]; val p2z = positions[i2 * 3 + 2]

                                val ux = p1x - p0x; val uy = p1y - p0y; val uz = p1z - p0z
                                val vx = p2x - p0x; val vy = p2y - p0y; val vz = p2z - p0z
                                var nx = uy * vz - uz * vy
                                var ny = uz * vx - ux * vz
                                var nz = ux * vy - uy * vx
                                val nLen = sqrt(nx * nx + ny * ny + nz * nz).coerceAtLeast(1e-5f)
                                nx /= nLen; ny /= nLen; nz /= nLen

                                val base = outVerts.size / 3
                                outVerts.addAll(listOf(p0x, p0y, p0z, p1x, p1y, p1z, p2x, p2y, p2z))
                                repeat(3) { outNorms.addAll(listOf(nx, ny, nz)) }
                                outIndices.addAll(listOf(base, base + 1, base + 2))
                            }
                        }
                    }
                }
            }

            if (outIndices.isEmpty()) {
                return Result.failure(IllegalArgumentException("No valid triangle faces found in OBJ file."))
            }

            // Normalize to unit cube centered at origin so scale controls work predictably
            val cx = (minX + maxX) * 0.5f
            val cy = (minY + maxY) * 0.5f
            val cz = (minZ + maxZ) * 0.5f
            val extent = maxOf(maxX - minX, maxY - minY, maxZ - minZ).coerceAtLeast(0.001f)
            for (i in outVerts.indices step 3) {
                outVerts[i] = (outVerts[i] - cx) / extent
                outVerts[i + 1] = (outVerts[i + 1] - cy) / extent
                outVerts[i + 2] = (outVerts[i + 2] - cz) / extent
            }

            Result.success(
                CustomMeshData(
                    vertices = outVerts,
                    normals = outNorms,
                    indices = outIndices,
                    triangleCount = outIndices.size / 3
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}
