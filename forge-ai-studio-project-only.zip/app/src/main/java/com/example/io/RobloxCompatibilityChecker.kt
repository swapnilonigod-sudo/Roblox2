package com.example.io

import com.example.engine3d.ProceduralMeshGenerator
import com.example.model.CompatibilityIssue
import com.example.model.CompatibilityReport
import com.example.model.ForgeMaterial
import com.example.model.SceneNode

object RobloxCompatibilityChecker {

    fun analyze(nodes: List<SceneNode>, scaleMultiplier: Float): CompatibilityReport {
        val parts = nodes.filter { !it.isFolder && it.visible }
        val issues = mutableListOf<CompatibilityIssue>()
        var totalTriangles = 0

        val nameCounts = parts.groupingBy { it.name.trim() }.eachCount()
        val duplicateNames = nameCounts.filter { it.value > 1 }.keys

        for (node in parts) {
            val tris = ProceduralMeshGenerator.triangleCountFor(node.shape, node.customMesh)
            totalTriangles += tris

            if (tris > 10_000) {
                issues.add(
                    CompatibilityIssue(
                        severity = "WARN",
                        targetName = node.name,
                        message = "Mesh has $tris triangles (Roblox MeshPart recommended max is 10,000; hard limit 20,000).",
                        recommendation = "Decimate mesh or split into modular parts before importing."
                    )
                )
            }

            val sx = node.scale.x * scaleMultiplier
            val sy = node.scale.y * scaleMultiplier
            val sz = node.scale.z * scaleMultiplier
            if (sx <= 0.05f || sy <= 0.05f || sz <= 0.05f) {
                issues.add(
                    CompatibilityIssue(
                        severity = "WARN",
                        targetName = node.name,
                        message = "Scale axis below Roblox 0.05 stud minimum (${sx.format2()}, ${sy.format2()}, ${sz.format2()}).",
                        recommendation = "Increase scale multiplier or enlarge part dimensions."
                    )
                )
            }
            if (sx > 2048f || sy > 2048f || sz > 2048f) {
                issues.add(
                    CompatibilityIssue(
                        severity = "ERROR",
                        targetName = node.name,
                        message = "Exceeds Roblox BasePart maximum dimension of 2048 studs.",
                        recommendation = "Lower export scale multiplier or split terrain into chunks."
                    )
                )
            }

            if (node.name in duplicateNames) {
                issues.add(
                    CompatibilityIssue(
                        severity = "WARN",
                        targetName = node.name,
                        message = "Duplicate part name '${node.name}' may collide during Roblox script FindFirstChild lookups.",
                        recommendation = "Rename parts uniquely in Scene Explorer."
                    )
                )
            }

            if (node.material == ForgeMaterial.NEON && node.transparency > 0.3f) {
                issues.add(
                    CompatibilityIssue(
                        severity = "WARN",
                        targetName = node.name,
                        message = "Semi-transparent Neon material renders differently in Roblox Future lighting.",
                        recommendation = "Use Glass or SmoothPlastic for translucent glow meshes."
                    )
                )
            }

            if (!node.anchored && node.canCollide && sy > 8f) {
                issues.add(
                    CompatibilityIssue(
                        severity = "WARN",
                        targetName = node.name,
                        message = "Tall unanchored part may topple under Roblox physics simulation.",
                        recommendation = "Enable Anchored in Properties Inspector for static structures."
                    )
                )
            }
        }

        if (parts.isEmpty()) {
            issues.add(
                CompatibilityIssue(
                    severity = "ERROR",
                    targetName = "Workspace",
                    message = "No visible 3D parts available to export.",
                    recommendation = "Add or unhide at least one 3D object before exporting."
                )
            )
        } else if (issues.isEmpty()) {
            issues.add(
                CompatibilityIssue(
                    severity = "PASS",
                    targetName = "All ${parts.size} Parts",
                    message = "All meshes, scales, materials, and collision settings pass Roblox Studio 3D import checks.",
                    recommendation = "Export as GLB for full hierarchy, transforms, and PBR materials."
                )
            )
        }

        val estimatedBytes = parts.size * 512 + totalTriangles * 48
        val estimatedKb = (estimatedBytes / 1024).coerceAtLeast(1)
        val hasErrors = issues.any { it.severity == "ERROR" }

        return CompatibilityReport(
            totalParts = parts.size,
            totalTriangles = totalTriangles,
            estimatedGlbKb = estimatedKb,
            readyForRoblox = !hasErrors,
            issues = issues
        )
    }

    private fun Float.format2(): String = String.format("%.2f", this)
}
