package com.example.data

import android.content.Context
import com.example.R
import com.example.firebase.OperationType
import com.example.firebase.handleFirestoreError
import com.example.model.ForgeProjectSummary
import com.example.model.LightingSettings
import com.example.model.LuauScript
import com.example.model.SceneNode
import com.google.firebase.Firebase
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.auth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.FirebaseFirestoreException
import com.google.firebase.firestore.Query
import com.google.firebase.firestore.snapshots
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.catch
import kotlinx.coroutines.flow.flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.tasks.await

class ProjectRepository(
    private val db: FirebaseFirestore,
    private val auth: FirebaseAuth = Firebase.auth
) {
    constructor(context: Context) : this(
        FirebaseFirestore.getInstance(
            context.applicationContext.getString(R.string.firestore_database_id)
        )
    )

    private fun requireUserId(expectedUserId: String? = null): String {
        val uid = auth.currentUser?.uid
            ?: throw IllegalStateException("User must be signed in with Google before accessing Firestore.")
        if (expectedUserId != null) {
            check(uid == expectedUserId) { "Signed-in user changed; refusing cross-user Firestore operation." }
        }
        return uid
    }

    fun observeProjects(userId: String): Flow<List<ForgeProjectSummary>> = flow {
        val uid = requireUserId(userId)
        val path = "users/$uid/projects"
        db.collection("users").document(uid).collection("projects")
            .orderBy("updatedAt", Query.Direction.DESCENDING)
            .snapshots()
            .map { snapshot ->
                snapshot.documents.map { doc -> ForgeProjectSummary.fromSnapshot(doc) }
            }
            .catch { error ->
                val firestoreError = generateSequence(error) { it.cause }
                    .filterIsInstance<FirebaseFirestoreException>()
                    .firstOrNull()
                if (firestoreError == null && error is CancellationException) throw error
                val toLog = firestoreError ?: (error as? Exception)
                if (toLog != null && auth.currentUser?.uid == uid) {
                    handleFirestoreError(toLog, OperationType.LIST, path)
                }
                throw error
            }
            .collect { emit(it) }
    }

    suspend fun createProject(
        userId: String,
        name: String,
        description: String,
        lighting: LightingSettings,
        objects: List<SceneNode>,
        scripts: List<LuauScript>
    ): Result<String> {
        var docPath = "users/$userId/projects"
        return try {
            val uid = requireUserId(userId)
            val cleanName = name.trim().take(80).ifBlank { "Untitled Forge Project" }
            val docRef = db.collection("users").document(uid).collection("projects").document()
            docPath = docRef.path
            val payload = ForgeProjectSummary.createPayload(
                userId = uid,
                name = cleanName,
                description = description,
                lighting = lighting,
                objects = objects,
                scripts = scripts
            )
            docRef.set(payload).await()
            Result.success(docRef.id)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.CREATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun saveProject(
        userId: String,
        projectId: String,
        name: String,
        description: String,
        lighting: LightingSettings,
        objects: List<SceneNode>,
        scripts: List<LuauScript>
    ): Result<Unit> {
        val docPath = "users/$userId/projects/$projectId"
        return try {
            val uid = requireUserId(userId)
            require(projectId.isNotBlank()) { "Project ID cannot be blank" }
            val boundedObjects = objects.take(500).map { it.toFirestoreMap() }
            val boundedScripts = scripts.take(100).map { it.toFirestoreMap() }
            val cleanName = name.trim().take(80).ifBlank { "Untitled Forge Project" }
            db.collection("users").document(uid).collection("projects").document(projectId)
                .update(
                    mapOf(
                        "name" to cleanName,
                        "description" to description.trim().take(400),
                        "objectCount" to boundedObjects.size,
                        "scriptCount" to boundedScripts.size,
                        "lighting" to lighting.toFirestoreMap(),
                        "objects" to boundedObjects,
                        "scripts" to boundedScripts,
                        "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                    )
                )
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun renameProject(userId: String, projectId: String, newName: String): Result<Unit> {
        val docPath = "users/$userId/projects/$projectId"
        return try {
            val uid = requireUserId(userId)
            val cleanName = newName.trim().take(80)
            require(cleanName.isNotEmpty()) { "Project name must not be empty" }
            db.collection("users").document(uid).collection("projects").document(projectId)
                .update(
                    mapOf(
                        "name" to cleanName,
                        "updatedAt" to com.google.firebase.firestore.FieldValue.serverTimestamp()
                    )
                )
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.UPDATE, docPath)
            Result.failure(e)
        }
    }

    suspend fun deleteProject(userId: String, projectId: String): Result<Unit> {
        val docPath = "users/$userId/projects/$projectId"
        return try {
            val uid = requireUserId(userId)
            require(projectId.isNotBlank()) { "Project ID cannot be blank" }
            db.collection("users").document(uid).collection("projects").document(projectId)
                .delete()
                .await()
            Result.success(Unit)
        } catch (e: CancellationException) {
            throw e
        } catch (e: Exception) {
            handleFirestoreError(e, OperationType.DELETE, docPath)
            Result.failure(e)
        }
    }
}
