const {
  initializeTestEnvironment,
  assertFails,
  assertSucceeds,
} = require("@firebase/rules-unit-testing");
const { test, before, after, beforeEach } = require("node:test");
const fs = require("node:fs");

let testEnv;
// "demo-" project ids are reserved for the local Firebase emulator (no real project needed).
const PROJECT_ID = "demo-forge-ai-studio";
const ALICE_UID = "alice_forge_123";
const BOB_UID = "bob_forge_456";

// Must match emulators.firestore in firebase.json.
const emulatorHost = "127.0.0.1";
const emulatorPort = 8085;

function validProjectPayload(uid, overrides = {}) {
  const now = new Date(Date.now() - 2000);
  return {
    userId: uid,
    name: "Sky Citadel Realm",
    description: "Fantasy floating kingdom prototype",
    objectCount: 2,
    scriptCount: 1,
    lighting: {
      ambientIntensity: 0.45,
      sunIntensity: 1.0,
      skyColorHex: "#101628",
      fogEnabled: true,
      timeOfDay: "DUSK",
    },
    objects: [
      {
        id: "obj_1",
        name: "IslandBase",
        kind: "TERRAIN",
        shape: "BOX",
        parentId: "workspace",
        px: 0, py: -0.5, pz: 0,
        rx: 0, ry: 0, rz: 0,
        sx: 16, sy: 1, sz: 16,
        colorHex: "#2E6F40",
        material: "GRASS",
        visible: true,
        canCollide: true,
        anchored: true,
        transparency: 0.0,
      },
    ],
    scripts: [
      {
        id: "scr_1",
        name: "SprintSystem.luau",
        scriptType: "LocalScript",
        parentTarget: "StarterPlayerScripts",
        code: "-- Sprint system",
      },
    ],
    createdAt: now,
    updatedAt: now,
    ...overrides,
  };
}

before(async () => {
  const rules = fs.readFileSync("./firestore.rules", "utf8");
  testEnv = await initializeTestEnvironment({
    projectId: PROJECT_ID,
    firestore: {
      rules,
      host: emulatorHost,
      port: emulatorPort,
    },
  });
});

after(async () => {
  if (testEnv) {
    await testEnv.cleanup();
  }
});

beforeEach(async () => {
  if (testEnv) {
    await testEnv.clearFirestore();
  }
});

test("Unauthenticated user cannot list, read, create, or delete projects", async () => {
  const unauthDb = testEnv.unauthenticatedContext().firestore();
  await assertFails(unauthDb.collection("users").doc(ALICE_UID).collection("projects").get());
  await assertFails(
    unauthDb
      .collection("users")
      .doc(ALICE_UID)
      .collection("projects")
      .doc("proj_1")
      .set(validProjectPayload(ALICE_UID))
  );
  await assertFails(
    unauthDb.collection("users").doc(ALICE_UID).collection("projects").doc("proj_1").delete()
  );
});

test("Authenticated owner can create, list, update, rename, and delete own projects", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const projectsRef = aliceDb.collection("users").doc(ALICE_UID).collection("projects");

  await assertSucceeds(projectsRef.doc("proj_alpha").set(validProjectPayload(ALICE_UID)));
  await assertSucceeds(projectsRef.get());
  await assertSucceeds(projectsRef.doc("proj_alpha").get());

  // Full save update
  await assertSucceeds(
    projectsRef.doc("proj_alpha").update({
      name: "Sky Citadel v2",
      description: "Updated castle walls",
      objectCount: 3,
      scriptCount: 1,
      lighting: {
        ambientIntensity: 0.5,
        sunIntensity: 1.1,
        skyColorHex: "#141B30",
        fogEnabled: false,
        timeOfDay: "DAY",
      },
      objects: [],
      scripts: [],
      updatedAt: new Date(Date.now() - 500),
    })
  );

  // Rename-only update
  await assertSucceeds(
    projectsRef.doc("proj_alpha").update({
      name: "Sky Citadel Final",
      updatedAt: new Date(Date.now() - 200),
    })
  );

  await assertSucceeds(projectsRef.doc("proj_alpha").delete());
});

test("Cross-user isolation: Bob cannot read, list, create, update, or delete Alice's projects", async () => {
  await testEnv.withSecurityRulesDisabled(async (ctx) => {
    await ctx
      .firestore()
      .collection("users")
      .doc(ALICE_UID)
      .collection("projects")
      .doc("alice_proj")
      .set(validProjectPayload(ALICE_UID));
  });

  const bobDb = testEnv.authenticatedContext(BOB_UID).firestore();
  const aliceProjects = bobDb.collection("users").doc(ALICE_UID).collection("projects");

  await assertFails(aliceProjects.get());
  await assertFails(aliceProjects.doc("alice_proj").get());
  await assertFails(aliceProjects.doc("bob_inject").set(validProjectPayload(BOB_UID)));
  await assertFails(
    aliceProjects.doc("alice_proj").update({
      name: "Hijacked",
      updatedAt: new Date(Date.now() - 500),
    })
  );
  await assertFails(aliceProjects.doc("alice_proj").delete());
});

test("Security invariants: reject @DocumentId field, ghost keys, future timestamps, oversized names, and immutable field tampering", async () => {
  const aliceDb = testEnv.authenticatedContext(ALICE_UID).firestore();
  const projectsRef = aliceDb.collection("users").doc(ALICE_UID).collection("projects");

  // Reject extra `id` field
  await assertFails(
    projectsRef.doc("proj_bad_id").set(validProjectPayload(ALICE_UID, { id: "proj_bad_id" }))
  );

  // Reject shadow/ghost field
  await assertFails(
    projectsRef.doc("proj_ghost").set(validProjectPayload(ALICE_UID, { isAdmin: true }))
  );

  // Reject empty or oversized project name
  await assertFails(
    projectsRef.doc("proj_empty_name").set(validProjectPayload(ALICE_UID, { name: "" }))
  );
  await assertFails(
    projectsRef
      .doc("proj_long_name")
      .set(validProjectPayload(ALICE_UID, { name: "A".repeat(81) }))
  );

  // Reject future timestamp
  await assertFails(
    projectsRef
      .doc("proj_future_ts")
      .set(validProjectPayload(ALICE_UID, { createdAt: new Date(Date.now() + 120000) }))
  );

  // Create valid doc then attempt immutable createdAt / userId tampering
  await assertSucceeds(projectsRef.doc("proj_immutable").set(validProjectPayload(ALICE_UID)));
  await assertFails(
    projectsRef.doc("proj_immutable").update({
      createdAt: new Date(Date.now() - 100),
      updatedAt: new Date(Date.now() - 100),
    })
  );
  await assertFails(
    projectsRef.doc("proj_immutable").update({
      userId: BOB_UID,
      updatedAt: new Date(Date.now() - 100),
    })
  );
});
