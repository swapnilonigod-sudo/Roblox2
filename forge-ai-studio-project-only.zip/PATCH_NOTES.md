# Forge AI Studio patch notes (2026-11-27)

Changes applied based on official Android/Kotlin documentation and the review summary:
- Compose BOM updated from 2024.09.00 to 2026.09.00 (current stable documented BOM).
- KSP updated from 2.3.5 to 2.3.14 (recent release; 2.3.14 available Nov 2026).
- compileSdk updated from API 36 minor API 1 syntax to API 37, as newer Compose releases require API 37.

Kept unchanged:
- AGP 9.1.1, Gradle wrapper 9.3.1, Kotlin 2.4.21, targetSdk 36, Java source/target 11.
- GitHub workflow and existing application code.

Verification limitations:
- ZIP integrity and static changes are verified.
- Gradle compilation and tests were NOT run here because the Gradle distribution/network could not be fetched.
- Therefore this archive is patched, not certified error-free. Run GitHub Actions to verify the actual APK build.
